#!/usr/bin/env python3
"""Pages for the iPhone app (Capacitor): the same pages as the website, but fully local.
   The typeface comes with the app (fonts/), nothing is fetched from the internet, no offline worker.
   usage: python3 src/native/prepara_www.py <folder of the built site> <ios/App/App/public of the Xcode project> <folder with overpass-400/600/800/900.woff2>"""
import os, re, shutil, sys
R, W, F = [a.rstrip('/') + '/' for a in sys.argv[1:4]]
os.makedirs(W + 'fonts', exist_ok=True)
for w in (400, 600, 800, 900): shutil.copy(F + 'overpass-%d.woff2' % w, W + 'fonts/overpass-%d.woff2' % w)
FACE = '<style>' + ''.join("@font-face{font-family:'Overpass';font-style:normal;font-weight:%d;font-display:swap;src:url(fonts/overpass-%d.woff2) format('woff2')}" % (w, w) for w in (400, 600, 800, 900)) + '</style>'
for f in ['index.html', 'via-libera.html', 'palline.html', 'labirinti.html', 'acqua.html', 'incastri.html', 'adesivi.html', 'privacy.html']:
    s = open(R + f, encoding='utf-8').read()
    s = re.sub(r'<link rel="(preconnect|stylesheet)" href="https://fonts\.(googleapis|gstatic)\.com[^>]*>\n?', '', s).replace('</head>', FACE + '\n</head>', 1)
    s = re.sub(r"\n<script>if \('serviceWorker' in navigator.*?</script>", '', s, flags=re.S)
    s = re.sub(r'<link rel="manifest"[^>]*>\n?', '', s)
    if f == 'privacy.html':
        s = s.replace("L'unica richiesta verso l'esterno è il caricamento del carattere tipografico da Google Fonts alla prima apertura; dopo resta sul dispositivo.", "Non fa nessuna richiesta verso l'esterno: tutto, compreso il carattere tipografico, è dentro l'app.")
        s = s.replace("The only request to the outside is loading the typeface from Google Fonts the first time it opens; after that it stays on the device.", "It makes no requests to the outside at all: everything, the typeface included, is inside the app.")
    open(W + f, 'w', encoding='utf-8').write(s)
for f in ('icon-180.png', 'icon-192.png', 'icon-512.png'): shutil.copy(R + f, W + f)
print('pagine per l\'app pronte in', W)
