"""App Store listing texts, one block per language of the listing. Checked against Apple's limits by running this file."""
import json, sys
NB = ' '   # French: non-breaking space before : ! ? ;
S = {}

S['en'] = dict(
  usa=['Inglese (Regno Unito) — lingua principale', 'Inglese (Australia): non serve, l’App Store mostra questo testo'],
  shots='en',
  name='Giocapensa',
  subtitle='Logic puzzles for ages 3+',
  promo="Six logic games in 9 languages for children who can't read yet. No ads, no in-app purchases, no data collected. Works offline.",
  keywords='kids,toddler,preschool,brain,maze,counting,numbers,stickers,shapes,traffic,no ads,offline,learning',
  description="""Giocapensa brings together six logic games for children from the age of three, to play alone or with a grown-up.

There is nothing to read: children work out each game just by looking and trying. No timers, no lives to lose, no game over. Every level is open from the start, so children can play whichever levels they like.

THE SIX GAMES
• Way out: slide the vehicles aside to clear the road for the striped car. 160 levels.
• Balls in jars: sort the balls so that each jar holds a single colour. 120 levels.
• Mazes: trace the path with a finger, collect the stars, find the key. 120 levels.
• Water the flowers: turn the pipes until the water reaches every flower. 120 levels.
• Shape puzzles: fill the outline of the rocket, the castle or the dinosaur with the right pieces. 120 levels.
• Stickers: five scenes to complete (the station, the building site, the bedroom, the farm, prehistory) and four ways to play: every sticker on its shadow; everything in its place; count and place; on, under and inside. A voice names the stickers, says where they go and counts along with your child.

MADE FOR LITTLE ONES
• Big touch areas and forgiving gestures.
• The Help button only becomes available after a few attempts, so children have a go on their own first. The wait can be changed or switched off.
• The last move can always be undone.
• Every level has a verified minimum number of moves: matching it earns a round of applause.

FOR PARENTS
• No ads, no in-app purchases, no subscriptions.
• No data collected: no account, no tracking, nothing leaves the phone.
• Works offline.
• In 9 languages: English, Italian, Spanish, Portuguese, French, German, Japanese, Simplified and Traditional Chinese. The voice can speak a different language from the written one, to practise a second language.
• Settings for sounds, music, voice, language and help.

640 levels in all, each one generated and checked.""")

S['en-US'] = dict(S['en'])
S['en-US']['usa'] = ['Inglese (Stati Uniti)', 'Inglese (Canada): stesso testo']
for a, b in (('colour', 'color'), ('practise', 'practice'), ('the building site', 'the construction site'), ('have a go on their own first', 'try on their own first')):
    assert a in S['en-US']['description'], a
    S['en-US']['description'] = S['en-US']['description'].replace(a, b)

S['it'] = dict(
  usa=['Italiano'],
  shots='it',
  name='Giocapensa',
  subtitle='Giochi di logica dai 3 anni',
  promo='Sei giochi di logica in 9 lingue per bambini che non sanno ancora leggere. Niente pubblicità, niente acquisti in-app, nessun dato raccolto. Funziona anche senza internet.',
  keywords='bambini,puzzle,prescolare,labirinto,contare,adesivi,rompicapo,incastri,traffico,senza pubblicità',
  description="""Giocapensa raccoglie sei giochi di logica pensati per bambini dai tre anni, da fare da soli o insieme a un adulto.

Non c'è niente da leggere: ogni gioco si capisce guardando e provando. Niente tempo che scorre, niente vite da perdere, niente sconfitte. Tutti i livelli sono aperti fin dall'inizio, così ognuno gioca dove si diverte.

I SEI GIOCHI
• Via libera: sposta i veicoli per liberare la strada all'auto a strisce. 160 livelli.
• Palline nei tubi: rimetti insieme le palline dello stesso colore. 120 livelli.
• Labirinti: traccia il sentiero con il dito, raccogli le stelle, trova la chiave. 120 livelli.
• Acqua ai fiori: gira i tubi finché l'acqua arriva a tutti i fiori. 120 livelli.
• Incastri: riempi la sagoma del razzo, del castello o del dinosauro con i pezzi giusti. 120 livelli.
• Adesivi: cinque scene da completare (la stazione, il cantiere, la cameretta, la fattoria, la preistoria) e quattro modi di giocare: ogni adesivo sulla sua ombra; ogni cosa al suo posto; conta e metti; sopra, sotto e dentro. Una voce dice il nome degli adesivi, dove vanno, e conta insieme al bambino.

PENSATO PER I PIÙ PICCOLI
• Elementi grandi da toccare e gesti che perdonano le imprecisioni.
• Il pulsante Aiuto si sblocca dopo qualche tentativo, così il bambino prova prima da solo. L'attesa si può cambiare o togliere.
• L'ultima mossa si può sempre annullare.
• Ogni livello ha un numero minimo di mosse verificato: chi lo raggiunge riceve un applauso.

PER I GENITORI
• Niente pubblicità, niente acquisti in-app, niente abbonamenti.
• Nessun dato raccolto: niente account, niente tracciamento, niente esce dal telefono.
• Funziona senza connessione.
• In 9 lingue: italiano, inglese, spagnolo, portoghese, francese, tedesco, giapponese, cinese semplificato e tradizionale. La voce può parlare una lingua diversa da quella delle scritte, per esercitarsi con una seconda lingua.
• Impostazioni per suoni, musica, voce, lingua e aiuto.

640 livelli in tutto, generati e verificati uno per uno.""")

S['es'] = dict(
  usa=['Spagnolo (Spagna)', 'Spagnolo (Messico): stesso testo; serve per il Messico e l’America Latina'],
  shots='es',
  name='Giocapensa',
  subtitle='Juegos de lógica desde 3 años',
  promo='Seis juegos de lógica en 9 idiomas para niños que aún no saben leer. Sin anuncios, sin compras dentro de la app, sin recopilación de datos. Funciona sin internet.',
  keywords='niños,infantil,preescolar,puzle,rompecabezas,laberinto,contar,stickers,formas,tráfico,sin anuncios',
  description="""Giocapensa reúne seis juegos de lógica pensados para niños a partir de tres años, para jugar solos o con un adulto.

No hay nada que leer: cada juego se entiende mirando y probando. Sin cronómetro, sin vidas que perder, sin derrotas. Todos los niveles están abiertos desde el principio, así cada niño juega donde más se divierte.

LOS SEIS JUEGOS
• Vía libre: aparta los vehículos para abrir paso al coche a rayas. 160 niveles.
• Bolas en frascos: junta las bolas del mismo color en cada frasco. 120 niveles.
• Laberintos: traza el camino con el dedo, recoge las estrellas, encuentra la llave. 120 niveles.
• Agua para las flores: gira las tuberías hasta que el agua llegue a todas las flores. 120 niveles.
• Puzles de formas: llena la silueta del cohete, del castillo o del dinosaurio con las piezas correctas. 120 niveles.
• Stickers: cinco escenas para completar (la estación, la obra, el dormitorio, la granja, la prehistoria) y cuatro formas de jugar: cada sticker en su sombra; cada cosa en su sitio; cuenta y pega; encima, debajo y dentro. Una voz dice el nombre de los stickers, dónde van, y cuenta junto con el niño.

PENSADO PARA LOS MÁS PEQUEÑOS
• Zonas táctiles grandes y gestos que no exigen precisión.
• El botón de ayuda se desbloquea después de algunos intentos, para que el niño pruebe primero solo. La espera se puede cambiar o quitar.
• Siempre se puede deshacer el último movimiento.
• Cada nivel tiene un número mínimo de movimientos comprobado: quien lo consigue recibe un aplauso.

PARA LAS FAMILIAS
• Sin anuncios, sin compras dentro de la app, sin suscripciones.
• No recoge datos: sin cuenta, sin rastreo, nada sale del teléfono.
• Funciona sin conexión.
• En 9 idiomas: español, inglés, italiano, portugués, francés, alemán, japonés, chino simplificado y tradicional. La voz puede hablar un idioma distinto del de los textos, para practicar una segunda lengua.
• Ajustes de sonidos, música, voz, idioma y ayuda.

640 niveles en total, generados y comprobados uno a uno.""")

S['pt'] = dict(
  usa=['Portoghese (Brasile)', 'Portoghese (Portogallo): stesso testo; senza, in Portogallo la scheda appare in inglese'],
  shots='pt',
  name='Giocapensa',
  subtitle='Jogos de lógica para crianças',
  promo='Seis jogos de lógica em 9 idiomas para crianças que ainda não sabem ler. Sem anúncios, sem compras no app, sem coleta de dados. Funciona sem internet.',
  keywords='infantil,pré-escola,quebra-cabeça,labirinto,contar,números,adesivos,formas,trânsito,sem anúncios',
  description="""Giocapensa reúne seis jogos de lógica pensados para crianças a partir de três anos, para jogar sozinhas ou com um adulto.

Não há nada para ler: cada jogo se entende olhando e experimentando. Sem relógio correndo, sem vidas para perder, sem derrotas. Todos os níveis estão abertos desde o início, então cada criança joga onde mais se diverte.

OS SEIS JOGOS
• Caminho livre: tire os veículos do caminho para o carro listrado passar. 160 níveis.
• Bolinhas nos potes: junte as bolinhas da mesma cor em cada pote. 120 níveis.
• Labirintos: trace o caminho com o dedo, pegue as estrelas, encontre a chave. 120 níveis.
• Água para as flores: gire os canos até a água chegar a todas as flores. 120 níveis.
• Encaixe: preencha a silhueta do foguete, do castelo ou do dinossauro com as peças certas. 120 níveis.
• Adesivos: cinco cenas para completar (a estação, a obra, o quarto, a fazenda, a pré-história) e quatro jeitos de jogar: cada adesivo na sua sombra; cada coisa no seu lugar; conte e cole; em cima, embaixo e dentro. Uma voz diz o nome dos adesivos, onde eles vão, e conta junto com a criança.

PENSADO PARA OS PEQUENOS
• Áreas de toque grandes e gestos que não exigem precisão.
• O botão de ajuda só é liberado depois de algumas tentativas, assim a criança tenta sozinha primeiro. A espera pode ser alterada ou desligada.
• A última jogada sempre pode ser desfeita.
• Cada nível tem um número mínimo de jogadas verificado: quem consegue ganha aplausos.

PARA AS FAMÍLIAS
• Sem anúncios, sem compras no app, sem assinatura.
• Nenhum dado coletado: sem conta, sem rastreamento, nada sai do celular.
• Funciona sem conexão.
• Em 9 idiomas: português, inglês, italiano, espanhol, francês, alemão, japonês, chinês simplificado e tradicional. A voz pode falar um idioma diferente do dos textos, para praticar uma segunda língua.
• Ajustes de sons, música, voz, idioma e ajuda.

640 níveis no total, gerados e verificados um a um.""")

S['fr'] = dict(
  usa=['Francese', 'Francese (Canada): stesso testo'],
  shots='fr',
  name='Giocapensa',
  subtitle='Jeux de logique dès 3 ans',
  promo='Six jeux de logique en 9 langues pour les enfants qui ne savent pas encore lire. Sans pub, sans achats intégrés, aucune donnée collectée. Fonctionne sans internet.',
  keywords='enfant,maternelle,puzzle,labyrinthe,compter,chiffres,autocollants,formes,casse-tête,sans pub',
  description=("""Giocapensa réunit six jeux de logique pensés pour les enfants dès 3 ans, à jouer seul ou avec un adulte.

Rien à lire{NB}: chaque jeu se comprend en regardant et en essayant. Pas de chrono, pas de vies à perdre, pas de défaite. Tous les niveaux sont ouverts dès le départ{NB}; chacun joue là où il s’amuse.

LES SIX JEUX
• Voie libre{NB}: écarte les véhicules pour laisser passer la voiture à rayures. 160 niveaux.
• Boules en bocaux{NB}: regroupe les boules de la même couleur dans chaque bocal. 120 niveaux.
• Labyrinthes{NB}: trace le chemin du doigt, ramasse les étoiles, trouve la clé. 120 niveaux.
• De l’eau pour les fleurs{NB}: tourne les tuyaux jusqu’à ce que l’eau arrive à toutes les fleurs. 120 niveaux.
• Encastrements{NB}: remplis la silhouette de la fusée, du château ou du dinosaure avec les bonnes pièces. 120 niveaux.
• Autocollants{NB}: cinq scènes à compléter (la gare, le chantier, la chambre, la ferme, la préhistoire) et quatre façons de jouer{NB}: chaque autocollant sur son ombre{NB}; chaque chose à sa place{NB}; compte et colle{NB}; sur, sous et dans. Une voix nomme les autocollants, indique où ils vont et compte avec l’enfant.

PENSÉ POUR LES PETITS
• De grandes zones tactiles et des gestes qui tolèrent les imprécisions.
• Le bouton Aide se débloque après quelques essais{NB}: l’enfant essaie d’abord tout seul. L’attente peut être modifiée ou désactivée.
• Le dernier coup peut toujours être annulé.
• Chaque niveau a un nombre minimum de coups vérifié{NB}: l’atteindre déclenche des applaudissements.

POUR LES PARENTS
• Pas de publicité, pas d’achats intégrés, pas d’abonnement.
• Aucune donnée collectée{NB}: pas de compte, pas de suivi, rien ne sort du téléphone.
• Fonctionne hors connexion.
• En 9 langues{NB}: français, anglais, italien, espagnol, portugais, allemand, japonais, chinois simplifié et traditionnel. La voix peut parler une autre langue que celle des textes, pour pratiquer une deuxième langue.
• Réglages pour les sons, la musique, la voix, la langue et l’aide.

640 niveaux en tout, générés et vérifiés un par un.""").replace('{NB}', NB))

S['de'] = dict(
  usa=['Tedesco'],
  shots='de',
  name='Giocapensa',
  subtitle='Logikspiele ab 3 Jahren',
  promo='Sechs Logikspiele in 9 Sprachen für Kinder, die noch nicht lesen können. Keine Werbung, keine In-App-Käufe, keine Datenerhebung. Funktioniert ohne Internet.',
  keywords='Kinder,Kleinkind,Kindergarten,Puzzle,Labyrinth,Zählen,Zahlen,Sticker,Formen,Rätsel,ohne Werbung',
  description="""Giocapensa vereint sechs Logikspiele für Kinder ab drei Jahren – allein oder zusammen mit einem Erwachsenen.

Es gibt nichts zu lesen: Jedes Spiel erschließt sich durch Hinschauen und Ausprobieren. Keine Uhr, die tickt, keine Leben, kein Game over. Alle Level sind von Anfang an freigeschaltet, so spielt jedes Kind dort, wo es Spaß hat.

DIE SECHS SPIELE
• Freie Fahrt: Schieb die Fahrzeuge zur Seite, damit das gestreifte Auto freie Fahrt hat. 160 Level.
• Kugeln im Glas: Sortiere die Kugeln, bis in jedem Glas nur eine Farbe ist. 120 Level.
• Labyrinthe: Zeichne den Weg mit dem Finger nach, sammle die Sterne, finde den Schlüssel. 120 Level.
• Wasser für die Blumen: Dreh die Rohre, bis das Wasser alle Blumen erreicht. 120 Level.
• Formenpuzzle: Füll die Umrisse von Rakete, Burg oder Dinosaurier mit den passenden Teilen. 120 Level.
• Sticker: fünf Bilder zum Vervollständigen (Bahnhof, Baustelle, Kinderzimmer, Bauernhof, Urzeit) und vier Spielarten: jeder Sticker auf seinen Schatten; alles an seinen Platz; zählen und kleben; auf, unter und in. Eine Stimme nennt die Sticker, sagt, wohin sie gehören, und zählt mit dem Kind.

FÜR DIE KLEINSTEN GEMACHT
• Große Tippflächen und Gesten, die Ungenauigkeiten verzeihen.
• Die Hilfe-Taste wird erst nach ein paar Versuchen frei, so probiert das Kind es zuerst selbst. Die Wartezeit lässt sich ändern oder abschalten.
• Der letzte Zug lässt sich immer zurücknehmen.
• Jedes Level hat eine geprüfte Mindestzahl an Zügen: Wer sie schafft, bekommt Applaus.

FÜR ELTERN
• Keine Werbung, keine In-App-Käufe, kein Abo.
• Keine Datenerhebung: kein Konto, kein Tracking, nichts verlässt das Gerät.
• Funktioniert offline.
• In 9 Sprachen: Deutsch, Englisch, Italienisch, Spanisch, Portugiesisch, Französisch, Japanisch, vereinfachtes und traditionelles Chinesisch. Die Stimme kann eine andere Sprache sprechen als die Texte, zum Üben einer zweiten Sprache.
• Einstellungen für Töne, Musik, Stimme, Sprache und Hilfe.

Insgesamt 640 Level, jedes einzeln erzeugt und geprüft.""")

S['ja'] = dict(
  usa=['Giapponese'],
  shots='ja',
  name='Giocapensa',
  subtitle='3歳からの知育ロジックゲーム',
  promo='字が読めなくても遊べる、6つのロジックゲーム。9か国語に対応。広告なし・アプリ内課金なし・データ収集なし。ネット接続は不要です。',
  keywords='子供,幼児,幼稚園,パズル,迷路,数遊び,シール,脳トレ,車,恐竜,広告なし,4歳,5歳',
  description="""Giocapensa（ジョカペンサ）は、3歳からの子どものための6つのロジックゲームを集めたアプリです。ひとりでも、大人といっしょでも遊べます。

読む必要はありません。どのゲームも、見て、さわって、ためすうちに遊び方がわかります。制限時間も、ライフも、ゲームオーバーもありません。すべてのレベルが最初から開いているので、好きなところから遊べます。

6つのゲーム
・クルマ脱出：車を動かして道をあけ、しましまの車を出口まで動かそう。160レベル。
・ボールわけ：同じ色のボールを同じびんに集めよう。120レベル。
・めいろ：指で道をなぞって、星を集め、かぎを見つけよう。120レベル。
・お花に水を：パイプを回して、すべての花に水を届けよう。120レベル。
・かたちパズル：ロケット、お城、恐竜のかたちをピースでうめよう。120レベル。
・シール：5つの場面（駅、工事現場、子ども部屋、牧場、恐竜の時代）と4つの遊び方（かげにはる、あるべき場所に、かぞえてはる、上・下・中）。声がシールの名前とはる場所を教え、いっしょに数をかぞえます。

小さな子のために
・大きなタッチ範囲と、少しずれても大丈夫な操作。
・「ヒント」ボタンは何度か試したあとに使えるようになるので、まずは自分で考えます。待ち時間は変更したり、オフにしたりできます。
・最後の一手はいつでも戻せます。
・各レベルには検証済みの最少手数があり、達成すると拍手で祝ってくれます。

保護者の方へ
・広告なし、アプリ内課金なし、サブスクリプションなし。
・データは一切収集しません。アカウントも追跡もなく、情報が端末の外に出ることはありません。
・オフラインで遊べます。
・9か国語に対応：日本語、英語、イタリア語、スペイン語、ポルトガル語、フランス語、ドイツ語、中国語（簡体字・繁体字）。声の言語を文字と別にすることもでき、外国語の練習にもなります。
・効果音、音楽、声、言語、ヒントの設定ができます。

全640レベル。どのレベルも自動で作成し、1つずつ検証しています。""")

S['zh-Hans'] = dict(
  usa=['Cinese (semplificato)'],
  shots='zh-Hans',
  name='Giocapensa',
  subtitle='3岁起的益智逻辑游戏',
  promo='6个逻辑游戏，不识字的孩子也能玩，支持9种语言。无广告、无内购、不收集任何数据，无需联网。',
  keywords='儿童,幼儿,宝宝,幼儿园,拼图,迷宫,数数,贴纸,早教,汽车,恐龙,无广告,4岁,5岁',
  description="""Giocapensa 收录了6个逻辑游戏，适合3岁以上的孩子，可以自己玩，也可以和大人一起玩。

完全不需要认字：每个游戏都能边看边试、自己弄懂。没有倒计时，没有生命值，也没有失败。所有关卡一开始就全部开放，孩子想玩哪关就玩哪关。

六个游戏
• 堵车脱困：挪开车辆，为条纹小汽车让出道路。160关。
• 彩球分类：把同样颜色的球放进同一个罐子。120关。
• 迷宫：用手指画出路线，收集星星，找到钥匙。120关。
• 给花浇水：转动水管，让水流到每一朵花。120关。
• 形状拼图：用合适的拼块填满火箭、城堡或恐龙的轮廓。120关。
• 贴纸：5个场景（车站、工地、儿童房、农场、史前时代），4种玩法（贴到影子上、放回原位、数一数再贴、上面·下面·里面）。语音会说出贴纸的名称和要贴的位置，并和孩子一起数数。

为小朋友设计
• 大大的点击区域，手势不必很精准。
• “提示”按钮要尝试几次之后才会开启，让孩子先自己动脑。等待时间可以调整或关闭。
• 随时可以撤销上一步。
• 每一关都有经过验证的最少步数，达成时会响起掌声。

给家长
• 无广告、无内购、无订阅。
• 不收集任何数据：无需账号，没有追踪，任何信息都不会离开手机。
• 无需联网即可使用。
• 支持9种语言：简体中文、繁体中文、英语、意大利语、西班牙语、葡萄牙语、法语、德语、日语。语音可以使用与文字不同的语言，帮助孩子练习第二语言。
• 可以设置音效、音乐、语音、语言和提示。

共640关，全部自动生成，并逐关验证。""")

S['zh-Hant'] = dict(
  usa=['Cinese (tradizionale)'],
  shots='zh-Hant',
  name='Giocapensa',
  subtitle='3歲起的益智邏輯遊戲',
  promo='6個邏輯遊戲，不識字的孩子也能玩，支援9種語言。無廣告、無內購、不收集任何資料，不需連網。',
  keywords='兒童,幼兒,寶寶,幼稚園,拼圖,迷宮,數數,貼紙,幼教,汽車,恐龍,無廣告,4歲,5歲',
  description="""Giocapensa 收錄了6個邏輯遊戲，適合3歲以上的孩子，可以自己玩，也可以和大人一起玩。

完全不需要認字：每個遊戲都能邊看邊試、自己弄懂。沒有倒數計時，沒有生命值，也沒有失敗。所有關卡一開始就全部開放，孩子想玩哪關就玩哪關。

六個遊戲
• 塞車脫困：挪開車輛，為條紋小汽車讓出道路。160關。
• 彩球分類：把同樣顏色的球放進同一個罐子。120關。
• 迷宮：用手指畫出路線，收集星星，找到鑰匙。120關。
• 給花澆水：轉動水管，讓水流到每一朵花。120關。
• 形狀拼圖：用合適的拼塊填滿火箭、城堡或恐龍的輪廓。120關。
• 貼紙：5個場景（車站、工地、兒童房、農場、史前時代），4種玩法（貼到影子上、放回原位、數一數再貼、上面・下面・裡面）。語音會說出貼紙的名稱和要貼的位置，並和孩子一起數數。

為小朋友設計
• 大大的點擊區域，手勢不必很精準。
• 「提示」按鈕要嘗試幾次之後才會開啟，讓孩子先自己動腦。等待時間可以調整或關閉。
• 隨時可以復原上一步。
• 每一關都有經過驗證的最少步數，達成時會響起掌聲。

給家長
• 無廣告、無內購、無訂閱。
• 不收集任何資料：不需要帳號，沒有追蹤，任何資訊都不會離開手機。
• 不需連網即可使用。
• 支援9種語言：繁體中文、簡體中文、英文、義大利文、西班牙文、葡萄牙文、法文、德文、日文。語音可以使用與文字不同的語言，幫助孩子練習第二語言。
• 可以設定音效、音樂、語音、語言和提示。

共640關，全部自動生成，並逐關驗證。""")

LIM = dict(name=30, subtitle=30, promo=170, keywords=100, description=4000)
ORDER = ['en', 'en-US', 'it', 'es', 'pt', 'fr', 'de', 'ja', 'zh-Hans', 'zh-Hant']
bad = 0
for k in ORDER:
    for f, n in LIM.items():
        v = S[k][f]
        if len(v) > n: bad += 1; print('TROPPO LUNGO', k, f, len(v), '>', n)
    kw = S[k]['keywords'].split(',')
    if len(set(x.lower() for x in kw)) != len(kw) or any(x != x.strip() or not x for x in kw): bad += 1; print('parole chiave da sistemare', k)
    print('%-8s nome %2d  sottotitolo %2d  promo %3d  parole %3d  descrizione %4d' % (k, len(S[k]['name']), len(S[k]['subtitle']), len(S[k]['promo']), len(S[k]['keywords']), len(S[k]['description'])))
if '--json' in sys.argv: json.dump({'order': ORDER, 'S': S}, open(sys.argv[-1], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('problemi:', bad)
