#!/usr/bin/env python3
"""Fills Giocapensa's App Store listing through the App Store Connect API.

For every language in testi.json it sets name, subtitle and privacy policy URL (app information),
description, keywords, promotional text and support URL (the version being prepared), and the
6.9-inch screenshots; it also sets categories and copyright. Price, countries, age rating, app
privacy, review contact and the submission stay manual in App Store Connect.
It can run again at any time: texts are rewritten, screenshots are replaced only where they differ.

Environment: APPSTORE_KEY_ID, APPSTORE_ISSUER_ID, APPSTORE_P8 (text of the .p8 key);
optional VERSIONE (version to fill, e.g. 1.1; default: «versione» of testi.json, else the one being prepared; a version
that does not exist yet is created), USCITA (--invia: release date, e.g. 2026-12-08; default: «uscita» of testi.json; empty: as soon as it is approved),
ASC_API (tests only).
usage: python3 carica.py [folder with testi.json and schermate/] [--stato | --reinvia [--davvero] | --invia [--davvero] | --candida [--davvero]]
--stato only reads: versions, builds, review submissions and countries, as annotations (workflow «Stato su App Store Connect»).
--reinvia sends a rejected version back to App Review with the review notes of testi.json (workflow «Reinvio alla
revisione»); without --davvero it only reads and says what it would do.
--invia sends the version being prepared to App Review (workflow «Invio alla revisione»): newest ready build, review
notes of testi.json, release date, submission; without --davvero it only reads and says what it would do.
--candida nominates the version for an App Store feature (Featuring → Nominations) with «candidatura» of testi.json and the
release date as publishing date (workflow «Candidatura in evidenza»); without --davvero it only says what it would send.
Messages for the parent are in Italian and go out as GitHub annotations, readable from the API.
"""
import glob, hashlib, http.client, json, os, re, sys, time, urllib.error, urllib.parse, urllib.request

API = os.environ.get('ASC_API', 'https://api.appstoreconnect.apple.com').rstrip('/')
DIR = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__)))
EDITABLE = {'PREPARE_FOR_SUBMISSION', 'READY_FOR_REVIEW', 'DEVELOPER_REJECTED', 'REJECTED', 'METADATA_REJECTED', 'INVALID_BINARY'}
DISPLAY = 'APP_IPHONE_67'            # the 6.9-inch slot of App Store Connect (1320 x 2868)
SUMMARY = []                          # rows for the run page


class Apple(Exception):
    pass


def _esc(s, prop=False):
    s = str(s).replace('%', '%25').replace('\r', '%0D').replace('\n', '%0A')
    return s.replace(':', '%3A').replace(',', '%2C') if prop else s


def note(kind, title, msg):
    print('::%s title=%s::%s' % (kind, _esc(title, True), _esc(msg)), flush=True)


def fail(msg):
    note('error', 'Scheda App Store', msg)
    sys.exit(1)


_tok = {'t': None, 'at': 0}


def pem(text):
    """The .p8 key as pasted from a phone: extra spaces, blank lines or \\n written out do not matter."""
    t = text.replace('\\n', '\n')
    m = re.search(r'-----BEGIN PRIVATE KEY-----(.*?)-----END PRIVATE KEY-----', t, re.S)
    body = re.sub(r'[^A-Za-z0-9+/=]', '', m.group(1) if m else t)
    return '-----BEGIN PRIVATE KEY-----\n%s\n-----END PRIVATE KEY-----\n' % '\n'.join(body[i:i + 64] for i in range(0, len(body), 64))


def token():
    now = int(time.time())
    if not _tok['t'] or now - _tok['at'] > 600:
        import jwt                    # PyJWT, with cryptography for ES256
        try:
            _tok['t'] = jwt.encode({'iss': os.environ['APPSTORE_ISSUER_ID'].strip(), 'iat': now, 'exp': now + 1080, 'aud': 'appstoreconnect-v1'},
                                   pem(os.environ['APPSTORE_P8']), algorithm='ES256', headers={'kid': re.sub(r'\s', '', os.environ['APPSTORE_KEY_ID']), 'typ': 'JWT'})
        except Exception as e:
            raise Apple('La chiave APPSTORE_P8 non si legge (%s): rimettila copiando tutto il testo del file .p8, comprese le righe BEGIN e END (passi B8 e C1).' % type(e).__name__)
        _tok['at'] = now
    return _tok['t']


def describe(method, path, status, raw):
    try:
        errs = json.loads(raw).get('errors') or []
    except ValueError:
        errs = []
    parts = []
    for e in errs[:4]:
        where = (e.get('source') or {}).get('pointer') or (e.get('source') or {}).get('parameter') or ''
        parts.append(' '.join(x for x in (e.get('code', ''), '-', e.get('detail') or e.get('title') or '', ('(' + where + ')') if where else '') if x))
    text = '%s %s → %d: %s' % (method, urllib.parse.unquote(path.replace(API, '')), status, '; '.join(parts) or raw[:300])
    if status == 401:
        text += '. Apple non accetta la chiave: controlla i segreti APPSTORE_KEY_ID, APPSTORE_ISSUER_ID e APPSTORE_P8 (passo C1), senza spazi in più.'
    elif status == 403:
        text += '. Apple rifiuta l\'operazione: la chiave deve avere accesso Admin, e in App Store Connect → Business gli accordi devono essere accettati.'
    return text


def call(method, path, body=None, query=None):
    url = path if path.startswith('http') else API + path
    if query:
        url += ('&' if '?' in url else '?') + urllib.parse.urlencode(query)
    data = None if body is None else json.dumps(body).encode()
    for attempt in range(5):
        req = urllib.request.Request(url, data=data, method=method, headers={'Authorization': 'Bearer ' + token(), 'Content-Type': 'application/json', 'Accept': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=90) as r:
                raw = r.read()
            return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            raw = e.read().decode('utf-8', 'replace')
            if e.code in (429, 500, 502, 503, 504) and attempt < 4:
                time.sleep(5 * (attempt + 1))
                continue
            raise Apple(describe(method, url, e.code, raw))
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
            if attempt < 4:
                time.sleep(5 * (attempt + 1))
                continue
            raise Apple('%s %s: Apple non risponde (%s)' % (method, path, e))


def items(path, query=None):
    q = dict(query or {})
    q.setdefault('limit', 50)
    res, out = call('GET', path, query=q), []
    while True:
        out += res.get('data') or []
        nxt = (res.get('links') or {}).get('next')
        if not nxt:
            return out
        res = call('GET', nxt)


def state(x):
    a = x.get('attributes') or {}
    return a.get('appVersionState') or a.get('state') or a.get('appStoreState') or ''


def rel(kind, id_):
    return {'data': {'type': kind, 'id': id_}}


def upsert(kind, have, locale, attrs, parent_rel, parent_kind, parent_id):
    """PATCH the localization of this locale if it exists, else create it."""
    if locale in have:
        call('PATCH', '/v1/%s/%s' % (kind, have[locale]), {'data': {'type': kind, 'id': have[locale], 'attributes': attrs}})
        return have[locale], 'aggiornata'
    a = dict(attrs, locale=locale)
    res = call('POST', '/v1/' + kind, {'data': {'type': kind, 'attributes': a, 'relationships': {parent_rel: rel(parent_kind, parent_id)}}})
    return res['data']['id'], 'aggiunta'


def first_keywords(kw, limit=100):
    """The keywords from the first, whole, within limit bytes: for the case Apple counts bytes and not characters."""
    out = []
    for w in kw.split(','):
        if len(','.join(out + [w]).encode()) > limit:
            break
        out.append(w)
    return ','.join(out)


def builds(app, version):
    """One line on the builds of this version, for the parent; never stops the run."""
    try:
        rows = call('GET', '/v1/builds', query={'filter[app]': app, 'filter[preReleaseVersion.version]': version, 'sort': '-uploadedDate', 'limit': 5}).get('data') or []
    except Apple:
        return
    if not rows:
        note('notice', 'Build', 'Per la versione %s Apple non ha ancora nessuna build: si carica con il flusso «App per iPhone».' % version)
        return
    words = {'VALID': 'pronta: si sceglie nella pagina della versione, sezione Build', 'PROCESSING': 'Apple la sta ancora controllando (di solito 15-60 minuti)',
             'FAILED': 'scartata da Apple: il motivo è nell\'email di Apple', 'INVALID': 'scartata da Apple: il motivo è nell\'email di Apple'}
    a = rows[0]['attributes']
    note('notice', 'Build', 'Ultima build della versione %s: %s, %s.' % (version, a.get('version'), words.get(a.get('processingState'), a.get('processingState'))))


def md5(path):
    return hashlib.md5(open(path, 'rb').read()).hexdigest()


def put_part(op, data):
    """Sends one part of a file to the address Apple gives, with exactly the headers Apple asks for."""
    u = urllib.parse.urlsplit(op['url'])
    chunk = data[op['offset']:op['offset'] + op['length']]
    headers = {h['name']: h['value'] for h in op.get('requestHeaders') or []}
    headers['Content-Length'] = str(len(chunk))
    target = u.path + ('?' + u.query if u.query else '')
    for attempt in range(5):
        conn = (http.client.HTTPSConnection if u.scheme == 'https' else http.client.HTTPConnection)(u.netloc, timeout=120)
        try:
            conn.request(op.get('method') or 'PUT', target, body=chunk, headers=headers)
            r = conn.getresponse()
            r.read()
            if r.status < 300:
                return
            err = 'HTTP %d' % r.status
        except (OSError, http.client.HTTPException) as e:
            err = str(e)
        finally:
            conn.close()
        if attempt < 4:
            time.sleep(4 * (attempt + 1))
    raise Apple('invio di una schermata non riuscito (%s)' % err)


def upload(set_id, path, checksum):
    data = open(path, 'rb').read()
    res = call('POST', '/v1/appScreenshots', {'data': {'type': 'appScreenshots', 'attributes': {'fileName': os.path.basename(path), 'fileSize': len(data)},
                                                       'relationships': {'appScreenshotSet': rel('appScreenshotSets', set_id)}}})['data']
    for op in res['attributes'].get('uploadOperations') or []:
        put_part(op, data)
    call('PATCH', '/v1/appScreenshots/' + res['id'], {'data': {'type': 'appScreenshots', 'id': res['id'], 'attributes': {'uploaded': True, 'sourceFileChecksum': checksum}}})
    return res['id']


def find_app(T):
    apps = [a for a in call('GET', '/v1/apps', query={'filter[bundleId]': T['bundle']}).get('data') or [] if (a.get('attributes') or {}).get('bundleId') == T['bundle']]
    if not apps:
        fail('In App Store Connect non c\'è ancora un\'app con identificativo %s: creala prima (passo B6), poi rilancia.' % T['bundle'])
    return apps[0]


def stato(T):
    """Read-only (--stato): versions, builds, review submissions and countries as App Store Connect sees them now.
    Each part goes out as annotations; a part Apple refuses becomes a warning and the others still run."""
    app = find_app(T)['id']

    def versioni():
        for v in items('/v1/apps/%s/appStoreVersions' % app, {'filter[platform]': 'IOS'})[:4]:
            b = call('GET', '/v1/appStoreVersions/%s/build' % v['id']).get('data')
            note('notice', 'Versione ' + str(v['attributes'].get('versionString')), '%s; build scelta: %s' % (state(v), b['attributes'].get('version') if b else 'nessuna'))

    def build():
        res = call('GET', '/v1/builds', query={'filter[app]': app, 'sort': '-uploadedDate', 'limit': 6, 'include': 'preReleaseVersion'})
        pre = {x['id']: (x.get('attributes') or {}).get('version') for x in res.get('included') or [] if x.get('type') == 'preReleaseVersions'}
        for b in res.get('data') or []:
            a = b.get('attributes') or {}
            p = (((b.get('relationships') or {}).get('preReleaseVersion') or {}).get('data') or {}).get('id')
            note('notice', 'Build ' + str(a.get('version')), 'versione %s: %s (caricata %s)' % (pre.get(p, '?'), a.get('processingState'), (a.get('uploadedDate') or '-')[:16]))

    def revisioni():
        for s in items('/v1/reviewSubmissions', {'filter[app]': app, 'filter[platform]': 'IOS'})[-4:]:
            a = s.get('attributes') or {}
            note('notice', 'Revisione', '%s (inviata %s)' % (a.get('state'), (a.get('submittedDate') or '-')[:16]))

    def paesi():
        av = call('GET', '/v1/apps/%s/appAvailabilityV2' % app)['data']['id']
        on, off = [], []
        for t in items('/v2/appAvailabilities/%s/territoryAvailabilities' % av, {'include': 'territory'}):
            tid = (((t.get('relationships') or {}).get('territory') or {}).get('data') or {}).get('id', '?')
            (on if (t.get('attributes') or {}).get('available') else off).append(tid)
        note('notice', 'Paesi', 'disponibile in %d; esclusi: %s' % (len(on), ', '.join(sorted(off)) or 'nessuno'))

    for title, part in (('Versioni', versioni), ('Build', build), ('Revisione', revisioni), ('Paesi', paesi)):
        try:
            part()
        except (Apple, KeyError, TypeError) as e:
            note('warning', title, 'non letto: %s' % e)


def reinvia(T, davvero):
    """--reinvia: sends the rejected app version back to App Review, as «Modifica», «Aggiungi alla verifica» and
    the resubmit button do in App Store Connect. It puts T['note_revisione'] in the version's review notes, marks
    the rejected item of the open submission as resolved and submits the submission again; Apple then closes the
    message thread of that submission, so the notes open with a line that points the new reviewer to the answers.
    Without davvero it changes nothing and says what it would do.
    The current notes are never printed (annotations are public): only their length."""
    tit = 'Reinvio' if davvero else 'Prova del reinvio'
    base = (T.get('note_revisione') or '').strip()
    if 'Guideline 1.3' not in base:
        fail('In testi.json mancano le note per la revisione con le risposte sulla categoria Bambini (note_revisione): senza, non reinvio.')
    nuove = ('Resubmission after an information request: the answers to the Kids Category questions (Guideline 1.3) '
             'are repeated at the end of these notes.\n\n' + base)
    if len(nuove) > 4000:
        fail('Le note per la revisione sono lunghe %d caratteri: Apple ne accetta al massimo 4000.' % len(nuove))
    app = find_app(T)['id']
    aperte = items('/v1/reviewSubmissions', {'filter[app]': app, 'filter[platform]': 'IOS', 'filter[state]': 'UNRESOLVED_ISSUES'})
    if len(aperte) != 1:
        fail('Mi aspettavo una sola richiesta di revisione con problemi da risolvere, ne ho trovate %d: non tocco niente.' % len(aperte))
    sub = aperte[0]
    note('notice', tit, 'richiesta %s: %s (inviata %s)' % (sub['id'], state(sub), (sub['attributes'].get('submittedDate') or '-')[:16]))
    res = call('GET', '/v1/reviewSubmissions/%s/items' % sub['id'], query={'include': 'appStoreVersion', 'limit': 50})
    elementi = [x for x in res.get('data') or [] if state(x) != 'REMOVED']
    for x in elementi:
        note('notice', tit, 'elemento %s: %s' % (x['id'], state(x)))
    vers = [x for x in elementi if (((x.get('relationships') or {}).get('appStoreVersion') or {}).get('data') or {}).get('id')]
    if len(elementi) != 1 or len(vers) != 1 or state(vers[0]) not in ('REJECTED', 'READY_FOR_REVIEW'):
        fail('Nella richiesta mi aspettavo solo la versione dell\'app, respinta: trovo altro, quindi non tocco niente.')
    item = vers[0]
    vid = item['relationships']['appStoreVersion']['data']['id']
    ver = call('GET', '/v1/appStoreVersions/' + vid)['data']
    b = call('GET', '/v1/appStoreVersions/%s/build' % vid).get('data')
    note('notice', tit, 'versione %s: %s; build scelta: %s' % (ver['attributes'].get('versionString'), state(ver), b['attributes'].get('version') if b else 'nessuna'))
    if not b:
        fail('La versione non ha una build scelta: non reinvio.')
    det = call('GET', '/v1/appStoreVersions/%s/appStoreReviewDetail' % vid).get('data')
    if not det:
        fail('La versione non ha i dati per la revisione: compilali in App Store Connect, poi rilancia.')
    vecchie = ((det.get('attributes') or {}).get('notes') or '').strip()
    cambia = vecchie != nuove
    note('notice', tit, 'note per la revisione: adesso %d caratteri, %s le risposte sulla categoria Bambini; %s' % (
        len(vecchie), 'con' if 'Guideline 1.3' in vecchie else 'senza',
        'da sostituire con quelle nuove (%d caratteri)' % len(nuove) if cambia else 'già quelle nuove'))
    if not davvero:
        note('notice', tit, 'Prova finita, non ho cambiato niente. Il reinvio vero: %selemento segnato come risolto, richiesta inviata di nuovo.' % ('note nuove, ' if cambia else ''))
        return
    if cambia:
        call('PATCH', '/v1/appStoreReviewDetails/' + det['id'], {'data': {'type': 'appStoreReviewDetails', 'id': det['id'], 'attributes': {'notes': nuove}}})
        note('notice', tit, 'note per la revisione aggiornate')
    if state(item) == 'REJECTED':
        call('PATCH', '/v1/reviewSubmissionItems/' + item['id'], {'data': {'type': 'reviewSubmissionItems', 'id': item['id'], 'attributes': {'resolved': True}}})
        note('notice', tit, 'elemento segnato come risolto')
    call('PATCH', '/v1/reviewSubmissions/' + sub['id'], {'data': {'type': 'reviewSubmissions', 'id': sub['id'], 'attributes': {'submitted': True}}})
    time.sleep(5)
    s2 = call('GET', '/v1/reviewSubmissions/' + sub['id'])['data']
    v2 = call('GET', '/v1/appStoreVersions/' + vid)['data']
    note('notice', 'Reinviata', 'richiesta %s: %s; versione %s: %s' % (sub['id'], state(s2), v2['attributes'].get('versionString'), state(v2)))


def invia(T, davvero):
    """--invia: sends the version being prepared to App Review, as the version page of App Store Connect does: it picks the
    newest build of that version that Apple has finished checking, writes T['note_revisione'] in the review notes, sets the
    release (USCITA: a date, e.g. 2026-12-08, for a scheduled release at 9:00 Italian time; empty: as soon as it is approved),
    then adds the version to a review submission and submits it. Without davvero it changes nothing and says what it would do."""
    tit = 'Invio' if davvero else 'Prova dell\'invio'
    want = os.environ.get('VERSIONE', '').strip() or T.get('versione', '')
    notes = (T.get('note_revisione') or '').strip()
    if not want:
        fail('Manca la versione da inviare: VERSIONE o «versione» in testi.json.')
    if 'Guideline 1.3' not in notes:
        fail('In testi.json mancano le note per la revisione con le risposte sulla categoria Bambini (note_revisione): senza, non invio.')
    app = find_app(T)['id']
    vers = [v for v in items('/v1/apps/%s/appStoreVersions' % app, {'filter[platform]': 'IOS'}) if v['attributes'].get('versionString') == want]
    if not vers:
        fail('La versione %s non c\'è ancora in App Store Connect: prima si compila la scheda (flusso «Scheda App Store»).' % want)
    ver = vers[0]
    if state(ver) not in EDITABLE - {'INVALID_BINARY'}:
        fail('La versione %s è %s: adesso non si può inviare.' % (want, state(ver)))
    rows = call('GET', '/v1/builds', query={'filter[app]': app, 'filter[preReleaseVersion.version]': want, 'filter[processingState]': 'VALID',
                                            'sort': '-uploadedDate', 'limit': 1}).get('data') or []
    if not rows:
        fail('Per la versione %s Apple non ha ancora una build pronta (VALID): si carica con il flusso «App per iPhone» e si aspetta che Apple finisca di controllarla.' % want)
    build = rows[0]
    try:
        det = call('GET', '/v1/appStoreVersions/%s/appStoreReviewDetail' % ver['id']).get('data')
    except Apple:
        det = None
    uscita = os.environ.get('USCITA', '').strip() or T.get('uscita', '')
    if uscita and not re.match(r'^\d{4}-\d{2}-\d{2}$', uscita):
        fail('USCITA deve essere una data come 2026-12-08, non «%s».' % uscita)
    quando = ('il %s alle 9:00 (ora italiana), se approvata prima; altrimenti appena approvata' % uscita) if uscita else 'appena approvata'
    subs = [x for x in items('/v1/reviewSubmissions', {'filter[app]': app, 'filter[platform]': 'IOS'}) if state(x) in ('READY_FOR_REVIEW', 'WAITING_FOR_REVIEW', 'IN_REVIEW', 'UNRESOLVED_ISSUES')]
    busy = [x for x in subs if state(x) != 'READY_FOR_REVIEW']
    if busy:
        fail('C\'è già una richiesta di revisione %s: non ne apro un\'altra.' % state(busy[0]))
    note('notice', tit, 'versione %s (%s): build %s; note per la revisione %d caratteri (dati di contatto %s); uscita %s.' % (
        want, state(ver), build['attributes'].get('version'), len(notes), 'già presenti' if det else 'MANCANTI', quando))
    if not det:
        fail('La versione %s non ha ancora le informazioni per la revisione (nome, telefono, email di contatto): vanno messe una volta in App Store Connect, pagina della versione, sezione «Informazioni per la revisione».' % want)
    if not davvero:
        note('notice', tit, 'nessuna modifica: con un push sul ramo invia-asc sceglie la build, scrive le note, imposta l\'uscita e invia la versione %s alla revisione.' % want)
        return
    call('PATCH', '/v1/appStoreVersions/%s/relationships/build' % ver['id'], rel('builds', build['id']))
    call('PATCH', '/v1/appStoreReviewDetails/' + det['id'], {'data': {'type': 'appStoreReviewDetails', 'id': det['id'], 'attributes': {'notes': notes}}})
    attrs = {'releaseType': 'SCHEDULED', 'earliestReleaseDate': uscita + 'T08:00:00Z'} if uscita else {'releaseType': 'AFTER_APPROVAL'}
    call('PATCH', '/v1/appStoreVersions/' + ver['id'], {'data': {'type': 'appStoreVersions', 'id': ver['id'], 'attributes': attrs}})
    note('notice', tit, 'build %s scelta, note scritte, uscita: %s' % (build['attributes'].get('version'), quando))
    sub = subs[0] if subs else call('POST', '/v1/reviewSubmissions', {'data': {'type': 'reviewSubmissions', 'attributes': {'platform': 'IOS'},
                                                                                'relationships': {'app': rel('apps', app)}}})['data']
    have = call('GET', '/v1/reviewSubmissions/%s/items' % sub['id'], query={'include': 'appStoreVersion', 'limit': 20}).get('data') or []
    if not any((((x.get('relationships') or {}).get('appStoreVersion') or {}).get('data') or {}).get('id') == ver['id'] for x in have):
        call('POST', '/v1/reviewSubmissionItems', {'data': {'type': 'reviewSubmissionItems', 'relationships': {
            'reviewSubmission': rel('reviewSubmissions', sub['id']), 'appStoreVersion': rel('appStoreVersions', ver['id'])}}})
    call('PATCH', '/v1/reviewSubmissions/' + sub['id'], {'data': {'type': 'reviewSubmissions', 'id': sub['id'], 'attributes': {'submitted': True}}})
    time.sleep(5)
    s2 = call('GET', '/v1/reviewSubmissions/' + sub['id'])['data']
    v2 = call('GET', '/v1/appStoreVersions/' + ver['id'])['data']
    note('notice', 'Inviata', 'richiesta %s: %s; versione %s: %s' % (sub['id'], state(s2), want, state(v2)))


def candida(T, davvero):
    """--candida: nominates the new version for an App Store feature, as App Store Connect → Featuring → Nominations does.
    Apple asks for nominations at least three weeks before the publishing date, which is the release date of testi.json.
    A nomination of the same name that is already there is not sent twice."""
    tit = 'Candidatura' if davvero else 'Prova della candidatura'
    C = T.get('candidatura') or {}
    uscita = os.environ.get('USCITA', '').strip() or T.get('uscita', '')
    if not (C.get('name') and C.get('description') and uscita):
        fail('In testi.json mancano la candidatura (nome e descrizione) o la data d\'uscita: senza, non candido.')
    giorni = (time.mktime(time.strptime(uscita, '%Y-%m-%d')) - time.time()) / 86400
    app = find_app(T)['id']
    old = []
    for st in ('DRAFT', 'SUBMITTED'):
        try:
            old += items('/v1/nominations', {'filter[state]': st, 'filter[relatedApps]': app})
        except Apple as e:
            note('warning', tit, 'candidature esistenti non lette: %s' % e)
    same = [x for x in old if (x.get('attributes') or {}).get('name') == C['name']]
    if same and state(same[0]) == 'SUBMITTED':
        note('notice', tit, 'la candidatura «%s» è già stata inviata il %s: non la rimando.' % (C['name'], ((same[0]['attributes'].get('submittedDate')) or '-')[:10]))
        return
    locales = sorted(T['lingue'])
    attrs = {'name': C['name'], 'type': C.get('type', 'APP_ENHANCEMENTS'), 'description': C['description'], 'notes': C.get('notes') or None,
             'publishStartDate': uscita + 'T08:00:00Z', 'deviceFamilies': ['IPHONE'], 'locales': locales,
             'hasInAppEvents': False, 'launchInSelectMarketsFirst': False, 'preOrderEnabled': False, 'submitted': bool(davvero)}
    note('notice', tit, '%s «%s», uscita %s (fra %d giorni%s), %d lingue, descrizione %d caratteri, note %d.' % (
        attrs['type'], C['name'], uscita, giorni, '' if giorni >= 21 else ': Apple chiede almeno tre settimane, la candidatura vale lo stesso ma ha meno probabilità',
        len(locales), len(C['description']), len(C.get('notes') or '')))
    if not davvero:
        note('notice', tit, 'nessuna modifica: con un push sul ramo candida-asc la candidatura viene inviata ad Apple.')
        return
    if same:
        nid = same[0]['id']
        a2 = {k: v for k, v in attrs.items() if k != 'type'}
        call('PATCH', '/v1/nominations/' + nid, {'data': {'type': 'nominations', 'id': nid, 'attributes': a2}})
    else:
        nid = call('POST', '/v1/nominations', {'data': {'type': 'nominations', 'attributes': attrs,
                                                         'relationships': {'relatedApps': {'data': [{'type': 'apps', 'id': app}]}}}})['data']['id']
    n2 = call('GET', '/v1/nominations/' + nid)['data']
    note('notice', 'Candidatura inviata', '«%s»: %s' % (C['name'], state(n2)))


def main():
    for k in ('APPSTORE_KEY_ID', 'APPSTORE_ISSUER_ID', 'APPSTORE_P8'):
        if not os.environ.get(k, '').strip():
            fail('Manca il segreto %s: aggiungilo in Settings → Secrets and variables → Actions del repository (passo C1).' % k)
    T = json.load(open(os.path.join(DIR, 'testi.json'), encoding='utf-8'))
    if '--stato' in sys.argv[2:]:
        return stato(T)
    if '--reinvia' in sys.argv[2:]:
        return reinvia(T, '--davvero' in sys.argv[2:])
    if '--invia' in sys.argv[2:]:
        return invia(T, '--davvero' in sys.argv[2:])
    if '--candida' in sys.argv[2:]:
        return candida(T, '--davvero' in sys.argv[2:])
    shots = {}
    for loc, L in T['lingue'].items():
        files = sorted(glob.glob(os.path.join(DIR, 'schermate', L['schermate'], '*.png')))
        if not files:
            fail('Mancano le schermate nella cartella scheda/schermate/%s.' % L['schermate'])
        shots[loc] = files

    found = find_app(T)
    app = found['id']
    print('App:', found['attributes'].get('name'), app, flush=True)

    # app information: categories, then name, subtitle, privacy URL in every language
    infos = [x for x in items('/v1/apps/%s/appInfos' % app) if state(x) in EDITABLE]
    if not infos:
        fail('Le informazioni dell\'app adesso non si possono modificare (app in revisione o già pubblicata senza una versione nuova).')
    info = infos[0]['id']
    call('PATCH', '/v1/appInfos/' + info, {'data': {'type': 'appInfos', 'id': info, 'relationships': {k: rel('appCategories', v) for k, v in T['categorie'].items()}}})
    print('Categorie:', ', '.join(T['categorie'].values()), flush=True)
    have = {x['attributes']['locale']: x['id'] for x in items('/v1/appInfos/%s/appInfoLocalizations' % info)}
    for loc, L in T['lingue'].items():
        _, what = upsert('appInfoLocalizations', have, loc, {'name': L['name'], 'subtitle': L['subtitle'], 'privacyPolicyUrl': T['url']['privacy']}, 'appInfo', 'appInfos', info)
        print('%-8s nome e sottotitolo: %s' % (loc, what), flush=True)

    # the version being prepared: copyright, texts, screenshots
    want = os.environ.get('VERSIONE', '').strip() or T.get('versione', '')
    every = items('/v1/apps/%s/appStoreVersions' % app, {'filter[platform]': 'IOS'})
    vers = [v for v in every if state(v) in EDITABLE and (not want or v['attributes'].get('versionString') == want)]
    if not vers and want and not any(v['attributes'].get('versionString') == want for v in every):
        if any(state(v) in EDITABLE or state(v) in ('WAITING_FOR_REVIEW', 'IN_REVIEW', 'PENDING_DEVELOPER_RELEASE') for v in every):
            fail('Non creo la versione %s: un\'altra versione è ancora in preparazione o in revisione.' % want)
        vers = [call('POST', '/v1/appStoreVersions', {'data': {'type': 'appStoreVersions', 'attributes': {'platform': 'IOS', 'versionString': want},
                                                                'relationships': {'app': rel('apps', app)}}})['data']]
        note('notice', 'Versione ' + want, 'creata in App Store Connect: testi e schermate di quella precedente vengono riscritti con quelli di scheda/')
    if not vers:
        fail('Non c\'è nessuna versione %sin preparazione per iPhone: in App Store Connect crea la versione (+ accanto a «App iOS»), poi rilancia.' % (want + ' ' if want else ''))
    ver = vers[0]
    print('Versione:', ver['attributes'].get('versionString'), state(ver), flush=True)
    call('PATCH', '/v1/appStoreVersions/' + ver['id'], {'data': {'type': 'appStoreVersions', 'id': ver['id'], 'attributes': {'copyright': T['copyright']}}})
    have = {x['attributes']['locale']: x['id'] for x in items('/v1/appStoreVersions/%s/appStoreVersionLocalizations' % ver['id'])}
    vloc = {}
    for loc, L in T['lingue'].items():
        attrs = {'description': L['description'], 'keywords': L['keywords'], 'promotionalText': L['promotionalText'], 'supportUrl': T['url']['support']}
        if L.get('whatsNew') and ver['attributes'].get('versionString') != '1.0':      # Apple refuses «What's New» on the first version
            attrs['whatsNew'] = L['whatsNew']
        try:
            vloc[loc], what = upsert('appStoreVersionLocalizations', have, loc, attrs, 'appStoreVersion', 'appStoreVersions', ver['id'])
        except Apple as e:
            short = first_keywords(L['keywords'])
            if 'keywords' not in str(e) or short == L['keywords']:
                raise
            vloc[loc], what = upsert('appStoreVersionLocalizations', have, loc, dict(attrs, keywords=short), 'appStoreVersion', 'appStoreVersions', ver['id'])
            note('warning', 'Parole chiave', '%s: Apple ha rifiutato le parole chiave così lunghe, ho messo solo le prime %d. Risposta di Apple: %s' % (loc, short.count(',') + 1, e))
        print('%-8s descrizione e parole chiave: %s' % (loc, what), flush=True)

    sent, same, pending = 0, 0, []
    for loc, files in shots.items():
        sets = items('/v1/appStoreVersionLocalizations/%s/appScreenshotSets' % vloc[loc])
        s = next((x for x in sets if x['attributes'].get('screenshotDisplayType') == DISPLAY), None)
        if s is None:
            s = call('POST', '/v1/appScreenshotSets', {'data': {'type': 'appScreenshotSets', 'attributes': {'screenshotDisplayType': DISPLAY},
                                                                 'relationships': {'appStoreVersionLocalization': rel('appStoreVersionLocalizations', vloc[loc])}}})['data']
        old = items('/v1/appScreenshotSets/%s/appScreenshots' % s['id'])
        sums = [md5(f) for f in files]
        if [x['attributes'].get('sourceFileChecksum') for x in old] == sums and all(((x['attributes'].get('assetDeliveryState') or {}).get('state')) == 'COMPLETE' for x in old):
            same += len(files)
            print('%-8s schermate: già queste' % loc, flush=True)
            continue
        for x in old:
            call('DELETE', '/v1/appScreenshots/' + x['id'])
        ids = [upload(s['id'], f, h) for f, h in zip(files, sums)]
        sent += len(ids)
        pending.append((loc, s['id'], ids))
        print('%-8s schermate: %d inviate' % (loc, len(ids)), flush=True)

    # Apple checks every image: wait for the verdict, then fix the order
    deadline, late = time.time() + 900, []
    for loc, set_id, ids in pending:
        while True:
            now = {x['id']: x for x in items('/v1/appScreenshotSets/%s/appScreenshots' % set_id)}
            st = {i: ((now.get(i, {}).get('attributes') or {}).get('assetDeliveryState') or {}) for i in ids}
            bad = [(i, v) for i, v in st.items() if v.get('state') == 'FAILED']
            if bad:
                why = '; '.join(' '.join(filter(None, (e.get('code'), e.get('description') or e.get('detail')))) for _, v in bad for e in (v.get('errors') or [])) or 'motivo non indicato'
                fail('Apple ha scartato %s di %s: %s' % ('1 schermata' if len(bad) == 1 else '%d schermate' % len(bad), loc, why))
            if all(v.get('state') == 'COMPLETE' for v in st.values()):
                break
            if time.time() > deadline:
                late.append(loc)
                break
            time.sleep(float(os.environ.get('ASC_POLL', 8)))
        if [x for x in now if x in ids] != ids:
            call('PATCH', '/v1/appScreenshotSets/%s/relationships/appScreenshots' % set_id, {'data': [{'type': 'appScreenshots', 'id': i} for i in ids]})
    if late:
        note('warning', 'Schermate', 'Apple sta ancora controllando le schermate di: %s. Di solito finisce da sola; se in App Store Connect restano vuote, rilancia il flusso.' % ', '.join(late))

    langs = len(T['lingue'])
    note('notice', 'Scheda compilata', '%d lingue: testi, categorie e copyright a posto; schermate inviate %d, già presenti %d.' % (langs, sent, same))
    builds(app, ver['attributes'].get('versionString'))
    out = os.environ.get('GITHUB_STEP_SUMMARY')
    if out:
        with open(out, 'a', encoding='utf-8') as f:
            f.write('## Scheda App Store compilata\n\n| Lingua | Nome | Sottotitolo | Schermate |\n| --- | --- | --- | --- |\n')
            for loc, L in T['lingue'].items():
                f.write('| %s | %s | %s | %d |\n' % (loc, L['name'], L['subtitle'], len(shots[loc])))
            f.write('\nRestano a mano in App Store Connect: classificazione per età, diritti sui contenuti, prezzo e disponibilità, privacy dell\'app, dati per la revisione, build e invio.\n')


if __name__ == '__main__':
    try:
        main()
    except Apple as e:
        fail(str(e))
    except Exception as e:            # the full log cannot be read from outside: say where it broke
        import traceback
        at = traceback.extract_tb(e.__traceback__)[-1]
        fail('Errore inatteso in %s, riga %d (%s): %s: %s' % (os.path.basename(at.filename), at.lineno, at.name, type(e).__name__, e))
