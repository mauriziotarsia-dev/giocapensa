#!/usr/bin/env python3
"""Builds the scheda/ folder of the repository, read by the workflow «Scheda App Store»:
testi.json (texts of scheda.py for the 14 App Store languages), carica.py and the 6.9-inch screenshots.
usage: python3 src/store/prepara_scheda.py <screenshots: one folder per language, e.g. en/1-home.png> <output folder, e.g. scheda>
"""
import glob, json, os, runpy, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC, OUT = sys.argv[1], sys.argv[2]
G = runpy.run_path(os.path.join(HERE, 'scheda.py'))          # prints the length check
if G['bad']:
    sys.exit('scheda.py: testi da sistemare')
S = G['S']
# App Store language -> texts of scheda.py; varieties without their own text reuse a close one
LOCALES = [('en-GB', 'en'), ('en-US', 'en-US'), ('en-CA', 'en-US'), ('it', 'it'), ('es-ES', 'es'), ('es-MX', 'es'),
           ('pt-BR', 'pt'), ('pt-PT', 'pt'), ('fr-FR', 'fr'), ('fr-CA', 'fr'), ('de-DE', 'de'), ('ja', 'ja'),
           ('zh-Hans', 'zh-Hans'), ('zh-Hant', 'zh-Hant')]
T = {
    'bundle': 'dev.tarsia.giocapensa',
    'copyright': '2026 Maurizio Tarsia',
    'categorie': {'primaryCategory': 'GAMES', 'primarySubcategoryOne': 'GAMES_PUZZLE', 'primarySubcategoryTwo': 'GAMES_FAMILY', 'secondaryCategory': 'EDUCATION'},
    'url': {'support': 'https://mauriziotarsia-dev.github.io/giocapensa/info.html?store',
            'privacy': 'https://mauriziotarsia-dev.github.io/giocapensa/privacy.html?store'},
    'lingue': {loc: {'name': S[k]['name'], 'subtitle': S[k]['subtitle'], 'promotionalText': S[k]['promo'],
                     'description': S[k]['description'], 'keywords': S[k]['keywords'], 'schermate': S[k]['shots']}
               for loc, k in LOCALES},
}
if os.path.isdir(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)
with open(os.path.join(OUT, 'testi.json'), 'w', encoding='utf-8') as f:
    json.dump(T, f, ensure_ascii=False, indent=1)
    f.write('\n')
shutil.copy(os.path.join(HERE, 'carica.py'), OUT)
for lg in sorted({L['schermate'] for L in T['lingue'].values()}):
    files = sorted(glob.glob(os.path.join(SRC, lg, '*.png')))
    if len(files) != 7:
        sys.exit('servono 7 schermate in %s, ce ne sono %d' % (os.path.join(SRC, lg), len(files)))
    os.makedirs(os.path.join(OUT, 'schermate', lg))
    for p in files:
        shutil.copy(p, os.path.join(OUT, 'schermate', lg, os.path.basename(p)))
print('scheda pronta:', len(T['lingue']), 'lingue,', len(glob.glob(os.path.join(OUT, 'schermate', '*', '*.png'))), 'schermate')
