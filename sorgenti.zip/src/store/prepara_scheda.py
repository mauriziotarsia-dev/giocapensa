#!/usr/bin/env python3
"""Builds the scheda/ folder of the repository, read by the workflow «Scheda App Store»:
testi.json (texts of scheda.py for the 14 App Store languages), carica.py and the 6.9-inch screenshots.
usage: python3 src/store/prepara_scheda.py <screenshots: one folder per language, e.g. en/1-home.png> <output folder, e.g. scheda>
"""
import glob, json, os, runpy, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC, OUT = sys.argv[1], sys.argv[2]
G = runpy.run_path(os.path.join(HERE, 'scheda.py'))          # prints the length check
if G['bad']:
    sys.exit('scheda.py: testi da sistemare')
S = G['S']
# notes for App Review (version page → App Review Information → Notes); they also answer the four questions
# Apple asks automatically about the Kids Category. carica.py --reinvia writes them; Apple's limit is 4000 characters.
NOTE_REVISIONE = '\n\n'.join([
    'Giocapensa is a set of six logic games for children aged 3 to 5 who cannot read yet. Everything runs locally from files bundled '
    'in the app: there is no login, no network access, no ads, no in-app purchases and no data collection; progress is stored only on '
    'the device. The app contains 640 generated and verified puzzle levels and works fully offline.',
    'Where the law requires age assurance (for example in Texas), the app calls Apple\'s Declared Age Range API once at launch '
    '(isEligibleForAgeFeatures, then requestAgeRange). The answer stays on the device and is not stored, and no feature depends on it, '
    'since all content is for young children.',
    'The voice in the Stickers game (it names the stickers, says where they go and counts them) uses the speech voices built into iOS. '
    'The gear icon on the home screen opens the settings (sounds, music, voice, language, help) and the in-app privacy and information '
    'pages; nothing links outside the app.',
    'Kids Category (Guideline 1.3): no third-party analytics, no advertising, no data shared with third parties, and no user or device '
    'data collected for any purpose. The only third-party components are the open-source Capacitor runtime (MIT) and the bundled '
    'Overpass typeface (SIL OFL), neither of which collects anything. App Privacy: Data Not Collected.',
])
if len(NOTE_REVISIONE) > 3800:                               # room for the line carica.py adds when resubmitting
    sys.exit('note per la revisione troppo lunghe: %d caratteri' % len(NOTE_REVISIONE))
VERSIONE = '1.1'                                              # the version the workflows fill, build and send (scheda/testi.json)
USCITA = '2026-12-10'                                         # scheduled release of that version (empty: as soon as Apple approves it)
# nomination for an App Store feature (App Store Connect → Featuring → Nominations), read by carica.py --candida;
# Apple's editors read it, so it is in English; it says nothing personal (the repository is public)
CANDIDATURA = {
    'type': 'NEW_CONTENT',
    'name': 'Giocapensa 1.1: the winter mountain',
    'description': ('Giocapensa is a set of six logic games for children aged 3 to 5 who cannot read yet. Version 1.1 adds a sixth scene '
                    'to the Stickers game: a winter mountain with a cable car, a snowplough, a snowcat, a sledge, a snowman, a mountain '
                    'goat, a fox and falling snow. Children put each sticker on its shadow, in its place, by counting, or where a gentle '
                    'voice asks ("Put the fox under the fir tree"), in nine languages. No ads, no in-app purchases, no data collected, '
                    'fully offline.'),
    'notes': ('Made for the Kids Category from the start: nothing links outside the app and there are no third-party SDKs. Each of the '
              '640 puzzle levels in the other five games is generated and checked by a solver, so every level has a true minimum '
              'number of moves. No timers, no lives, no game over: every level is open, and the Help button is earned after a few tries. '
              'The voice uses the speech voices built into iOS, and it can speak a different language from the written one.'),
}
SCHERMATE = 8                                                 # screenshots per language, made by schermate.py
# App Store language -> texts of scheda.py; varieties without their own text reuse a close one
LOCALES = [('en-GB', 'en'), ('en-US', 'en-US'), ('en-CA', 'en-US'), ('it', 'it'), ('es-ES', 'es'), ('es-MX', 'es'),
           ('pt-BR', 'pt'), ('pt-PT', 'pt'), ('fr-FR', 'fr'), ('fr-CA', 'fr'), ('de-DE', 'de'), ('ja', 'ja'),
           ('zh-Hans', 'zh-Hans'), ('zh-Hant', 'zh-Hant')]
T = {
    'bundle': 'dev.tarsia.giocapensa',
    'versione': VERSIONE,
    'uscita': USCITA,
    'candidatura': CANDIDATURA,
    'copyright': '2026 Maurizio Tarsia',
    'categorie': {'primaryCategory': 'GAMES', 'primarySubcategoryOne': 'GAMES_PUZZLE', 'primarySubcategoryTwo': 'GAMES_FAMILY', 'secondaryCategory': 'EDUCATION'},
    'url': {'support': 'https://mauriziotarsia-dev.github.io/giocapensa/info.html?store',
            'privacy': 'https://mauriziotarsia-dev.github.io/giocapensa/privacy.html?store'},
    'lingue': {loc: {'name': S[k]['name'], 'subtitle': S[k]['subtitle'], 'promotionalText': S[k]['promo'],
                     'description': S[k]['description'], 'keywords': S[k]['keywords'], 'whatsNew': S[k]['novita'], 'schermate': S[k]['shots']}
               for loc, k in LOCALES},
    'note_revisione': NOTE_REVISIONE,
}
if os.path.isdir(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)
with open(os.path.join(OUT, 'testi.json'), 'w', encoding='utf-8') as f:
    json.dump(T, f, ensure_ascii=False, indent=1)
    f.write('\n')
shutil.copy(os.path.join(HERE, 'carica.py'), OUT)
for lg in sorted({L['schermate'] for L in T['lingue'].values()}):
    files = sorted(glob.glob(os.path.join(SRC, lg, '*.png')))
    if len(files) != SCHERMATE:
        sys.exit('servono %d schermate in %s, ce ne sono %d' % (SCHERMATE, os.path.join(SRC, lg), len(files)))
    os.makedirs(os.path.join(OUT, 'schermate', lg))
    for p in files:
        shutil.copy(p, os.path.join(OUT, 'schermate', lg, os.path.basename(p)))
print('scheda pronta:', len(T['lingue']), 'lingue,', len(glob.glob(os.path.join(OUT, 'schermate', '*', '*.png'))), 'schermate')
