#!/usr/bin/env python3
"""Builds the scheda/ folder of the repository, read by the workflow «Scheda App Store»:
testi.json (texts of scheda.py for the 14 App Store languages), carica.py and the 6.9-inch screenshots.
usage: python3 src/store/prepara_scheda.py <screenshots: one folder per language, e.g. en/1-home.png> <output folder, e.g. scheda>
"""
import glob, json, os, runpy, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC, OUT = sys.argv[1], sys.argv[2]
G = runpy.run_path(os.path.join(HERE, 'scheda.py'))          # prints the length check
if G['bad']:
    sys.exit('scheda.py: testi da sistemare')
S = G['S']
# notes for App Review (version page → App Review Information → Notes); they also answer the four questions
# Apple asks automatically about the Kids Category. carica.py --reinvia writes them; Apple's limit is 4000 characters.
NOTE_REVISIONE = '\n\n'.join([
    'Giocapensa is a set of six logic games for children aged 3 to 5 who cannot read yet. Everything runs locally from files bundled '
    'in the app: there is no login, no network access, no ads, no in-app purchases and no data collection; progress is stored only on '
    'the device. The app contains 640 generated and verified puzzle levels and works fully offline.',
    'Where the law requires age assurance (for example in Texas), the app calls Apple\'s Declared Age Range API once at launch '
    '(isEligibleForAgeFeatures, then requestAgeRange). The answer stays on the device and is not stored, and no feature depends on it, '
    'since all content is for young children.',
    'The voice in the Stickers game (it names the stickers, says where they go and counts them) uses the speech voices built into iOS. '
    'The gear icon on the home screen opens the settings (sounds, music, voice, language, help) and the in-app privacy and information '
    'pages; nothing links outside the app.',
    'Kids Category (Guideline 1.3): no third-party analytics, no advertising, no data shared with third parties, and no user or device '
    'data collected for any purpose. The only third-party components are the open-source Capacitor runtime (MIT) and the bundled '
    'Overpass typeface (SIL OFL), neither of which collects anything. App Privacy: Data Not Collected.',
])
if len(NOTE_REVISIONE) > 3800:                               # room for the line carica.py adds when resubmitting
    sys.exit('note per la revisione troppo lunghe: %d caratteri' % len(NOTE_REVISIONE))
# App Store language -> texts of scheda.py; varieties without their own text reuse a close one
LOCALES = [('en-GB', 'en'), ('en-US', 'en-US'), ('en-CA', 'en-US'), ('it', 'it'), ('es-ES', 'es'), ('es-MX', 'es'),
           ('pt-BR', 'pt'), ('pt-PT', 'pt'), ('fr-FR', 'fr'), ('fr-CA', 'fr'), ('de-DE', 'de'), ('ja', 'ja'),
           ('zh-Hans', 'zh-Hans'), ('zh-Hant', 'zh-Hant')]
T = {
    'bundle': 'dev.tarsia.giocapensa',
    'copyright': '2026 Maurizio Tarsia',
    'categorie': {'primaryCategory': 'GAMES', 'primarySubcategoryOne': 'GAMES_PUZZLE', 'primarySubcategoryTwo': 'GAMES_FAMILY', 'secondaryCategory': 'EDUCATION'},
    'url': {'support': 'https://mauriziotarsia-dev.github.io/giocapensa/info.html?store',
            'privacy': 'https://mauriziotarsia-dev.github.io/giocapensa/privacy.html?store'},
    'lingue': {loc: {'name': S[k]['name'], 'subtitle': S[k]['subtitle'], 'promotionalText': S[k]['promo'],
                     'description': S[k]['description'], 'keywords': S[k]['keywords'], 'schermate': S[k]['shots']}
               for loc, k in LOCALES},
    'note_revisione': NOTE_REVISIONE,
}
if os.path.isdir(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)
with open(os.path.join(OUT, 'testi.json'), 'w', encoding='utf-8') as f:
    json.dump(T, f, ensure_ascii=False, indent=1)
    f.write('\n')
shutil.copy(os.path.join(HERE, 'carica.py'), OUT)
for lg in sorted({L['schermate'] for L in T['lingue'].values()}):
    files = sorted(glob.glob(os.path.join(SRC, lg, '*.png')))
    if len(files) != 7:
        sys.exit('servono 7 schermate in %s, ce ne sono %d' % (os.path.join(SRC, lg), len(files)))
    os.makedirs(os.path.join(OUT, 'schermate', lg))
    for p in files:
        shutil.copy(p, os.path.join(OUT, 'schermate', lg, os.path.basename(p)))
print('scheda pronta:', len(T['lingue']), 'lingue,', len(glob.glob(os.path.join(OUT, 'schermate', '*', '*.png'))), 'schermate')
