"""App Store screenshots, 6.9" (1320 x 2868), one set per language, from the app's own pages (typeface included).
   usage: python3 schermate.py <folder with the app pages> <output folder> <langs> [scene]"""
import json, os, subprocess, sys, time
from playwright.sync_api import sync_playwright
ROOT, OUT, LANGS = sys.argv[1], sys.argv[2], sys.argv[3].split(',')
SCENE = sys.argv[4] if len(sys.argv) > 4 else 'stazione'
MODE = sys.argv[5] if len(sys.argv) > 5 else 'sagome'
DIFF = sys.argv[6] if len(sys.argv) > 6 else '2'
ONLY = sys.argv[7].split(',') if len(sys.argv) > 7 else None
KEEP = int(sys.argv[8]) if len(sys.argv) > 8 else 1
PORT = 8781
SEED = r"""
(function () { var s = 20261016; Math.random = function () { s |= 0; s = s + 0x6D2B79F5 | 0; var t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; })();
try {
  var put = function (k, v) { localStorage.setItem(k, JSON.stringify(v)); };
  put('giocapensa.opzioni', { ui: %(lang)s, lingua: 'app' });
  put('via-libera.v2', { saves: { a1: { id: 'a1', name: 'Leo', created: 1, updated: 2, level: 41, skin: 'pastel', best: {}, board: null, deleted: false } }, active: 'a1' });
  put('palline.v1', { best: {}, last: 95 });
  put('labirinti.v1', { best: {}, last: 58 });
  put('acqua.v2', { best: {}, last: 64 });
  put('incastri.v1', { best: {}, last: 109 });
  put('adesivi.scene.v1', { rounds: {}, mode: %(mode)s, diff: %(diff)s });
} catch (e) {}
"""
TARGETS = r"""() => {
  const R = window.__AD.state().R, out = [];
  R.targets.forEach((t, i) => {
    if (t.done) return;
    const sh = document.querySelector('#silG [data-t="' + i + '"]');
    const tile = [...document.querySelectorAll('.tile[data-id="' + t.id + '"]')].find(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.left >= 0 && r.right <= innerWidth; });
    if (sh && tile) { const a = tile.getBoundingClientRect(), b = sh.getBoundingClientRect(); out.push({ i: i, id: t.id, from: [a.left + a.width / 2, a.top + a.height / 2], to: [b.left + b.width / 2, b.top + b.height / 2] }); }
  });
  return out;
}"""
srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '-d', ROOT], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        for lg in LANGS:
            d = os.path.join(OUT, lg); os.makedirs(d, exist_ok=True)
            ctx = b.new_context(viewport={'width': int(os.environ.get('SHOT_W', 440)), 'height': int(os.environ.get('SHOT_H', 956))}, device_scale_factor=3, locale='en-GB', color_scheme='light', has_touch=False, reduced_motion='reduce')
            ctx.add_init_script(SEED % {'lang': json.dumps(lg), 'mode': json.dumps(MODE), 'diff': json.dumps(DIFF)})
            errs = []
            for i, name in enumerate(('index', 'via-libera', 'palline', 'labirinti', 'acqua', 'incastri', 'adesivi'), 1):
                if ONLY and name not in ONLY: continue
                pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
                pg.goto('http://localhost:%d/%s.html' % (PORT, name)); pg.wait_for_timeout(900)
                pg.evaluate('document.fonts.ready')
                if name == 'adesivi':
                    pg.click('.scn[data-s="%s"]' % SCENE); pg.wait_for_timeout(1200)
                    left = pg.evaluate("() => window.__AD.state().R.targets.filter(t => !t.done).length") if MODE == 'sagome' else 0
                    for attempt in range(40):
                        if left <= KEEP: break
                        ts = pg.evaluate(TARGETS)
                        if not ts:
                            pg.click('#btnTrayNext'); pg.wait_for_timeout(500); continue
                        t = ts[0]
                        pg.mouse.move(*t['from']); pg.mouse.down(); pg.mouse.move(t['to'][0], t['to'][1], steps=12); pg.mouse.up(); pg.wait_for_timeout(900)
                        left = pg.evaluate("() => window.__AD.state().R.targets.filter(t => !t.done).length")
                    pg.wait_for_timeout(600)
                pg.screenshot(path=os.path.join(d, '%d-%s%s.png' % (i, name, ('-' + SCENE + '-' + MODE + DIFF) if (ONLY and name == 'adesivi') else '')))
                pg.close()
            ctx.close()
            print(lg, 'errori:', errs)
        b.close()
finally:
    srv.terminate()
