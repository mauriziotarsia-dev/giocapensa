"""App Store screenshots, 6.9" (1320 x 2868), one set per language: each page of the app (typeface included)
   framed on a coloured background with a caption on top, written for the grown-up who reads the listing.
   usage: python3 schermate.py <folder with the app pages (prepara_www.py)> <output folder> <langs>
   The pages as they are, without caption, are kept in <output folder>/grezze/<lang>/."""
import base64, json, os, subprocess, sys, time
from playwright.sync_api import sync_playwright
ROOT, OUT, LANGS = sys.argv[1], sys.argv[2], sys.argv[3].split(',')
PORT = 8781
INK = '#4A3B52'

# (file, page, background, caption by language: title, line under it)
SHOTS = [
  ('1-home', 'index', '#FFE9A8'),
  ('2-adesivi', 'adesivi', '#CDEBFF'),
  ('3-via-libera', 'via-libera', '#FFD9C7'),
  ('4-palline', 'palline', '#D4F0CF'),
  ('5-labirinti', 'labirinti', '#FFE0B8'),
  ('6-acqua', 'acqua', '#CFF1F2'),
  ('7-incastri', 'incastri', '#FFE9A8'),
  ('8-genitori', 'index', '#D9E8FF'),
]
CAP = {
  'it': [('6 giochi di logica', 'Dai 3 anni, senza saper leggere'),
         ('Ogni adesivo al posto giusto', 'Sei scene e una voce che guida'),
         ('Libera la strada all’auto a strisce', '160 livelli, tutti aperti'),
         ('Un colore per ogni barattolo', '120 livelli'),
         ('Traccia il sentiero con il dito', 'Stelle, chiavi e cancelli'),
         ('Gira i tubi: l’acqua va ai fiori', '120 livelli'),
         ('Riempi la sagoma con i pezzi', 'Razzi, castelli e dinosauri'),
         ('Pensato per i genitori', 'Niente pubblicità né acquisti dentro l’app. Nessun dato raccolto.')],
  'en': [('6 logic games', 'Ages 3+, no reading needed'),
         ('Every sticker in the right place', 'Six scenes and a voice to guide'),
         ('Clear the road for the striped car', '160 levels, all open'),
         ('Sort the balls into jars', '120 levels'),
         ('Trace the path with a finger', 'Stars, keys and gates'),
         ('Turn the pipes to water the flowers', '120 levels'),
         ('Fill the shape with the pieces', 'Rockets, castles and dinosaurs'),
         ('Made with parents in mind', 'No ads, no in-app purchases. No data collected.')],
  'es': [('6 juegos de lógica', 'Desde 3 años, sin saber leer'),
         ('Cada sticker en su sitio', 'Seis escenas y una voz que guía'),
         ('Abre paso al coche a rayas', '160 niveles, todos abiertos'),
         ('Un color en cada frasco', '120 niveles'),
         ('Traza el camino con el dedo', 'Estrellas, llaves y puertas'),
         ('Gira las tuberías y riega las flores', '120 niveles'),
         ('Rellena la silueta con las piezas', 'Cohetes, castillos y dinosaurios'),
         ('Pensado para las familias', 'Sin anuncios ni compras dentro de la app. Sin recopilar datos.')],
  'pt': [('6 jogos de lógica', 'A partir de 3 anos, sem precisar ler'),
         ('Cada adesivo no lugar certo', 'Seis cenários e uma voz que guia'),
         ('Abra caminho para o carro listrado', '160 níveis, todos liberados'),
         ('Uma cor em cada pote', '120 níveis'),
         ('Trace o caminho com o dedo', 'Estrelas, chaves e portões'),
         ('Gire os canos e regue as flores', '120 níveis'),
         ('Preencha a forma com as peças', 'Foguetes, castelos e dinossauros'),
         ('Pensado para os pais', 'Sem anúncios nem compras dentro do app. Nenhum dado coletado.')],
  'fr': [('6 jeux de logique', 'Dès 3 ans, sans savoir lire'),
         ('Chaque autocollant à sa place', 'Six décors et une voix pour guider'),
         ('Libère la route de la voiture à rayures', '160 niveaux, tous ouverts'),
         ('Une couleur par bocal', '120 niveaux'),
         ('Trace le chemin du bout du doigt', 'Étoiles, clés et barrières'),
         ('Tourne les tuyaux pour arroser les fleurs', '120 niveaux'),
         ('Remplis la silhouette avec les pièces', 'Fusées, châteaux et dinosaures'),
         ('Pensé pour les parents', 'Sans pub ni achats intégrés. Aucune donnée collectée.')],
  'de': [('6 Logikspiele', 'Ab 3 Jahren, ganz ohne Lesen'),
         ('Jeder Sticker an seinen Platz', 'Sechs Szenen und eine Stimme, die hilft'),
         ('Mach dem gestreiften Auto den Weg frei', '160 Level, alle offen'),
         ('Eine Farbe pro Glas', '120 Level'),
         ('Zieh den Weg mit dem Finger nach', 'Sterne, Schlüssel und Tore'),
         ('Dreh die Rohre und gieß die Blumen', '120 Level'),
         ('Füll die Form mit den Teilen', 'Raketen, Burgen und Dinos'),
         ('Für Eltern gemacht', 'Keine Werbung, keine In-App-Käufe. Es werden keine Daten erhoben.')],
  'ja': [('6つのロジックゲーム', '3歳から・字が読めなくても遊べる'),
         ('シールを正しい場所に', '6つの場面と、やさしい声の案内'),
         ('しましまの車の\n道をあけよう', '160レベル、すべて遊べる'),
         ('ボールを色ごとに分けよう', '120レベル'),
         ('指で道をなぞろう', '星、かぎ、とびら'),
         ('パイプを回してお花に水を', '120レベル'),
         ('ピースで形をうめよう', 'ロケット、お城、恐竜'),
         ('保護者の方へ', '広告なし・アプリ内課金なし。\nデータは集めません。')],
  'zh-Hans': [('6个逻辑游戏', '3岁起，不识字也能玩'),
              ('把贴纸放到对的地方', '6个场景，语音引导'),
              ('挪开车辆，\n让条纹小汽车出去', '160关，全部开放'),
              ('按颜色把彩球分好', '120关'),
              ('用手指画出路线', '星星、钥匙和大门'),
              ('转动水管，给花浇水', '120关'),
              ('用拼块填满图形', '火箭、城堡和恐龙'),
              ('为家长着想', '无广告，无应用内购买，不收集任何数据。')],
  'zh-Hant': [('6個邏輯遊戲', '3歲起，不識字也能玩'),
              ('把貼紙放到對的地方', '6個場景，語音引導'),
              ('挪開車輛，\n讓條紋小汽車出去', '160關，全部開放'),
              ('依顏色把彩球分好', '120關'),
              ('用手指畫出路線', '星星、鑰匙和大門'),
              ('轉動水管，給花澆水', '120關'),
              ('用拼塊填滿圖形', '火箭、城堡和恐龍'),
              ('為家長著想', '無廣告，無App內購買，不收集任何資料。')],
}
assert all(len(v) == len(SHOTS) for v in CAP.values())

SEED = r"""
(function () { var s = 20261117; Math.random = function () { s |= 0; s = s + 0x6D2B79F5 | 0; var t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; })();
try {
  var put = function (k, v) { localStorage.setItem(k, JSON.stringify(v)); };
  put('giocapensa.opzioni', { ui: %(lang)s, lingua: 'app' });
  put('via-libera.v2', { saves: { a1: { id: 'a1', name: 'Leo', created: 1, updated: 2, level: 41, skin: 'pastel', best: {}, board: null, deleted: false } }, active: 'a1' });
  put('palline.v1', { best: {}, last: 95 });
  put('labirinti.v1', { best: {}, last: 58 });
  put('acqua.v2', { best: {}, last: 64 });
  put('incastri.v1', { best: {}, last: 109 });
  put('adesivi.scene.v1', { rounds: {}, mode: 'dove', diff: '2' });
} catch (e) {}
"""
# Stickers: the winter mountain, «everything in its place», with most stickers already placed
PLAY_STEP = r"""(keep) => {
  const s = window.__AD.state(), R = s.R, home = id => (s.SC.items.find(q => q[0] === id) || [])[1];
  const left = R.tray.filter(q => !q.used && !q.stranger); if (left.length <= keep) return null;
  const q = left[0], z = s.SC.zones.find(x => x.id === home(q.id)), used = R.used[z.id] || {}, sl = z.slots[z.slots.findIndex((x, k) => !used[k])];
  const svg = document.getElementById('bgG').ownerSVGElement, bb = svg.getBoundingClientRect(), sc = Math.min(bb.width / 1000, bb.height / 1320);
  const tile = [...document.querySelectorAll('#tray .tile')].find(e => e.dataset.id === q.id && !e.classList.contains('gone'));
  tile.scrollIntoView({ inline: 'center', block: 'nearest' }); const a = tile.getBoundingClientRect();
  return { from: [a.left + a.width / 2, a.top + a.height / 2], to: [bb.left + (bb.width - 1000 * sc) / 2 + sl[0] * sc, bb.top + (bb.height - 1320 * sc) / 2 + (sl[1] - 30) * sc + 26] };
}"""


def raw(b, lg, d):
    ctx = b.new_context(viewport={'width': 440, 'height': 956}, device_scale_factor=3, locale='en-GB', color_scheme='light', has_touch=False, reduced_motion='reduce')
    ctx.add_init_script(SEED % {'lang': json.dumps(lg)})
    errs = []
    for name, page, _ in [x for x in SHOTS if not os.environ.get('SOLO') or x[0] in os.environ['SOLO']]:
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('http://localhost:%d/%s.html' % (PORT, page)); pg.wait_for_timeout(900)
        pg.evaluate('document.fonts.ready')
        if page == 'adesivi':
            pg.click('.scn[data-s="montagna"]'); pg.wait_for_timeout(900)
            for _ in range(12):
                t = pg.evaluate(PLAY_STEP, 1)
                if not t: break
                pg.wait_for_timeout(200); pg.mouse.move(*t['from']); pg.mouse.down(); pg.mouse.move(t['to'][0], t['to'][1], steps=12); pg.mouse.up(); pg.wait_for_timeout(900)
            pg.evaluate("() => { const R = window.__AD.state().R, q = R.tray.find(x => !x.used && !x.stranger), t = q && [...document.querySelectorAll('#tray .tile:not(.gone)')].find(e => e.dataset.id === q.id); if (t) t.scrollIntoView({ inline: 'center', block: 'nearest' }); }")
            pg.wait_for_timeout(600)
        if name == '8-genitori':
            pg.click('#btnSet'); pg.wait_for_timeout(700)
        pg.screenshot(path=os.path.join(d, name + '.png'))
        pg.close()
    ctx.close()
    return errs


def font(w):
    return base64.b64encode(open(os.path.join(ROOT, 'fonts', 'overpass-%d.woff2' % w), 'rb').read()).decode()


def compose(b, lg, src, out):
    faces = ''.join("@font-face{font-family:'Overpass';font-weight:%d;src:url(data:font/woff2;base64,%s) format('woff2')}" % (w, font(w)) for w in (600, 900))
    cjk = {'ja': "'Noto Sans CJK JP',", 'zh-Hans': "'Noto Sans CJK SC',", 'zh-Hant': "'Noto Sans CJK TC',"}.get(lg, '')
    ctx = b.new_context(viewport={'width': 440, 'height': 956}, device_scale_factor=3)
    for i, (name, _, bg) in enumerate(SHOTS):
        title, line = CAP[lg][i]
        img = base64.b64encode(open(os.path.join(src, name + '.png'), 'rb').read()).decode()
        html = '''<!doctype html><html lang="%(lang)s"><head><meta charset="utf-8"><style>%(faces)s
html,body{margin:0; width:440px; height:956px; overflow:hidden}
body{background:%(bg)s; font-family:'Overpass',%(cjk)s sans-serif; color:%(ink)s; position:relative}
.dots{position:absolute; inset:0; background-image:radial-gradient(circle, rgba(255,255,255,.75) 3px, transparent 3.5px), radial-gradient(circle, rgba(74,59,82,.07) 2.5px, transparent 3px); background-size:46px 46px, 62px 62px; background-position:0 0, 23px 31px}
.cap{position:absolute; left:22px; right:22px; top:34px; height:150px; display:flex; flex-direction:column; justify-content:center; align-items:center; text-align:center}
h1{white-space:pre-line; margin:0; font-weight:900; font-size:%(fs)spx; line-height:1.12; letter-spacing:-.01em; text-wrap:balance}
p{white-space:pre-line; margin:10px 0 0; font-weight:600; font-size:17px; line-height:1.3; text-wrap:balance; opacity:.85}
.ph{position:absolute; left:50%%; top:196px; width:338px; height:735px; transform:translateX(-50%%); border-radius:44px; background:%(ink)s; padding:9px; box-sizing:border-box; box-shadow:0 18px 30px rgba(74,59,82,.28)}
.ph img{display:block; width:100%%; height:100%%; border-radius:36px; object-fit:cover; object-position:top}
</style></head><body><div class="dots"></div><div class="cap"><h1>%(title)s</h1><p>%(line)s</p></div><div class="ph"><img src="data:image/png;base64,%(img)s"></div></body></html>''' % dict(
            lang=lg, faces=faces, bg=bg, cjk=cjk, ink=INK, title=title, line=line, img=img, fs=33 if len(title) < 30 or '\n' in title or lg in ('ja', 'zh-Hans', 'zh-Hant') else 30)
        pg = ctx.new_page(); pg.set_content(html); pg.evaluate('document.fonts.ready'); pg.wait_for_timeout(150)
        lines = pg.evaluate("() => { const h = document.querySelector('h1'), s = getComputedStyle(h); return Math.round(h.getBoundingClientRect().height / parseFloat(s.lineHeight)); }")
        tall = pg.evaluate("() => document.querySelector('.cap').scrollHeight > 150 || document.querySelector('h1').scrollWidth > document.querySelector('h1').clientWidth + 1")
        if lines > 2 or tall: print('DIDASCALIA TROPPO LUNGA', lg, name, lines)
        pg.screenshot(path=os.path.join(out, name + '.png'))
        pg.close()
    ctx.close()


srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '-d', ROOT], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        for lg in LANGS:
            d = os.path.join(OUT, 'grezze', lg); o = os.path.join(OUT, lg)
            os.makedirs(d, exist_ok=True); os.makedirs(o, exist_ok=True)
            errs = [] if os.environ.get('SOLO_DIDASCALIE') else raw(b, lg, d)
            compose(b, lg, d, o)
            print(lg, 'errori:', errs, flush=True)
        b.close()
finally:
    srv.terminate()
