#!/usr/bin/env python3
"""Incastri: silhouettes you can recognise (a rocket, a cat, a castle…) cut into pieces that may not be rotated.
   The cut itself is the stored solution; the cutter keeps the pieces chunky and the fillings few.
   usage: python3 gen.py > levels.json"""
import json, random, sys
random.seed(23)
N4 = [(1, 0), (-1, 0), (0, 1), (0, -1)]

# ---- the silhouettes, drawn by hand: what the child sees taking shape on the board
FORME = [
    # id,            rows
    ('quadrato',   ['##', '##']),
    ('montagna',   ['.#.', '###']),
    ('zeta',       ['##.', '.##']),
    ('elle',       ['#.', '#.', '##']),
    ('croce',      ['.#.', '###', '.#.']),
    ('ti',         ['###', '.#.', '.#.']),
    ('gradini',    ['#..', '##.', '.##']),
    ('scatola',    ['###', '###']),
    ('freccia',    ['.#.', '###', '.#.', '.#.']),
    ('coppa',      ['#.#', '###', '.#.']),
    ('casetta',    ['.#.', '###', '###']),
    ('albero',     ['.#.', '###', '###', '.#.']),
    ('razzo',      ['.#.', '###', '###', '#.#']),
    ('ponte',      ['#...#', '#####', '#...#']),
    ('gatto',      ['#.#', '###', '###', '#.#']),
    ('pesce',      ['###.', '####', '###.']),
    ('barca',      ['..#..', '..#..', '#####', '.###.']),
    ('macchina',   ['.##..', '#####', '#.#.#']),
    ('aereo',      ['..#..', '#####', '..#..', '.###.']),
    ('fungo',      ['.###.', '#####', '..#..', '..#..']),
    ('stella',     ['..#..', '#####', '.###.', '.#.#.']),
    ('albero2',    ['..#..', '.###.', '#####', '..#..', '..#..']),
    ('corona',     ['#.#.#', '#####', '#####']),
    ('casa',       ['.###.', '#####', '.###.', '.###.']),
    ('treno',      ['.##..', '####.', '#####', '#.#.#']),
    ('razzo2',     ['..#..', '.###.', '.###.', '.###.', '##.##']),
    ('robot',      ['.#.#.', '.###.', '#####', '.###.', '.#.#.']),
    ('granchio',   ['#...#', '#####', '#####', '#.#.#']),
    ('castello',   ['#.#.#', '#####', '#####', '##.##']),
    ('pinguino',   ['.##.', '####', '####', '####', '#..#']),
    ('balena',     ['..#...', '######', '######', '.####.']),
    ('velieri',    ['...#..', '..##..', '.###..', '####..', '######']),
    ('dinosauro',  ['....##', '...###', '..####', '######', '.##.##']),
    ('camion',     ['..####', '######', '######', '.##.##']),
    ('aereo2',     ['...#...', '...#...', '#######', '...#...', '..###..']),
    ('nave',       ['..#....', '..##...', '..###..', '#######', '.#####.']),
    ('casa2',      ['..##..', '.####.', '######', '.####.', '.####.']),
    ('trattore',   ['..####', '######', '######', '##..##']),
    ('balena2',    ['..##...', '#######', '#######', '.#####.']),
    ('torre',      ['.###.', '#####', '.###.', '#####', '.###.', '#####']),
    ('robot2',     ['.#..#.', '.####.', '######', '######', '.####.', '.#..#.']),
    ('pinguino2',  ['.###.', '#####', '#####', '#####', '.###.', '##.##']),
    ('dinosauro2', ['.....##', '....###', '...####', '.######', '#######', '.##..##']),
    ('camion2',    ['..#####', '.######', '#######', '#######', '.##.##.']),
    ('castello2',  ['#.#.#.#', '#######', '#######', '#######', '##.#.##']),
]
def cells_of(rows): return {(x, y) for y, r in enumerate(rows) for x, ch in enumerate(r) if ch == '#'}
def connected(cells):
    cells = set(cells); st = [next(iter(cells))]; seen = {st[0]}
    while st:
        x, y = st.pop()
        for dx, dy in N4:
            n = (x + dx, y + dy)
            if n in cells and n not in seen: seen.add(n); st.append(n)
    return len(seen) == len(cells)
def norm(cs):
    mx = min(x for x, y in cs); my = min(y for x, y in cs); return tuple(sorted((x - mx, y - my) for x, y in cs))
def boring(p):
    """a plain bar or a full rectangle: fine now and then, dull if that is all there is"""
    w = max(x for x, y in p) + 1; h = max(y for x, y in p) + 1
    return len(p) == w * h
def cut(cells, k, lo, hi):
    seeds = random.sample(sorted(cells), k); own = {s: i for i, s in enumerate(seeds)}; free = set(cells) - set(seeds); size = [1] * k
    while free:
        order = sorted(range(k), key=lambda i: (size[i], random.random())); grown = False
        for i in order:
            if size[i] >= hi: continue
            opts = [(x + dx, y + dy) for (x, y), o in own.items() if o == i for dx, dy in N4 if (x + dx, y + dy) in free]
            if opts: c = random.choice(opts); own[c] = i; free.discard(c); size[i] += 1; grown = True; break
        if not grown: return None
    return own if min(size) >= lo else None
def count(cells, pieces, cap=40):
    """how many different fillings exist (identical pieces are interchangeable)"""
    cells = frozenset(cells); seen = set()
    def rec(left, remaining, acc):
        if len(seen) >= cap: return
        if not left: seen.add(frozenset(acc)); return
        t = min(left, key=lambda c: (c[1], c[0]))
        for i, p in enumerate(remaining):
            if p in remaining[:i]: continue
            for ax, ay in p:
                pos = frozenset((t[0] - ax + x, t[1] - ay + y) for x, y in p)
                if pos <= left: rec(left - pos, remaining[:i] + remaining[i + 1:], acc + [(p, min(pos))])
    rec(cells, [norm(q) for q in pieces], []); return len(seen)

def build(name, rows, k, lo, hi, maxsol, tries=700):
    cells = cells_of(rows); w = max(len(r) for r in rows); h = len(rows)
    for _ in range(tries):
        own = cut(cells, k, lo, hi)
        if not own: continue
        pieces = [[c for c, o in own.items() if o == i] for i in range(k)]
        shapes = [norm(p) for p in pieces]
        if k > 2 and len(set(shapes)) < 2: continue                      # not all the same block
        odd = sum(0 if boring(q) else 1 for q in shapes)
        if k > 2 and odd < (2 if k >= 4 else 1): continue                # pieces with real corners, not only bars and squares
        if count(cells, pieces, maxsol + 1) > maxsol: continue
        grid = ['' .join('ABCDEFGH'[own[(x, y)]] if (x, y) in own else '.' for x in range(w)) for y in range(h)]
        return {'w': w, 'h': h, 'g': '/'.join(grid), 'm': k, 'n': name, 'a': len(cells)}
    return None

PIANO = [   # tier: (pieces, smallest piece, largest piece, max fillings, range of silhouette size)
    (2, 2, 5, 9, (4, 9)),
    (3, 2, 5, 6, (7, 13)),
    (4, 3, 5, 4, (12, 18)),
    (5, 3, 6, 3, (17, 24)),
    (6, 4, 6, 2, (24, 32)),
]
out = []
for k, lo, hi, maxsol, (amin, amax) in PIANO:
    pool = [(n, r) for n, r in FORME if amin <= len(cells_of(r)) <= amax]
    got, seen, guard = [], set(), 0
    while len(got) < 24 and guard < 4000:
        guard += 1
        name, rows = pool[guard % len(pool)] if guard % 3 else random.choice(pool)
        lv = build(name, rows, k, lo, hi, maxsol, tries=120)
        if not lv or lv['g'] in seen: continue
        seen.add(lv['g']); got.append(lv)
    assert len(got) == 24, (k, len(got))
    got.sort(key=lambda L: (L['a'], L['g']))
    out += got
json.dump([{k2: L[k2] for k2 in ('w', 'h', 'g', 'm', 'n')} for L in out], sys.stdout, separators=(',', ':'))
for t in range(5):
    part = out[t * 24:(t + 1) * 24]
    print('fascia', t + 1, '| pezzi', part[0]['m'], '| caselle', min(L['a'] for L in part), '-', max(L['a'] for L in part), '|', ', '.join(sorted({L['n'] for L in part})), file=sys.stderr)
