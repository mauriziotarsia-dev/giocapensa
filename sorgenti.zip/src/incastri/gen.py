#!/usr/bin/env python3
"""Incastri: a silhouette cut into polyomino pieces that may not be rotated. The cut itself is the stored solution."""
import json, random
random.seed(23)
N4 = [(1, 0), (-1, 0), (0, 1), (0, -1)]
def connected(cells):
    cells = set(cells); st = [next(iter(cells))]; seen = {st[0]}
    while st:
        x, y = st.pop()
        for dx, dy in N4:
            n = (x + dx, y + dy)
            if n in cells and n not in seen: seen.add(n); st.append(n)
    return len(seen) == len(cells)
def shape(w, h, holes):
    cells = {(x, y) for x in range(w) for y in range(h)}
    for _ in range(holes):
        edge = [c for c in cells if sum((c[0] + dx, c[1] + dy) in cells for dx, dy in N4) < 4]; random.shuffle(edge)
        for c in edge:
            if connected(cells - {c}) and len({x for x, y in cells - {c}}) == w and len({y for x, y in cells - {c}}) == h: cells.discard(c); break
    return cells
def cut(cells, k, lo, hi):
    seeds = random.sample(sorted(cells), k); own = {s: i for i, s in enumerate(seeds)}; free = set(cells) - set(seeds); size = [1] * k
    while free:
        order = sorted(range(k), key=lambda i: (size[i], random.random())); grown = False
        for i in order:
            if size[i] >= hi: continue
            opts = [(x + dx, y + dy) for (x, y), o in own.items() if o == i for dx, dy in N4 if (x + dx, y + dy) in free]
            if opts: c = random.choice(opts); own[c] = i; free.discard(c); size[i] += 1; grown = True; break
        if not grown: return None
    return own if min(size) >= lo else None
def norm(cs): mx = min(x for x, y in cs); my = min(y for x, y in cs); return tuple(sorted((x - mx, y - my) for x, y in cs))
def count(cells, pieces, cap=50):
    """number of different fillings (identical pieces are interchangeable)"""
    cells = frozenset(cells); seen = set()
    def rec(left, remaining, acc):
        if len(seen) >= cap: return
        if not left: seen.add(frozenset(acc)); return
        t = min(left, key=lambda c: (c[1], c[0]))
        for i, p in enumerate(remaining):
            if p in remaining[:i]: continue
            for ax, ay in p:
                pos = frozenset((t[0] - ax + x, t[1] - ay + y) for x, y in p)
                if pos <= left: rec(left - pos, remaining[:i] + remaining[i + 1:], acc + [(p, min(pos))])
    rec(cells, [norm(p) for p in pieces], []); return len(seen)
def make(w, h, holes, k, lo, hi, maxsol):
    for _ in range(3000):
        cells = shape(w, h, holes); own = cut(cells, k, lo, hi)
        if not own: continue
        pieces = [[c for c, o in own.items() if o == i] for i in range(k)]
        if k > 2 and len({norm(p) for p in pieces}) < k - 1: continue        # not all the same block
        if all(len(p) == len({x for x, y in p}) * len({y for x, y in p}) for p in pieces) and k > 2: continue   # only plain bars and squares is dull
        n = count(cells, pieces)
        if n > maxsol: continue
        rows = [''.join('ABCDEFGH'[own[(x, y)]] if (x, y) in own else '.' for x in range(w)) for y in range(h)]
        return {'w': w, 'h': h, 'g': '/'.join(rows), 'm': k, 'n': n, 'a': len(cells)}
    raise SystemExit('nessun livello per %s' % ((w, h, holes, k),))
plan = [  # (w, h, holes, pieces, smallest, largest, max fillings) x how many
    [((2, 2, 0, 2, 2, 2, 9), 2), ((3, 2, 0, 2, 2, 4, 9), 6), ((2, 3, 0, 2, 2, 4, 9), 6), ((3, 3, 1, 2, 3, 5, 9), 10)],
    [((3, 3, 0, 3, 2, 4, 6), 10), ((3, 3, 1, 3, 2, 4, 6), 6), ((4, 3, 2, 3, 2, 5, 4), 8)],
    [((4, 3, 0, 4, 2, 4, 4), 8), ((3, 4, 1, 4, 2, 4, 4), 8), ((4, 4, 3, 4, 2, 5, 3), 8)],
    [((4, 4, 0, 5, 2, 5, 3), 10), ((4, 4, 1, 5, 2, 4, 3), 6), ((5, 4, 3, 5, 3, 5, 2), 8)],
    [((5, 4, 0, 6, 2, 5, 2), 8), ((4, 5, 1, 6, 2, 5, 2), 8), ((5, 5, 5, 6, 3, 5, 2), 8)],
]
out = []; seen = set()
for tier in plan:
    lv = []
    for cfg, n in tier:
        got = tries = 0
        while got < n and tries < 600:
            tries += 1; L = make(*cfg)
            if L['g'] in seen: continue
            seen.add(L['g']); lv.append(L); got += 1
    tries = 0
    while len(lv) < 24 and tries < 2000:                                      # top up from the last recipe of the tier
        tries += 1; L = make(*tier[-1][0])
        if L['g'] not in seen: seen.add(L['g']); lv.append(L)
    assert len(lv) == 24, len(lv)
    lv.sort(key=lambda L: (L['m'], L['a'], -L['n'])); out += lv
json.dump([{'w': L['w'], 'h': L['h'], 'g': L['g'], 'm': L['m']} for L in out], open('levels.json', 'w'), separators=(',', ':'))
for t in range(5): print('fascia', t + 1, 'pezzi:', ' '.join(str(L['m']) for L in out[t * 24:(t + 1) * 24]), '| soluzioni:', ' '.join(str(L['n']) for L in out[t * 24:(t + 1) * 24]))
