(function () {
  'use strict';
  var RAW = window.GAME_LEVELS, IN = window.IN, K = window.Kit, INK = K.INK, scene = document.getElementById('scene');
  var COL = [['#FF9383', '#EE5E4D', '#C7402F'], ['#FFE98A', '#FFD95A', '#E8B52E'], ['#A9D3FF', '#7DB7F7', '#5791DB'], ['#B4ECAE', '#8DD68A', '#62B660'], ['#A6ECE6', '#4FC3C7', '#2E9AA1'], ['#FFC894', '#F2A65A', '#D98535']], CNAME = ['rosso', 'giallo', 'blu', 'verde', 'turchese', 'arancione'];
  var G, placed, hist, slots, els, W, H, bx, by, S = 0.58, drag = null, piecesG, ghostG, fxG;
  function dot(x, y, r, f) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + (f || INK) + '"/>'; }
  function defs() {
    var s = '<defs><linearGradient id="gTable" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F3D9B1"/><stop offset="1" stop-color="#DDB884"/></linearGradient>' +
      '<radialGradient id="gVig" cx="50%" cy="45%" r="75%"><stop offset=".55" stop-color="#5A3A1A" stop-opacity="0"/><stop offset="1" stop-color="#5A3A1A" stop-opacity=".28"/></radialGradient>' +
      '<linearGradient id="gRim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E2B07A"/><stop offset="1" stop-color="#B57E48"/></linearGradient>' +
      '<linearGradient id="gSlot" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#A97B4C"/><stop offset="1" stop-color="#C79A68"/></linearGradient>' +
      '<linearGradient id="gFelt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#CFE6C4"/><stop offset="1" stop-color="#E6F4DE"/></linearGradient>';
    COL.forEach(function (c, i) { s += '<linearGradient id="gp' + i + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + c[0] + '"/><stop offset=".55" stop-color="' + c[1] + '"/><stop offset="1" stop-color="' + c[2] + '"/></linearGradient>'; });
    return s + '</defs>';
  }
  function art(p) {
    var has = {}, body = '', sil = '', edge = '', hi = '', lo = '', inner = '', ci = p.id % COL.length;
    p.cells.forEach(function (c) { has[c[0] + ',' + c[1]] = 1; });
    p.cells.forEach(function (c) {
      var x = c[0] * 100, y = c[1] * 100, up = has[c[0] + ',' + (c[1] - 1)], dn = has[c[0] + ',' + (c[1] + 1)], lf = has[(c[0] - 1) + ',' + c[1]], rt = has[(c[0] + 1) + ',' + c[1]];
      body += '<rect x="' + (x - 0.5) + '" y="' + (y - 0.5) + '" width="101" height="101" fill="url(#gp' + ci + ')"/><ellipse cx="' + (x + 30) + '" cy="' + (y + 22) + '" rx="17" ry="8" fill="#fff" opacity=".5" transform="rotate(-20 ' + (x + 30) + ' ' + (y + 22) + ')"/>';
      sil += '<rect x="' + x + '" y="' + y + '" width="100" height="100"/>';
      if (!up) { edge += 'M' + x + ' ' + y + 'h100'; hi += 'M' + (x + (lf ? 0 : 11)) + ' ' + (y + 11) + 'H' + (x + (rt ? 100 : 89)); } else inner += 'M' + (x + 18) + ' ' + y + 'h64';
      if (!dn) { edge += 'M' + x + ' ' + (y + 100) + 'h100'; lo += 'M' + (x + (lf ? 0 : 11)) + ' ' + (y + 89) + 'H' + (x + (rt ? 100 : 89)); }
      if (!lf) { edge += 'M' + x + ' ' + y + 'v100'; hi += 'M' + (x + 11) + ' ' + (y + (up ? 0 : 11)) + 'V' + (y + (dn ? 100 : 89)); } else inner += 'M' + x + ' ' + (y + 18) + 'v64';
      if (!rt) { edge += 'M' + (x + 100) + ' ' + y + 'v100'; lo += 'M' + (x + 89) + ' ' + (y + (up ? 0 : 11)) + 'V' + (y + (dn ? 100 : 89)); }
    });
    var f = p.cells[0], fx = f[0] * 100 + 50, fy = f[1] * 100 + 56;
    return '<g class="shadowp" fill="#3A2410">' + sil + '</g>' + body +
      '<path d="' + inner + '" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="5" stroke-linecap="round"/><path d="' + hi + '" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="7" stroke-linecap="round"/><path d="' + lo + '" fill="none" stroke="#000" stroke-opacity=".17" stroke-width="7" stroke-linecap="round"/>' +
      '<g class="flash" fill="#fff">' + sil + '</g><path d="' + edge + '" fill="none"' + K.k(9) + '/>' +
      '<g class="blink" style="--d:' + (-p.id * 0.9) + 's"><ellipse cx="' + (fx - 16) + '" cy="' + (fy - 8) + '" rx="7" ry="8.5" fill="' + INK + '"/><ellipse cx="' + (fx + 16) + '" cy="' + (fy - 8) + '" rx="7" ry="8.5" fill="' + INK + '"/>' + dot(fx - 13.5, fy - 11, 2.6, '#fff') + dot(fx + 18.5, fy - 11, 2.6, '#fff') + '</g>' +
      '<path class="m1" d="M' + (fx - 12) + ' ' + (fy + 10) + 'q12 11 24 0" fill="none"' + K.k(4.5) + '/><ellipse class="m2" cx="' + fx + '" cy="' + (fy + 15) + '" rx="7" ry="8.5" fill="#7A3B46"' + K.k(3.5) + '/>' +
      '<path class="m3" d="M' + (fx - 14) + ' ' + (fy + 8) + 'h28q-2 16 -14 16t-14 -16Z" fill="#7A3B46"' + K.k(3.5) + '/>' + dot(fx - 30, fy + 8, 7, '#fff') + dot(fx + 30, fy + 8, 7, '#fff');
  }
  function setT(i, x, y, s) { var e = els[i]; e._x = x; e._y = y; e._s = s; e.setAttribute('transform', 'translate(' + x.toFixed(1) + ',' + y.toFixed(1) + ') scale(' + s.toFixed(3) + ')'); }
  function home(i) { return placed[i] ? [bx + placed[i][0] * 100, by + placed[i][1] * 100, 1] : [slots[i][0], slots[i][1], S]; }
  function glide(i, ms, done) { var e = els[i], t = home(i), x0 = e._x, y0 = e._y, s0 = e._s; e.classList.toggle('placed', !!placed[i]); K.tween(ms, function (q) { var k2 = q * q * (3 - 2 * q); setT(i, x0 + (t[0] - x0) * k2, y0 + (t[1] - y0) * k2, s0 + (t[2] - s0) * k2); }, done); }

  function load(n) {
    G = IN.parse(RAW[n]); placed = G.pieces.map(function () { return null; }); hist = []; drag = null;
    W = Math.max(G.w * 100 + 150, 620); bx = (W - G.w * 100) / 2; by = 84;
    var order = G.pieces.map(function (p, i) { return i; }), r = n * 7 + 3, i, j, t;
    for (i = order.length - 1; i > 0; i--) { r = (r * 1103515245 + 12345) % 2147483648; j = r % (i + 1); t = order[i]; order[i] = order[j]; order[j] = t; }
    var x = 64, y = by + G.h * 100 + 116, rowH = 0; slots = [];
    order.forEach(function (pi) { var p = G.pieces[pi], pw = p.pw * 100 * S, ph = p.ph * 100 * S; if (x + pw > W - 64) { x = 64; y += rowH + 30; rowH = 0; } slots[pi] = [x, y]; x += pw + 34; rowH = Math.max(rowH, ph); });
    var trayTop = by + G.h * 100 + 74, trayBot = y + rowH + 42; H = trayBot + 46;
    scene.setAttribute('viewBox', '0 0 ' + W + ' ' + H); scene.style.setProperty('--scene-bg', '#E8C898');
    var s = defs() + '<rect x="-3000" y="-3000" width="9000" height="9000" fill="url(#gTable)"/>', cx, cy, k2;
    for (k2 = -6; k2 < 26; k2++) s += '<path d="M-3000 ' + (k2 * 58 + 20) + 'q' + (400 + (k2 * 37) % 160) + ' ' + (14 - (k2 * 11) % 28) + ' 1500 0t1500 0 1500 0 1500 0" fill="none" stroke="#B98D55" stroke-width="' + (2 + k2 % 3) + '" opacity=".22"/>';   // wood grain
    s += '<rect x="-3000" y="-3000" width="9000" height="9000" fill="url(#gVig)"/>';
    for (k2 = 0; k2 < 7; k2++) s += '<g class="twinkle" style="--d:' + (-k2 * 0.7) + 's">' + K.star(30 + (k2 * 173) % (W - 60), 24 + (k2 * 97) % 46, 9, '#FFF6D6', 0) + '</g>';
    // the wooden tray with its carved slots
    s += '<g class="world"><rect x="' + (bx - 30) + '" y="' + (by - 18) + '" width="' + (G.w * 100 + 60) + '" height="' + (G.h * 100 + 62) + '" rx="34" fill="#5A3A1A" opacity=".3"/>' +
      '<rect x="' + (bx - 34) + '" y="' + (by - 34) + '" width="' + (G.w * 100 + 68) + '" height="' + (G.h * 100 + 68) + '" rx="34" fill="url(#gRim)"' + K.k(5) + '/>' +
      '<path d="M' + (bx - 22) + ' ' + (by + G.h * 100) + 'V' + (by - 10) + 'a12 12 0 0 1 12 -12H' + (bx + G.w * 100) + '" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".45"/>';
    for (cy = 0; cy < G.h; cy++) for (cx = 0; cx < G.w; cx++) if (G.board[cy][cx]) { var sx = bx + cx * 100, sy = by + cy * 100;
      s += '<rect x="' + (sx + 4) + '" y="' + (sy + 4) + '" width="92" height="92" rx="16" fill="url(#gSlot)"/><path d="M' + (sx + 10) + ' ' + (sy + 84) + 'V' + (sy + 20) + 'a10 10 0 0 1 10 -10H' + (sx + 84) + '" fill="none" stroke="#5A3A1A" stroke-width="5" stroke-linecap="round" opacity=".38"/>' +
        '<path d="M' + (sx + 90) + ' ' + (sy + 18) + 'V' + (sy + 80) + 'a10 10 0 0 1 -10 10H' + (sx + 18) + '" fill="none" stroke="#FFE7C2" stroke-width="4" stroke-linecap="round" opacity=".6"/>'; }
    // the drawer: wood outside, felt inside
    s += '<rect x="30" y="' + (trayTop + 10) + '" width="' + (W - 60) + '" height="' + (trayBot - trayTop) + '" rx="32" fill="#5A3A1A" opacity=".28"/><rect x="26" y="' + trayTop + '" width="' + (W - 52) + '" height="' + (trayBot - trayTop) + '" rx="32" fill="url(#gRim)"' + K.k(5) + '/>' +
      '<rect x="44" y="' + (trayTop + 18) + '" width="' + (W - 88) + '" height="' + (trayBot - trayTop - 36) + '" rx="20" fill="url(#gFelt)"' + K.k(4) + '/><path d="M56 ' + (trayBot - 34) + 'V' + (trayTop + 44) + 'a12 12 0 0 1 12 -12H' + (W - 70) + '" fill="none" stroke="#5A7A4A" stroke-width="5" stroke-linecap="round" opacity=".25"/>';
    s += '<clipPath id="bclip"><rect x="' + bx + '" y="' + by + '" width="' + (G.w * 100) + '" height="' + (G.h * 100) + '" rx="14"/></clipPath><g id="ghostG"></g><g id="piecesG">';
    G.pieces.forEach(function (p) { s += '<g class="piece" data-p="' + p.id + '" style="--d:' + (-p.id * 0.55) + 's"><g class="pi">' + art(p) + '</g></g>'; });
    scene.innerHTML = s + '</g><g id="shineG" clip-path="url(#bclip)"></g></g><g id="fxG"></g>';
    piecesG = scene.querySelector('#piecesG'); ghostG = scene.querySelector('#ghostG'); fxG = scene.querySelector('#fxG');
    els = G.pieces.map(function (p) { return piecesG.querySelector('[data-p="' + p.id + '"]'); });
    G.pieces.forEach(function (p, i2) { setT(i2, slots[i2][0], slots[i2][1], S); });
    return '';
  }
  function pt(e) { var b = scene.getBoundingClientRect(), s = Math.min(b.width / W, b.height / H); return { x: (e.clientX - b.left - (b.width - W * s) / 2) / s, y: (e.clientY - b.top - (b.height - H * s) / 2) / s }; }
  function ghost(cells, color, cls) { ghostG.innerHTML = cells.map(function (c) { return '<rect class="' + (cls || '') + '" x="' + (bx + c[0] * 100 + 6) + '" y="' + (by + c[1] * 100 + 6) + '" width="88" height="88" rx="15" fill="' + color + '" stroke="#fff" stroke-width="4" stroke-dasharray="10 9"/>'; }).join(''); }
  function snap() {                                   // where the held piece would land, if it fits there
    var d = drag, p = G.pieces[d.i], gx = Math.round((els[d.i]._x - bx) / 100), gy = Math.round((els[d.i]._y - by) / 100);
    d.spot = IN.fits(G, IN.grid(G, placed), p, gx, gy) ? [gx, gy] : null;
    if (d.spot) ghost(p.cells.map(function (c) { return [gx + c[0], gy + c[1]]; }), '#9BF0A2', 'ghostc'); else ghostG.innerHTML = '';
  }
  scene.addEventListener('pointerdown', function (e) {
    if (K.isWon() || drag || (e.pointerType === 'mouse' && e.button !== 0)) return; var g = e.target.closest ? e.target.closest('.piece') : null; if (!g) return;
    e.preventDefault(); clearHint(); var i = +g.getAttribute('data-p'), q = pt(e), el = els[i];
    drag = { i: i, pid: e.pointerId, lx: (q.x - el._x) / el._s, ly: (q.y - el._y) / el._s, from: placed[i], moved: false, spot: null }; placed[i] = null;
    piecesG.appendChild(el); el.classList.remove('pop', 'placed'); el.classList.add('drag'); K.sfx('pick'); try { scene.setPointerCapture(e.pointerId); } catch (err) {}
  });
  scene.addEventListener('pointermove', function (e) {
    if (!drag || e.pointerId !== drag.pid) return; var q = pt(e), p = G.pieces[drag.i]; drag.moved = true;
    setT(drag.i, q.x - Math.min(drag.lx, p.pw * 100) , q.y - drag.ly - 64, 1); snap();
  });
  function up(e) {
    if (!drag || e.pointerId !== drag.pid) return; var d = drag, el = els[d.i]; drag = null; el.classList.remove('drag'); ghostG.innerHTML = '';
    if (d.moved && d.spot) {
      placed[d.i] = d.spot; hist.push({ p: d.i, from: d.from, to: d.spot });
      glide(d.i, 90, function () { el.classList.add('pop'); }); K.sfx('place', placed.filter(function (q) { return !!q; }).length - 1); K.buzz(10); K.changed();   // each piece plays the next note up
      if (placed.every(function (x) { return !!x; })) { els.forEach(function (pe, n) { pe.style.setProperty('--pd', (n * 0.09) + 's'); pe.classList.remove('pop'); pe.classList.add('party'); }); K.sparkle(fxG, W / 2, by + G.h * 50, 20); K.confetti(fxG, W, H); scene.querySelector('#shineG').innerHTML = '<rect class="shine" x="' + bx + '" y="' + (by - 40) + '" width="' + (G.w * 38) + '" height="' + (G.h * 100 + 80) + '" fill="#fff" opacity=".55"/>'; K.win(); }
    } else {
      if (!d.moved) placed[d.i] = d.from; else if (d.from) hist.push({ p: d.i, from: d.from, to: null });   // taken off the board: allowed, and it is not a move
      glide(d.i, 200); if (d.moved) K.sfx('back'); K.changed();
    }
  }
  scene.addEventListener('pointerup', up); scene.addEventListener('pointercancel', up);
  scene.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  function clearHint() { if (ghostG) ghostG.innerHTML = ''; if (els) els.forEach(function (e) { e.classList.remove('hintp'); }); }
  K.start({
    key: 'incastri.v1', count: RAW.length, perTier: 24, moveLabel: 'Mosse', word: ['mossa', 'mosse'], winTitle: 'Tutto incastrato!', winDelay: 1500,
    intro: 'Trascina i pezzi dal cassetto fino a riempire tutta la sagoma. I pezzi non si girano.',
    rules: ['Riempi tutta la sagoma con i pezzi del cassetto.', 'I pezzi si trascinano così come sono: non si possono girare.', 'Un pezzo già messo si può riprendere e spostare, o riportare nel cassetto.', 'Conta una mossa ogni pezzo appoggiato sulla sagoma: il minimo è un pezzo, una mossa.'],
    minOf: function (i) { return RAW[i].m; }, load: load, moves: function () { return hist ? hist.filter(function (h) { return h.to; }).length : 0; }, canUndo: function () { return hist && hist.length > 0 && !drag; },
    undo: function () { var h = hist.pop(); placed[h.p] = h.from; piecesG.appendChild(els[h.p]); els[h.p].classList.remove('pop'); glide(h.p, 200); K.sfx('back'); K.changed(); },
    clearHint: clearHint,
    hint: function () {
      if (drag) return null; var sol = IN.solve(G, placed), i;
      if (sol) { for (i = 0; i < sol.length; i++) if (!placed[i]) break; var p = G.pieces[i]; els[i].classList.add('hintp'); ghost(p.cells.map(function (c) { return [sol[i][0] + c[0], sol[i][1] + c[1]]; }), '#FF8A3D', 'ghostc');
        return 'Il pezzo ' + CNAME[i % CNAME.length] + ' va dove lampeggia l\'arancione.'; }
      for (i = 0; i < placed.length; i++) { if (!placed[i]) continue; var trial = placed.slice(); trial[i] = null; if (IN.solve(G, trial)) { els[i].classList.add('hintp'); return 'Così gli altri non ci stanno: togli il pezzo ' + CNAME[i % CNAME.length] + ' e riprova.'; } }
      return 'Riporta i pezzi nel cassetto e riparti.';
    }
  });
})();
