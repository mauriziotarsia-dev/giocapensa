(function () {
  'use strict';
  var RAW = window.GAME_LEVELS, IN = window.IN, K = window.Kit, INK = K.INK, scene = document.getElementById('scene');
  var NOMI = {                                                 // what the silhouette shows, so the grown-up can name it: «riempi il razzo»
    quadrato: ['il quadrato', 'Quadrato'], montagna: ['la montagna', 'Montagna'], zeta: ['la zeta', 'Zeta'], elle: ['la elle', 'Elle'], croce: ['la croce', 'Croce'],
    ti: ['la ti', 'Ti'], gradini: ['i gradini', 'Gradini'], scatola: ['la scatola', 'Scatola'], freccia: ['la freccia', 'Freccia'], coppa: ['la coppa', 'Coppa'],
    casetta: ['la casetta', 'Casetta'], albero: ["l'albero", 'Albero'], albero2: ["l'albero", 'Albero'], razzo: ['il razzo', 'Razzo'], razzo2: ['il razzo', 'Razzo'],
    ponte: ['il ponte', 'Ponte'], gatto: ['il gatto', 'Gatto'], pesce: ['il pesce', 'Pesce'], barca: ['la barca', 'Barca'], macchina: ['la macchina', 'Macchina'],
    aereo: ["l'aereo", 'Aereo'], aereo2: ["l'aereo", 'Aereo'], fungo: ['il fungo', 'Fungo'], stella: ['la stella', 'Stella'], corona: ['la corona', 'Corona'],
    casa: ['la casa', 'Casa'], casa2: ['la casa', 'Casa'], treno: ['il treno', 'Treno'], robot: ['il robot', 'Robot'], robot2: ['il robot', 'Robot'],
    granchio: ['il granchio', 'Granchio'], castello: ['il castello', 'Castello'], castello2: ['il castello', 'Castello'], pinguino: ['il pinguino', 'Pinguino'],
    pinguino2: ['il pinguino', 'Pinguino'], balena: ['la balena', 'Balena'], balena2: ['la balena', 'Balena'], velieri: ['la barca a vela', 'Barca'],
    nave: ['la nave', 'Nave'], dinosauro: ['il dinosauro', 'Dinosauro'], dinosauro2: ['il dinosauro', 'Dinosauro'], camion: ['il camion', 'Camion'],
    camion2: ['il camion', 'Camion'], trattore: ['il trattore', 'Trattore'], torre: ['la torre', 'Torre']
  };
  function alive() {                                            // the filled shape opens its eyes and smiles
    var sx = 0, sy = 0, n = 0, cx2, cy2; for (cy2 = 0; cy2 < G.h; cy2++) for (cx2 = 0; cx2 < G.w; cx2++) if (G.board[cy2][cx2]) { sx += cx2; sy += cy2; n++; }
    var x = bx + (sx / n + 0.5) * 100, y = by + (sy / n + 0.5) * 100;
    fxG.insertAdjacentHTML('beforeend', '<g class="alive" transform="translate(' + x.toFixed(0) + ',' + y.toFixed(0) + ')"><g class="alin"><ellipse cx="-30" cy="-6" rx="13" ry="16" fill="#fff" stroke="#4A3B52" stroke-width="6"/><ellipse cx="30" cy="-6" rx="13" ry="16" fill="#fff" stroke="#4A3B52" stroke-width="6"/><circle cx="-27" cy="-3" r="7" fill="#4A3B52"/><circle cx="33" cy="-3" r="7" fill="#4A3B52"/><path d="M-22 22q22 24 44 0Z" fill="#7A3B46" stroke="#4A3B52" stroke-width="5" stroke-linejoin="round"/><circle cx="-46" cy="18" r="9" fill="#FFB59A" opacity=".9"/><circle cx="46" cy="18" r="9" fill="#FFB59A" opacity=".9"/></g></g>');
  }
  var NOMI_L = {                                               // the other languages: 'Name|object of «fill …»|gender' (the gender only where the title agrees with the name)
    en: { quadrato: 'Square|the square', montagna: 'Mountain|the mountain', zeta: 'Zigzag|the zigzag', elle: 'L shape|the L shape', croce: 'Cross|the cross', ti: 'T shape|the T shape', gradini: 'Steps|the steps', scatola: 'Box|the box',
      freccia: 'Arrow|the arrow', coppa: 'Cup|the cup', casetta: 'Little house|the little house', albero: 'Tree|the tree', razzo: 'Rocket|the rocket', ponte: 'Bridge|the bridge', gatto: 'Cat|the cat', pesce: 'Fish|the fish',
      barca: 'Boat|the boat', macchina: 'Car|the car', aereo: 'Plane|the plane', fungo: 'Mushroom|the mushroom', stella: 'Star|the star', corona: 'Crown|the crown', casa: 'House|the house', treno: 'Train|the train', robot: 'Robot|the robot',
      granchio: 'Crab|the crab', castello: 'Castle|the castle', pinguino: 'Penguin|the penguin', balena: 'Whale|the whale', velieri: 'Sailboat|the sailboat', nave: 'Ship|the ship', dinosauro: 'Dinosaur|the dinosaur',
      camion: 'Truck|the truck', trattore: 'Tractor|the tractor', torre: 'Tower|the tower' },
    es: { quadrato: 'Cuadrado|el cuadrado|m', montagna: 'Montaña|la montaña|f', zeta: 'Zigzag|el zigzag|m', elle: 'Forma de L|la forma de L|f', croce: 'Cruz|la cruz|f', ti: 'Forma de T|la forma de T|f', gradini: 'Escalones|los escalones|mp',
      scatola: 'Caja|la caja|f', freccia: 'Flecha|la flecha|f', coppa: 'Copa|la copa|f', casetta: 'Casita|la casita|f', albero: 'Árbol|el árbol|m', razzo: 'Cohete|el cohete|m', ponte: 'Puente|el puente|m', gatto: 'Gato|el gato|m',
      pesce: 'Pez|el pez|m', barca: 'Barca|la barca|f', macchina: 'Coche|el coche|m', aereo: 'Avión|el avión|m', fungo: 'Hongo|el hongo|m', stella: 'Estrella|la estrella|f', corona: 'Corona|la corona|f', casa: 'Casa|la casa|f',
      treno: 'Tren|el tren|m', robot: 'Robot|el robot|m', granchio: 'Cangrejo|el cangrejo|m', castello: 'Castillo|el castillo|m', pinguino: 'Pingüino|el pingüino|m', balena: 'Ballena|la ballena|f', velieri: 'Velero|el velero|m',
      nave: 'Barco|el barco|m', dinosauro: 'Dinosaurio|el dinosaurio|m', camion: 'Camión|el camión|m', trattore: 'Tractor|el tractor|m', torre: 'Torre|la torre|f' },
    pt: { quadrato: 'Quadrado|o quadrado|m', montagna: 'Montanha|a montanha|f', zeta: 'Zigue-zague|o zigue-zague|m', elle: 'Forma de L|a forma de L|f', croce: 'Cruz|a cruz|f', ti: 'Forma de T|a forma de T|f', gradini: 'Degraus|os degraus|mp',
      scatola: 'Caixa|a caixa|f', freccia: 'Seta|a seta|f', coppa: 'Taça|a taça|f', casetta: 'Casinha|a casinha|f', albero: 'Árvore|a árvore|f', razzo: 'Foguete|o foguete|m', ponte: 'Ponte|a ponte|f', gatto: 'Gato|o gato|m',
      pesce: 'Peixe|o peixe|m', barca: 'Barco|o barco|m', macchina: 'Carro|o carro|m', aereo: 'Avião|o avião|m', fungo: 'Cogumelo|o cogumelo|m', stella: 'Estrela|a estrela|f', corona: 'Coroa|a coroa|f', casa: 'Casa|a casa|f',
      treno: 'Trem|o trem|m', robot: 'Robô|o robô|m', granchio: 'Caranguejo|o caranguejo|m', castello: 'Castelo|o castelo|m', pinguino: 'Pinguim|o pinguim|m', balena: 'Baleia|a baleia|f', velieri: 'Veleiro|o veleiro|m',
      nave: 'Navio|o navio|m', dinosauro: 'Dinossauro|o dinossauro|m', camion: 'Caminhão|o caminhão|m', trattore: 'Trator|o trator|m', torre: 'Torre|a torre|f' },
    fr: { quadrato: 'Carré|le carré|m', montagna: 'Montagne|la montagne|f', zeta: 'Zigzag|le zigzag|m', elle: 'Forme en L|la forme en L|f', croce: 'Croix|la croix|f', ti: 'Forme en T|la forme en T|f', gradini: 'Marches|les marches|fp',
      scatola: 'Boîte|la boîte|f', freccia: 'Flèche|la flèche|f', coppa: 'Coupe|la coupe|f', casetta: 'Petite maison|la petite maison|f', albero: "Arbre|l'arbre|m", razzo: 'Fusée|la fusée|f', ponte: 'Pont|le pont|m', gatto: 'Chat|le chat|m',
      pesce: 'Poisson|le poisson|m', barca: 'Bateau|le bateau|m', macchina: 'Voiture|la voiture|f', aereo: "Avion|l'avion|m", fungo: 'Champignon|le champignon|m', stella: "Étoile|l'étoile|f", corona: 'Couronne|la couronne|f',
      casa: 'Maison|la maison|f', treno: 'Train|le train|m', robot: 'Robot|le robot|m', granchio: 'Crabe|le crabe|m', castello: 'Château|le château|m', pinguino: 'Pingouin|le pingouin|m', balena: 'Baleine|la baleine|f',
      velieri: 'Voilier|le voilier|m', nave: 'Navire|le navire|m', dinosauro: 'Dinosaure|le dinosaure|m', camion: 'Camion|le camion|m', trattore: 'Tracteur|le tracteur|m', torre: 'Tour|la tour|f' },
    de: { quadrato: 'Quadrat|das Quadrat', montagna: 'Berg|den Berg', zeta: 'Zickzack|den Zickzack', elle: 'L|das L', croce: 'Kreuz|das Kreuz', ti: 'T|das T', gradini: 'Treppe|die Treppe', scatola: 'Schachtel|die Schachtel',
      freccia: 'Pfeil|den Pfeil', coppa: 'Pokal|den Pokal', casetta: 'Häuschen|das Häuschen', albero: 'Baum|den Baum', razzo: 'Rakete|die Rakete', ponte: 'Brücke|die Brücke', gatto: 'Katze|die Katze', pesce: 'Fisch|den Fisch',
      barca: 'Boot|das Boot', macchina: 'Auto|das Auto', aereo: 'Flugzeug|das Flugzeug', fungo: 'Pilz|den Pilz', stella: 'Stern|den Stern', corona: 'Krone|die Krone', casa: 'Haus|das Haus', treno: 'Zug|den Zug', robot: 'Roboter|den Roboter',
      granchio: 'Krabbe|die Krabbe', castello: 'Burg|die Burg', pinguino: 'Pinguin|den Pinguin', balena: 'Wal|den Wal', velieri: 'Segelboot|das Segelboot', nave: 'Schiff|das Schiff', dinosauro: 'Dinosaurier|den Dinosaurier',
      camion: 'Lastwagen|den Lastwagen', trattore: 'Traktor|den Traktor', torre: 'Turm|den Turm' },
    ja: { quadrato: '四角', montagna: '山', zeta: 'ジグザグ', elle: 'L字', croce: '十字', ti: 'T字', gradini: '階段', scatola: '箱', freccia: '矢印', coppa: 'カップ', casetta: '小さな家', albero: '木', razzo: 'ロケット', ponte: '橋',
      gatto: 'ねこ', pesce: '魚', barca: 'ボート', macchina: '車', aereo: '飛行機', fungo: 'きのこ', stella: '星', corona: '王冠', casa: '家', treno: '電車', robot: 'ロボット', granchio: 'カニ', castello: 'お城', pinguino: 'ペンギン',
      balena: 'クジラ', velieri: 'ヨット', nave: '船', dinosauro: '恐竜', camion: 'トラック', trattore: 'トラクター', torre: '塔' },
    'zh-Hant': { quadrato: '正方形', montagna: '山', zeta: '之字形', elle: 'L形', croce: '十字', ti: 'T形', gradini: '階梯', scatola: '盒子', freccia: '箭頭', coppa: '獎盃', casetta: '小房子', albero: '樹', razzo: '火箭', ponte: '橋',
      gatto: '貓', pesce: '魚', barca: '小船', macchina: '汽車', aereo: '飛機', fungo: '蘑菇', stella: '星星', corona: '皇冠', casa: '房子', treno: '火車', robot: '機器人', granchio: '螃蟹', castello: '城堡', pinguino: '企鵝',
      balena: '鯨魚', velieri: '帆船', nave: '大船', dinosauro: '恐龍', camion: '卡車', trattore: '拖拉機', torre: '塔' },
    'zh-Hans': { quadrato: '正方形', montagna: '山', zeta: '之字形', elle: 'L形', croce: '十字', ti: 'T形', gradini: '阶梯', scatola: '盒子', freccia: '箭头', coppa: '奖杯', casetta: '小房子', albero: '树', razzo: '火箭', ponte: '桥',
      gatto: '猫', pesce: '鱼', barca: '小船', macchina: '汽车', aereo: '飞机', fungo: '蘑菇', stella: '星星', corona: '皇冠', casa: '房子', treno: '火车', robot: '机器人', granchio: '螃蟹', castello: '城堡', pinguino: '企鹅',
      balena: '鲸鱼', velieri: '帆船', nave: '大船', dinosauro: '恐龙', camion: '卡车', trattore: '拖拉机', torre: '塔' }
  };
  var FINE = { en: '{N} done!', es: { m: '¡{N} terminado!', f: '¡{N} terminada!', mp: '¡{N} terminados!' }, pt: { m: '{N} pronto!', f: '{N} pronta!', mp: '{N} prontos!' },   // the title when the shape is full
    fr: { m: '{N} terminé !', f: '{N} terminée !', fp: '{N} terminées !' }, de: '{N} fertig!', ja: '{N}、完成！', zh: '{N}完成了！' };
  var COL = [['#FF9383', '#EE5E4D', '#C7402F'], ['#FFE98A', '#FFD95A', '#E8B52E'], ['#A9D3FF', '#7DB7F7', '#5791DB'], ['#B4ECAE', '#8DD68A', '#62B660'], ['#A6ECE6', '#4FC3C7', '#2E9AA1'], ['#FFC894', '#F2A65A', '#D98535']], CNAME = PICK({ it: ['rosso', 'giallo', 'blu', 'verde', 'turchese', 'arancione'], en: ['red', 'yellow', 'blue', 'green', 'turquoise', 'orange'],
    es: ['roja', 'amarilla', 'azul', 'verde', 'turquesa', 'naranja'], pt: ['vermelha', 'amarela', 'azul', 'verde', 'turquesa', 'laranja'], fr: ['rouge', 'jaune', 'bleue', 'verte', 'turquoise', 'orange'],
    de: ['rote', 'gelbe', 'blaue', 'grüne', 'türkise', 'orange'], ja: ['赤い', '黄色い', '青い', '緑の', '水色の', 'オレンジの'], 'zh-Hant': ['紅色', '黃色', '藍色', '綠色', '藍綠色', '橘色'], 'zh-Hans': ['红色', '黄色', '蓝色', '绿色', '蓝绿色', '橙色'] });
  var G, placed, hist, slots, els, W, H, bx, by, S = 0.58, drag = null, piecesG, ghostG, fxG;
  function dot(x, y, r, f) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + (f || INK) + '"/>'; }
  function defs() {
    var s = '<defs><linearGradient id="gTable" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F3D9B1"/><stop offset="1" stop-color="#DDB884"/></linearGradient>' +
      '<radialGradient id="gVig" cx="50%" cy="45%" r="75%"><stop offset=".55" stop-color="#5A3A1A" stop-opacity="0"/><stop offset="1" stop-color="#5A3A1A" stop-opacity=".28"/></radialGradient>' +
      '<linearGradient id="gRim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E2B07A"/><stop offset="1" stop-color="#B57E48"/></linearGradient>' +
      '<linearGradient id="gSlot" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#A97B4C"/><stop offset="1" stop-color="#C79A68"/></linearGradient>' +
      '<linearGradient id="gFelt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#CFE6C4"/><stop offset="1" stop-color="#E6F4DE"/></linearGradient>';
    COL.forEach(function (c, i) { s += '<linearGradient id="gp' + i + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + c[0] + '"/><stop offset=".55" stop-color="' + c[1] + '"/><stop offset="1" stop-color="' + c[2] + '"/></linearGradient>'; });
    return s + '</defs>';
  }
  function art(p) {
    var has = {}, body = '', sil = '', edge = '', hi = '', lo = '', inner = '', ci = p.id % COL.length;
    p.cells.forEach(function (c) { has[c[0] + ',' + c[1]] = 1; });
    p.cells.forEach(function (c) {
      var x = c[0] * 100, y = c[1] * 100, up = has[c[0] + ',' + (c[1] - 1)], dn = has[c[0] + ',' + (c[1] + 1)], lf = has[(c[0] - 1) + ',' + c[1]], rt = has[(c[0] + 1) + ',' + c[1]];
      body += '<rect x="' + (x - 0.5) + '" y="' + (y - 0.5) + '" width="101" height="101" fill="url(#gp' + ci + ')"/><ellipse cx="' + (x + 30) + '" cy="' + (y + 22) + '" rx="17" ry="8" fill="#fff" opacity=".5" transform="rotate(-20 ' + (x + 30) + ' ' + (y + 22) + ')"/>';
      sil += '<rect x="' + x + '" y="' + y + '" width="100" height="100"/>';
      if (!up) { edge += 'M' + x + ' ' + y + 'h100'; hi += 'M' + (x + (lf ? 0 : 11)) + ' ' + (y + 11) + 'H' + (x + (rt ? 100 : 89)); } else inner += 'M' + (x + 18) + ' ' + y + 'h64';
      if (!dn) { edge += 'M' + x + ' ' + (y + 100) + 'h100'; lo += 'M' + (x + (lf ? 0 : 11)) + ' ' + (y + 89) + 'H' + (x + (rt ? 100 : 89)); }
      if (!lf) { edge += 'M' + x + ' ' + y + 'v100'; hi += 'M' + (x + 11) + ' ' + (y + (up ? 0 : 11)) + 'V' + (y + (dn ? 100 : 89)); } else inner += 'M' + x + ' ' + (y + 18) + 'v64';
      if (!rt) { edge += 'M' + (x + 100) + ' ' + y + 'v100'; lo += 'M' + (x + 89) + ' ' + (y + (up ? 0 : 11)) + 'V' + (y + (dn ? 100 : 89)); }
    });
    var f = p.cells[0], fx = f[0] * 100 + 50, fy = f[1] * 100 + 56;
    return '<g class="shadowp" fill="#3A2410">' + sil + '</g>' + body +
      '<path d="' + inner + '" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="5" stroke-linecap="round"/><path d="' + hi + '" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="7" stroke-linecap="round"/><path d="' + lo + '" fill="none" stroke="#000" stroke-opacity=".17" stroke-width="7" stroke-linecap="round"/>' +
      '<g class="flash" fill="#fff">' + sil + '</g><path d="' + edge + '" fill="none"' + K.k(9) + '/>' +
      '<g class="blink" style="--d:' + (-p.id * 0.9) + 's"><ellipse cx="' + (fx - 16) + '" cy="' + (fy - 8) + '" rx="7" ry="8.5" fill="' + INK + '"/><ellipse cx="' + (fx + 16) + '" cy="' + (fy - 8) + '" rx="7" ry="8.5" fill="' + INK + '"/>' + dot(fx - 13.5, fy - 11, 2.6, '#fff') + dot(fx + 18.5, fy - 11, 2.6, '#fff') + '</g>' +
      '<path class="m1" d="M' + (fx - 12) + ' ' + (fy + 10) + 'q12 11 24 0" fill="none"' + K.k(4.5) + '/><ellipse class="m2" cx="' + fx + '" cy="' + (fy + 15) + '" rx="7" ry="8.5" fill="#7A3B46"' + K.k(3.5) + '/>' +
      '<path class="m3" d="M' + (fx - 14) + ' ' + (fy + 8) + 'h28q-2 16 -14 16t-14 -16Z" fill="#7A3B46"' + K.k(3.5) + '/>' + dot(fx - 30, fy + 8, 7, '#fff') + dot(fx + 30, fy + 8, 7, '#fff');
  }
  function setT(i, x, y, s) { var e = els[i]; e._x = x; e._y = y; e._s = s; e.setAttribute('transform', 'translate(' + x.toFixed(1) + ',' + y.toFixed(1) + ') scale(' + s.toFixed(3) + ')'); }
  function home(i) { return placed[i] ? [bx + placed[i][0] * 100, by + placed[i][1] * 100, 1] : [slots[i][0], slots[i][1], S]; }
  function glide(i, ms, done) { var e = els[i], t = home(i), x0 = e._x, y0 = e._y, s0 = e._s; e.classList.toggle('placed', !!placed[i]); K.tween(ms, function (q) { var k2 = q * q * (3 - 2 * q); setT(i, x0 + (t[0] - x0) * k2, y0 + (t[1] - y0) * k2, s0 + (t[2] - s0) * k2); }, done); }

  function load(n) {
    G = IN.parse(RAW[n]); placed = G.pieces.map(function () { return null; }); hist = []; drag = null;
    W = Math.max(G.w * 100 + 150, 620); bx = (W - G.w * 100) / 2; by = 92;
    var order = G.pieces.map(function (p, i) { return i; }), r = n * 7 + 3, i, j, t;
    for (i = order.length - 1; i > 0; i--) { r = (r * 1103515245 + 12345) % 2147483648; j = r % (i + 1); t = order[i]; order[i] = order[j]; order[j] = t; }
    var x = 64, y = by + G.h * 100 + 116, rowH = 0; slots = [];
    order.forEach(function (pi) { var p = G.pieces[pi], pw = p.pw * 100 * S, ph = p.ph * 100 * S; if (x + pw > W - 64) { x = 64; y += rowH + 30; rowH = 0; } slots[pi] = [x, y]; x += pw + 34; rowH = Math.max(rowH, ph); });
    var trayTop = by + G.h * 100 + 74, trayBot = y + rowH + 42; H = trayBot + 46;
    scene.setAttribute('viewBox', '0 0 ' + W + ' ' + H); scene.style.setProperty('--scene-bg', '#E8C898');
    var s = defs() + '<rect x="-3000" y="-3000" width="9000" height="9000" fill="url(#gTable)"/>', cx, cy, k2;
    for (k2 = -6; k2 < 26; k2++) s += '<path d="M-3000 ' + (k2 * 58 + 20) + 'q' + (400 + (k2 * 37) % 160) + ' ' + (14 - (k2 * 11) % 28) + ' 1500 0t1500 0 1500 0 1500 0" fill="none" stroke="#B98D55" stroke-width="' + (2 + k2 % 3) + '" opacity=".22"/>';   // wood grain
    s += '<rect x="-3000" y="-3000" width="9000" height="9000" fill="url(#gVig)"/>';
    for (k2 = 0; k2 < 7; k2++) s += '<g class="twinkle" style="--d:' + (-k2 * 0.7) + 's">' + K.star(30 + (k2 * 173) % (W - 60), 24 + (k2 * 97) % 46, 9, '#FFF6D6', 0) + '</g>';
    // the wooden tray with its carved slots
    s += '<g class="world"><rect x="' + (bx - 30) + '" y="' + (by - 18) + '" width="' + (G.w * 100 + 60) + '" height="' + (G.h * 100 + 62) + '" rx="34" fill="#5A3A1A" opacity=".3"/>' +
      '<rect x="' + (bx - 34) + '" y="' + (by - 34) + '" width="' + (G.w * 100 + 68) + '" height="' + (G.h * 100 + 68) + '" rx="34" fill="url(#gRim)"' + K.k(5) + '/>' +
      '<path d="M' + (bx - 22) + ' ' + (by + G.h * 100) + 'V' + (by - 10) + 'a12 12 0 0 1 12 -12H' + (bx + G.w * 100) + '" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".45"/>';
    var out = '';                                                 // the outline of the whole silhouette, so the shape is clear before a single piece is placed
    for (cy = 0; cy < G.h; cy++) for (cx = 0; cx < G.w; cx++) if (G.board[cy][cx]) {
      var sx = bx + cx * 100, sy = by + cy * 100;
      if (cy === 0 || !G.board[cy - 1][cx]) out += 'M' + sx + ' ' + sy + 'h100';
      if (cy === G.h - 1 || !G.board[cy + 1][cx]) out += 'M' + sx + ' ' + (sy + 100) + 'h100';
      if (cx === 0 || !G.board[cy][cx - 1]) out += 'M' + sx + ' ' + sy + 'v100';
      if (cx === G.w - 1 || !G.board[cy][cx + 1]) out += 'M' + (sx + 100) + ' ' + sy + 'v100';
      s += '<rect x="' + (sx + 4) + '" y="' + (sy + 4) + '" width="92" height="92" rx="16" fill="url(#gSlot)"/><path d="M' + (sx + 10) + ' ' + (sy + 84) + 'V' + (sy + 20) + 'a10 10 0 0 1 10 -10H' + (sx + 84) + '" fill="none" stroke="#5A3A1A" stroke-width="5" stroke-linecap="round" opacity=".38"/>' +
        '<path d="M' + (sx + 90) + ' ' + (sy + 18) + 'V' + (sy + 80) + 'a10 10 0 0 1 -10 10H' + (sx + 18) + '" fill="none" stroke="#FFE7C2" stroke-width="4" stroke-linecap="round" opacity=".6"/>';
    }
    s += '<path d="' + out + '" fill="none" stroke="#5A3A1A" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" opacity=".55" transform="translate(4,6)"/>' +
      '<path d="' + out + '" fill="none" stroke="#FFF1DA" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" opacity=".85"/>';
    // the drawer: wood outside, felt inside
    s += '<rect x="30" y="' + (trayTop + 10) + '" width="' + (W - 60) + '" height="' + (trayBot - trayTop) + '" rx="32" fill="#5A3A1A" opacity=".28"/><rect x="26" y="' + trayTop + '" width="' + (W - 52) + '" height="' + (trayBot - trayTop) + '" rx="32" fill="url(#gRim)"' + K.k(5) + '/>' +
      '<rect x="44" y="' + (trayTop + 18) + '" width="' + (W - 88) + '" height="' + (trayBot - trayTop - 36) + '" rx="20" fill="url(#gFelt)"' + K.k(4) + '/><path d="M56 ' + (trayBot - 34) + 'V' + (trayTop + 44) + 'a12 12 0 0 1 12 -12H' + (W - 70) + '" fill="none" stroke="#5A7A4A" stroke-width="5" stroke-linecap="round" opacity=".25"/>';
    s += '<clipPath id="bclip"><rect x="' + bx + '" y="' + by + '" width="' + (G.w * 100) + '" height="' + (G.h * 100) + '" rx="14"/></clipPath><g id="ghostG"></g><g id="piecesG">';
    G.pieces.forEach(function (p) { s += '<g class="piece" data-p="' + p.id + '" style="--d:' + (-p.id * 0.55) + 's"><g class="pi">' + art(p) + '</g></g>'; });
    scene.innerHTML = s + '</g><g id="shineG" clip-path="url(#bclip)"></g></g><g id="fxG"></g>';
    piecesG = scene.querySelector('#piecesG'); ghostG = scene.querySelector('#ghostG'); fxG = scene.querySelector('#fxG');
    els = G.pieces.map(function (p) { return piecesG.querySelector('[data-p="' + p.id + '"]'); });
    G.pieces.forEach(function (p, i2) { setT(i2, slots[i2][0], slots[i2][1], S); });
    var nm = NOMI[RAW[n].n], f, fine;
    if (LANG === 'it') {
      var fin = !nm ? '' : /^la /.test(nm[0]) ? ' finita!' : /^i /.test(nm[0]) ? ' finiti!' : /^le /.test(nm[0]) ? ' finite!' : ' finito!';   // the ending agrees with the name
      CFG.winTitle = nm ? nm[1] + fin : 'Tutto incastrato!';
      return nm ? L('Riempi {x} con i pezzi del cassetto.', 'Fill {x} with the pieces from the drawer.', { x: nm[0] }) : '';
    }
    f = (PICK(NOMI_L)[String(RAW[n].n).replace(/2$/, '')] || '').split('|');
    if (!f[0]) { CFG.winTitle = L('Tutto incastrato!', 'All in place!'); return ''; }
    fine = PICK(FINE); if (typeof fine !== 'string') fine = fine[f[2]] || fine.m || fine.f;
    CFG.winTitle = fine.replace('{N}', f[0]);
    return L('Riempi {x} con i pezzi del cassetto.', 'Fill {x} with the pieces from the drawer.', { x: f[1] || f[0] });
  }
  function pt(e) { var b = scene.getBoundingClientRect(), s = Math.min(b.width / W, b.height / H); return { x: (e.clientX - b.left - (b.width - W * s) / 2) / s, y: (e.clientY - b.top - (b.height - H * s) / 2) / s }; }
  function ghost(cells, color, cls) { ghostG.innerHTML = cells.map(function (c) { return '<rect class="' + (cls || '') + '" x="' + (bx + c[0] * 100 + 6) + '" y="' + (by + c[1] * 100 + 6) + '" width="88" height="88" rx="15" fill="' + color + '" stroke="#fff" stroke-width="4" stroke-dasharray="10 9"/>'; }).join(''); }
  function snap() {                                   // where the held piece would land, if it fits there
    var d = drag, p = G.pieces[d.i], gx = Math.round((els[d.i]._x - bx) / 100), gy = Math.round((els[d.i]._y - by) / 100);
    d.spot = IN.fits(G, IN.grid(G, placed), p, gx, gy) ? [gx, gy] : null;
    if (d.spot) ghost(p.cells.map(function (c) { return [gx + c[0], gy + c[1]]; }), '#9BF0A2', 'ghostc'); else ghostG.innerHTML = '';
  }
  scene.addEventListener('pointerdown', function (e) {
    if (K.isWon() || drag || (e.pointerType === 'mouse' && e.button !== 0)) return; var g = e.target.closest ? e.target.closest('.piece') : null; if (!g) return;
    e.preventDefault(); clearHint(); var i = +g.getAttribute('data-p'), q = pt(e), el = els[i];
    drag = { i: i, pid: e.pointerId, lx: (q.x - el._x) / el._s, ly: (q.y - el._y) / el._s, from: placed[i], moved: false, spot: null }; placed[i] = null;
    piecesG.appendChild(el); el.classList.remove('pop', 'placed'); el.classList.add('drag'); K.sfx('pick'); try { scene.setPointerCapture(e.pointerId); } catch (err) {}
  });
  scene.addEventListener('pointermove', function (e) {
    if (!drag || e.pointerId !== drag.pid) return; var q = pt(e), p = G.pieces[drag.i]; drag.moved = true;
    setT(drag.i, q.x - Math.min(drag.lx, p.pw * 100) , q.y - drag.ly - 64, 1); snap();
  });
  function up(e) {
    if (!drag || e.pointerId !== drag.pid) return; var d = drag, el = els[d.i]; drag = null; el.classList.remove('drag'); ghostG.innerHTML = '';
    if (d.moved && d.spot) {
      placed[d.i] = d.spot; hist.push({ p: d.i, from: d.from, to: d.spot });
      glide(d.i, 90, function () { el.classList.add('pop'); }); K.sfx('place', placed.filter(function (q) { return !!q; }).length - 1); K.buzz(10); K.changed();   // each piece plays the next note up
      if (placed.every(function (x) { return !!x; })) { els.forEach(function (pe, n) { pe.style.setProperty('--pd', (n * 0.09) + 's'); pe.classList.remove('pop'); pe.classList.add('party'); }); K.sparkle(fxG, W / 2, by + G.h * 50, 20); K.confetti(fxG, W, H); alive(); scene.querySelector('#shineG').innerHTML = '<rect class="shine" x="' + bx + '" y="' + (by - 40) + '" width="' + (G.w * 38) + '" height="' + (G.h * 100 + 80) + '" fill="#fff" opacity=".55"/>'; K.win(); }
    } else {
      if (!d.moved) placed[d.i] = d.from; else if (d.from) hist.push({ p: d.i, from: d.from, to: null });   // taken off the board: allowed, and it is not a move
      glide(d.i, 200); if (d.moved) K.sfx('back'); K.changed();
    }
  }
  scene.addEventListener('pointerup', up); scene.addEventListener('pointercancel', up);
  scene.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  function clearHint() { if (ghostG) ghostG.innerHTML = ''; if (els) els.forEach(function (e) { e.classList.remove('hintp'); }); }
  var CFG = {
    key: 'incastri.v1', count: RAW.length, perTier: 24, moveLabel: L('Mosse', 'Moves'), word: [L('mossa', 'move'), L('mosse', 'moves')], winTitle: L('Tutto incastrato!', 'All in place!'), winDelay: 1500,
    intro: L('Trascina i pezzi dal cassetto fino a riempire tutta la sagoma. I pezzi non si girano.', 'Drag the pieces from the drawer until the whole shape is filled. The pieces do not turn.'),
    rules: [L('Riempi tutta la sagoma con i pezzi del cassetto.', 'Fill the whole shape with the pieces from the drawer.'), L('I pezzi si trascinano così come sono: non si possono girare.', 'Pieces are dragged as they are: they cannot be turned.'), L('Un pezzo già messo si può riprendere e spostare, o riportare nel cassetto.', 'A piece already placed can be picked up again and moved, or put back in the drawer.'), L('Conta una mossa ogni pezzo appoggiato sulla sagoma: il minimo è un pezzo, una mossa.', 'Each piece set down on the shape counts as one move: the fewest is one piece, one move.')],
    minOf: function (i) { return RAW[i].m; }, load: load, moves: function () { return hist ? hist.filter(function (h) { return h.to; }).length : 0; }, canUndo: function () { return hist && hist.length > 0 && !drag; },
    undo: function () { var h = hist.pop(); placed[h.p] = h.from; piecesG.appendChild(els[h.p]); els[h.p].classList.remove('pop'); glide(h.p, 200); K.sfx('back'); K.changed(); },
    clearHint: clearHint,
    hint: function () {
      if (drag) return null; var sol = IN.solve(G, placed), i;
      if (sol) { for (i = 0; i < sol.length; i++) if (!placed[i]) break; var p = G.pieces[i]; els[i].classList.add('hintp'); ghost(p.cells.map(function (c) { return [sol[i][0] + c[0], sol[i][1] + c[1]]; }), '#FF8A3D', 'ghostc');
        return L('Il pezzo {c} va dove lampeggia l\'arancione.', 'The {c} piece goes where the orange is flashing.', { c: CNAME[i % CNAME.length] }); }
      for (i = 0; i < placed.length; i++) { if (!placed[i]) continue; var trial = placed.slice(); trial[i] = null; if (IN.solve(G, trial)) { els[i].classList.add('hintp'); return L('Così gli altri non ci stanno: togli il pezzo {c} e riprova.', 'The others will not fit like this: take the {c} piece away and try again.', { c: CNAME[i % CNAME.length] }); } }
      return L('Riporta i pezzi nel cassetto e riparti.', 'Put the pieces back in the drawer and start again.');
    }
  };
  K.start(CFG);
})();
