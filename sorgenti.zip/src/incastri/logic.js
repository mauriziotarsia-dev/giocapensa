/* Incastri rules (no DOM): a silhouette, pieces that keep their orientation, and a small exact-cover solver for the hints. */
(function (root) {
  'use strict';
  function parse(L) {
    var rows = L.g.split('/'), board = [], by = {}, x, y, ch;
    for (y = 0; y < L.h; y++) { board.push([]); for (x = 0; x < L.w; x++) { ch = rows[y].charAt(x); board[y].push(ch !== '.'); if (ch !== '.') (by[ch] = by[ch] || []).push([x, y]); } }
    var pieces = Object.keys(by).sort().map(function (k, i) {
      var cs = by[k], mx = Math.min.apply(null, cs.map(function (c) { return c[0]; })), my = Math.min.apply(null, cs.map(function (c) { return c[1]; }));
      var rel = cs.map(function (c) { return [c[0] - mx, c[1] - my]; });
      return { id: i, cells: rel, pw: Math.max.apply(null, rel.map(function (c) { return c[0]; })) + 1, ph: Math.max.apply(null, rel.map(function (c) { return c[1]; })) + 1, home: [mx, my] };
    });
    return { w: L.w, h: L.h, board: board, pieces: pieces, min: L.m };
  }
  function grid(G, placed, skip) {
    var occ = G.board.map(function (r) { return r.map(function (b) { return b ? -1 : -2; }); });   // -2 outside, -1 empty, n = piece
    placed.forEach(function (pos, i) { if (pos && i !== skip) G.pieces[i].cells.forEach(function (c) { occ[pos[1] + c[1]][pos[0] + c[0]] = i; }); });
    return occ;
  }
  function fits(G, occ, piece, x, y) {
    for (var k = 0; k < piece.cells.length; k++) { var cx = x + piece.cells[k][0], cy = y + piece.cells[k][1]; if (cx < 0 || cy < 0 || cx >= G.w || cy >= G.h || occ[cy][cx] !== -1) return false; }
    return true;
  }
  // complete the current placement: positions for every piece, or null when what is on the board cannot be finished
  function solve(G, placed) {
    var occ = grid(G, placed), pos = placed.slice();
    function rec() {
      var x, y, tx = -1, ty = -1, i, k;
      for (y = 0; y < G.h && tx < 0; y++) for (x = 0; x < G.w; x++) if (occ[y][x] === -1) { tx = x; ty = y; break; }
      if (tx < 0) return pos.every(function (p) { return !!p; });
      for (i = 0; i < G.pieces.length; i++) {
        if (pos[i]) continue; var p = G.pieces[i];
        for (k = 0; k < p.cells.length; k++) {
          var ox = tx - p.cells[k][0], oy = ty - p.cells[k][1]; if (!fits(G, occ, p, ox, oy)) continue;
          p.cells.forEach(function (c) { occ[oy + c[1]][ox + c[0]] = i; }); pos[i] = [ox, oy];
          if (rec()) return true;
          p.cells.forEach(function (c) { occ[oy + c[1]][ox + c[0]] = -1; }); pos[i] = null;
        }
      }
      return false;
    }
    return rec() ? pos : null;
  }
  root.IN = { parse: parse, grid: grid, fits: fits, solve: solve };
})(typeof window !== 'undefined' ? window : globalThis);
