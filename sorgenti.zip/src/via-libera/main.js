(function () {
  'use strict';
  var RAW = window.VL_LEVELS, VL = window.VL, PER_TIER = 32, KEY = 'via-libera.v2', OLD_KEY = 'via-libera.v1', MAX_SAVES = 20;
  var TIERS = [
    { name: 'Principiante', color: '#27AE86', ink: '#04241A' },
    { name: 'Intermedio', color: '#F3B61F', ink: '#2A1E00' },
    { name: 'Avanzato', color: '#2D5BDA', ink: '#FFFFFF' },
    { name: 'Esperto', color: '#E8452E', ink: '#2B0803' },
    { name: 'Maestro', color: '#A30F2D', ink: '#FFFFFF' }
  ];
  var $ = function (id) { return document.getElementById(id); };
  var grid = $('grid'), ghost = $('ghost'), statusEl = $('status'), exitEl = $('exit'), result = $('result'), controls = $('controls');
  var sheet = $('sheet'), menu = $('menu'), nameDlg = $('nameDlg'), confirmDlg = $('confirm');
  function now() { return Date.now(); }
  function clampInt(n, lo, hi) { n = Math.floor(+n); if (!isFinite(n)) n = lo; return Math.max(lo, Math.min(hi, n)); }
  function esc(t) { return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function openDlg(d) { if (d.showModal) { if (!d.open) d.showModal(); } else d.setAttribute('open', ''); }
  function closeDlg(d) { if (d.close) { if (d.open) d.close(); } else d.removeAttribute('open'); }

  /* =====================================================================
     Saved games. Every game has a name and is saved automatically: always on
     this device, and in the viewer's Claude account when the page can reach it.
     ===================================================================== */
  var store = { saves: {}, active: '', sound: true, hintMode: 'attesa' }, freshDefault = false, touched = false;
  var HINT_MODES = ['subito', 'attesa', 'mai'];
  var SKIN_ORDER = ['cars', 'medieval', 'harbor', 'pixel', 'pastel'];
  function newId() { return 's' + now().toString(36) + Math.floor(Math.random() * 1679616).toString(36); }
  function cleanSave(o, id) {
    if (!o || typeof o !== 'object') return null;
    var s = { id: id, name: String(o.name == null ? 'Partita' : o.name).trim().slice(0, 24) || 'Partita', created: +o.created || now(), updated: +o.updated || 0,
      level: clampInt(o.level, 0, RAW.length - 1), skin: SKIN_ORDER.indexOf(o.skin) >= 0 ? o.skin : 'cars', best: {}, board: null, deleted: !!o.deleted };
    if (o.best && typeof o.best === 'object') Object.keys(o.best).forEach(function (k) { var lv = Math.floor(+k), n = Math.floor(+o.best[k]); if (lv >= 1 && lv <= RAW.length && isFinite(n) && n > 0) s.best[lv] = n; });
    var b = o.board;
    if (b && typeof b === 'object' && Array.isArray(b.pos) && b.pos.length <= 20) {
      s.board = { level: clampInt(b.level, 0, RAW.length - 1), pos: b.pos.map(function (x) { return clampInt(x, 0, 4); }), base: clampInt(b.base, 0, 100000), hist: [] };
      if (Array.isArray(b.hist)) s.board.hist = b.hist.filter(function (h) { return Array.isArray(h) && h.length === 3; }).slice(-400).map(function (h) { return [clampInt(h[0], 0, 19), clampInt(h[1], 0, 4), clampInt(h[2], 0, 4)]; });
    }
    return s;
  }
  function blankSave(name, level, skin) { var t = now(); return { id: newId(), name: name, created: t, updated: t, level: level, skin: skin || 'cars', best: {}, board: null, deleted: false }; }
  function liveSaves() { return Object.keys(store.saves).map(function (id) { return store.saves[id]; }).filter(function (s) { return !s.deleted; }).sort(function (a, b) { return b.updated - a.updated; }); }
  function S() { return store.saves[store.active]; }
  function saveLocal() { try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) {} }
  function ensureActive() {
    if (S() && !S().deleted) return;
    var l = liveSaves();
    if (l.length) store.active = l[0].id;
    else { var d = blankSave('Partita 1', 0); store.saves[d.id] = d; store.active = d.id; freshDefault = true; }
  }
  function loadLocal() {
    try {
      var raw = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (raw && typeof raw === 'object') {
        if (raw.saves && typeof raw.saves === 'object') Object.keys(raw.saves).forEach(function (id) { var s = cleanSave(raw.saves[id], id); if (s && !(s.deleted && now() - s.updated > 30 * 864e5)) store.saves[id] = s; });
        if (typeof raw.active === 'string') store.active = raw.active;
        if (typeof raw.sound === 'boolean') store.sound = raw.sound;
        if (HINT_MODES.indexOf(raw.hintMode) >= 0) store.hintMode = raw.hintMode;
      }
    } catch (e) {}
    if (!liveSaves().length) {
      try { // progress made with the first version of the game
        var old = JSON.parse(localStorage.getItem(OLD_KEY) || 'null');
        if (old && typeof old === 'object') { var m = cleanSave({ name: 'Partita 1', created: now(), updated: now(), level: old.last, best: old.best }, newId()); store.saves[m.id] = m; store.active = m.id; if (typeof old.sound === 'boolean') store.sound = old.sound; }
      } catch (e) {}
    }
    ensureActive();
  }

  var cloud = { state: 'off', col: null, dirty: {}, busy: false, timer: 0, fails: 0, refused: 0 };
  function mergeSave(l, r) {
    var newer = r.updated > l.updated ? r : l, m = JSON.parse(JSON.stringify(newer)), changed = newer === l && l.updated !== r.updated;
    m.id = l.id; m.created = Math.min(l.created, r.created);
    [l, r].forEach(function (s) { Object.keys(s.best).forEach(function (k) { if (!m.best[k] || s.best[k] < m.best[k]) m.best[k] = s.best[k]; }); });
    if (JSON.stringify(m.best) !== JSON.stringify(r.best)) changed = true;
    return { save: m, upload: changed };
  }
  function boardKey(s) { return s ? s.id + '|' + s.level + '|' + s.skin + '|' + JSON.stringify(s.board) : ''; }
  function mergeFromCloud(snap) {
    var remote = {}, before = boardKey(S());
    snap.docs.forEach(function (d) { var s = cleanSave(d.data(), d.id); if (s) remote[d.id] = s; });
    var remoteLive = Object.keys(remote).some(function (id) { return !remote[id].deleted; });
    if (freshDefault && !touched && remoteLive) { delete store.saves[store.active]; store.active = ''; } // an untouched placeholder gives way to the real saves
    freshDefault = false;
    Object.keys(remote).forEach(function (id) {
      var l = store.saves[id];
      if (!l) { store.saves[id] = remote[id]; return; }
      var m = mergeSave(l, remote[id]); store.saves[id] = m.save; if (m.upload) cloud.dirty[id] = 1;
    });
    Object.keys(store.saves).forEach(function (id) { if (!remote[id]) cloud.dirty[id] = 1; });
    ensureActive(); saveLocal(); pump();
    if (!touched && boardKey(S()) !== before) applyActive('');
    refreshOpenPanels();
  }
  function cloudInit() {
    if (!(window.claude && typeof window.claude.use === 'function')) return;
    cloud.state = 'pending';
    Promise.all([window.claude.use('db'), window.claude.use('user')]).then(function (r) {
      if (!r[0] || !r[1]) throw new Error('no cloud here');
      return r[1].id().then(function (uid) { if (!uid) throw new Error('no identity'); cloud.col = r[0].collection('data/users/' + uid); return cloud.col.get(); });
    }).then(function (snap) { cloud.state = 'on'; mergeFromCloud(snap); }).catch(function () { cloud.state = 'off'; cloud.col = null; refreshOpenPanels(); });
  }
  function pump() {
    if (cloud.state !== 'on' || cloud.busy) return;
    var id = Object.keys(cloud.dirty)[0]; if (!id) return;
    delete cloud.dirty[id];
    var s = store.saves[id]; if (!s) { pump(); return; }
    var body = JSON.parse(JSON.stringify(s)); delete body.id;
    cloud.busy = true;
    var ref; try { ref = cloud.col.doc(id); } catch (e) { cloud.busy = false; pump(); return; }
    ref.set(body).then(function () { cloud.busy = false; cloud.fails = 0; cloud.refused = 0; pump(); }, function (e) {
      cloud.busy = false; var code = e && e.code;
      if ((code === 'unavailable' || code === 'resource_exhausted') && ++cloud.fails < 4) { cloud.dirty[id] = 1; setTimeout(pump, 8000); }
      else if (code === 'invalid_argument' || code === 'quota_exceeded' || code === 'transform_error') { if (++cloud.refused >= 2) { cloud.state = 'off'; refreshOpenPanels(); } else pump(); }
      else { cloud.state = 'off'; refreshOpenPanels(); }
    });
  }
  function cloudSoon(id) { cloud.dirty[id] = 1; clearTimeout(cloud.timer); cloud.timer = setTimeout(pump, 1800); }
  function cloudNow(id) { cloud.dirty[id] = 1; clearTimeout(cloud.timer); pump(); }
  function commitSave(urgent) { var s = S(); s.updated = now(); saveLocal(); if (urgent) cloudNow(s.id); else cloudSoon(s.id); }

  /* =====================================================================
     Sound. Web Audio only: on iPhone it follows the ring/silent switch.
     ===================================================================== */
  var AC = window.AudioContext || window.webkitAudioContext, actx = null, master = null, noiseBuf = null;
  function ensureAudio() {
    if (!store.sound || (window.OPZ && !OPZ.get('suoni')) || !AC) return null;
    try {
      if (!actx) {
        actx = new AC(); master = actx.createGain(); master.gain.value = 0.95;
        var comp = actx.createDynamicsCompressor(); master.connect(comp); comp.connect(actx.destination);
        var rn = Math.floor(actx.sampleRate * 1.2), ir = actx.createBuffer(2, rn, actx.sampleRate), rc, ri, rd;                 // a touch of room reverb, like the other games
        for (rc = 0; rc < 2; rc++) { rd = ir.getChannelData(rc); for (ri = 0; ri < rn; ri++) rd[ri] = (Math.random() * 2 - 1) * Math.pow(1 - ri / rn, 3.2) * (ri < 400 ? ri / 400 : 1); }
        var conv = actx.createConvolver(), wet = actx.createGain(); conv.buffer = ir; wet.gain.value = 0.2; master.connect(wet); wet.connect(conv); conv.connect(comp);
        var n = Math.floor(actx.sampleRate * 0.6), ch; noiseBuf = actx.createBuffer(1, n, actx.sampleRate); ch = noiseBuf.getChannelData(0);
        for (var i = 0; i < n; i++) ch[i] = Math.random() * 2 - 1;
      }
      if (actx.state !== 'running' && actx.resume) actx.resume();
      return actx;
    } catch (e) { return null; }
  }
  // iOS only starts audio from inside a touch/click handler: wake the context on every gesture until it runs.
  function wakeAudio() {
    var a = ensureAudio(); if (!a) return;
    try { var s = a.createBufferSource(); s.buffer = a.createBuffer(1, 1, 22050); s.connect(a.destination); s.start(0); } catch (e) {}
  }
  ['pointerdown', 'pointerup', 'touchstart', 'touchend', 'click', 'keydown'].forEach(function (ev) { window.addEventListener(ev, function () { if (store.sound && (!actx || actx.state !== 'running')) wakeAudio(); }, true); });
  document.addEventListener('visibilitychange', function () { if (document.hidden) { clearTimeout(cloud.timer); pump(); } });
  function tone(t, f0, f1, dur, type, vol, attack) {
    var o = actx.createOscillator(), g = actx.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + (attack || 0.006)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.05);
  }
  function hiss(t, dur, kind, f0, f1, q, vol) {
    var s = actx.createBufferSource(), f = actx.createBiquadFilter(), g = actx.createGain(); s.buffer = noiseBuf;
    f.type = kind; f.Q.value = q; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(master); s.start(t, Math.random() * 0.25, dur + 0.05);
  }
  function brass(t, freq, dur, vol, cutoff) { // two detuned saws through a low-pass: horns and trumpets
    var f = actx.createBiquadFilter(), g = actx.createGain(); f.type = 'lowpass'; f.frequency.value = cutoff; f.Q.value = 0.8;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.03); g.gain.setValueAtTime(vol, t + Math.max(0.04, dur - 0.06)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    [-5, 5].forEach(function (cents) { var o = actx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = freq; o.detune.value = cents; o.connect(f); o.start(t); o.stop(t + dur + 0.05); });
    f.connect(g); g.connect(master);
  }
  var SFX = {
    cars: {
      move: function (t, k) { hiss(t, 0.075, 'bandpass', 2600, 1300, 1.1, 0.6 * k); tone(t, 560, 330, 0.085, 'triangle', 0.5 * k); },
      block: function (t) { tone(t, 330, 220, 0.13, 'square', 0.16); hiss(t, 0.06, 'lowpass', 1200, 600, 0.7, 0.45); },
      win: function (t) { // two horn beeps, then a rising arpeggio
        [[0, 0.13], [0.19, 0.3]].forEach(function (b) { brass(t + b[0], 466, b[1], 0.22, 2400); brass(t + b[0], 587, b[1], 0.2, 2400); });
        [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) { tone(t + 0.62 + i * 0.1, f, f, 0.34, 'triangle', 0.32, 0.012); });
      }
    },
    medieval: {
      move: function (t, k) { [0, 0.09].forEach(function (d, i) { hiss(t + d, 0.045, 'bandpass', 1400 - i * 250, 900, 5, 1.1 * k); tone(t + d, 780 - i * 120, 520, 0.05, 'sine', 0.5 * k); }); },
      block: function (t) { tone(t, 300, 210, 0.12, 'triangle', 0.4); hiss(t, 0.05, 'bandpass', 700, 400, 3, 0.8); },
      win: function (t) { // trumpet fanfare
        [[392, 0, 0.13], [392, 0.15, 0.13], [392, 0.3, 0.13], [523.25, 0.46, 0.22], [659.25, 0.7, 0.22], [783.99, 0.94, 0.62]].forEach(function (n) { brass(t + n[1], n[0], n[2], 0.3, 2600); });
      }
    },
    harbor: {
      move: function (t, k) { hiss(t, 0.3, 'bandpass', 500, 1700, 0.9, 0.55 * k); tone(t + 0.03, 380, 250, 0.11, 'sine', 0.4 * k); },
      block: function (t) { tone(t, 280, 200, 0.16, 'sine', 0.5); hiss(t, 0.12, 'lowpass', 900, 400, 0.7, 0.35); },
      win: function (t) { // ship horn, then the harbour bell
        brass(t, 233.08, 0.75, 0.3, 1100); brass(t, 311.13, 0.75, 0.26, 1100);
        [0.9, 1.22].forEach(function (d) { tone(t + d, 1568, 1568, 0.9, 'sine', 0.3, 0.004); tone(t + d, 2349, 2349, 0.5, 'sine', 0.12, 0.004); });
      }
    },
    pixel: { // square-wave chip sounds; the jingle is an original IV-V-I run
      move: function (t, k) { tone(t, 660, 660, 0.045, 'square', 0.15 * k, 0.003); tone(t + 0.05, 990, 990, 0.065, 'square', 0.15 * k, 0.003); },
      block: function (t) { tone(t, 196, 147, 0.15, 'square', 0.2, 0.003); },
      win: function (t) {
        [698.46, 880, 1046.5, 783.99, 987.77, 1174.66].forEach(function (f, i) { tone(t + 0.1 + i * 0.085, f, f, 0.09, 'square', 0.15, 0.003); });
        tone(t + 0.64, 1046.5, 1046.5, 0.45, 'square', 0.15, 0.003); tone(t + 0.64, 1318.5, 1318.5, 0.45, 'square', 0.1, 0.003); tone(t + 0.64, 523.25, 523.25, 0.45, 'triangle', 0.25, 0.003);
      }
    },
    pastel: { // soft toy sounds: a pop, a bonk, a little horn and a glockenspiel run
      move: function (t, k) { tone(t, 500, 820, 0.09, 'sine', 0.5 * k, 0.01); hiss(t, 0.03, 'highpass', 3000, 2000, 0.7, 0.12 * k); },
      block: function (t) { tone(t, 330, 210, 0.15, 'sine', 0.5, 0.008); },
      win: function (t) {
        [0, 0.15].forEach(function (d) { tone(t + d, 622, 622, 0.11, 'triangle', 0.32, 0.01); tone(t + d, 466, 466, 0.11, 'triangle', 0.22, 0.01); });
        [1046.5, 1174.66, 1318.5, 1568, 2093].forEach(function (f, i) { var tt = t + 0.42 + i * 0.12; tone(tt, f, f, i === 4 ? 0.9 : 0.5, 'sine', 0.3, 0.004); tone(tt, f * 2, f * 2, 0.25, 'sine', 0.07, 0.004); });
      }
    }
  };
  function sfx(kind, k) {
    var a = ensureAudio(); if (!a) return;
    function fire() { try { SFX[S().skin][kind](a.currentTime + 0.015, k == null ? 1 : k); } catch (e) {} }
    if (a.state === 'running') { fire(); return; }
    if (!a.resume) return;
    var r = a.resume();                                                          // the first sound of the page must wait for the audio to be awake
    if (r && r.then) r.then(fire, function () {}); else fire();
  }
  function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

  /* =====================================================================
     Drawing: three looks for the same pieces. All art faces right in a
     (len*100) x 100 box; vehicleSVG turns it for the other directions.
     ===================================================================== */
  function rect(x, y, w, h, rx, attrs) { return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + rx + '" ' + (attrs || '') + '/>'; }
  var TYRE = 'fill="#0A0B0D"';
  function artCars(v, so) {
    var L = v.len * 100, s = rect(7 + so[0], 8 + so[1], L - 14, 84, v.len === 2 ? 27 : 23, 'fill="#000" fill-opacity=".38"');
    if (v.len === 2) {
      var st = v.hero ? rect(7, 39, 186, 7, 0, 'fill="#fff" fill-opacity=".9"') + rect(7, 54, 186, 7, 0, 'fill="#fff" fill-opacity=".9"') : '';
      return s + rect(30, 2, 34, 14, 5, TYRE) + rect(138, 2, 34, 14, 5, TYRE) + rect(30, 84, 34, 14, 5, TYRE) + rect(138, 84, 34, 14, 5, TYRE) +
        rect(7, 8, 186, 84, 27, 'fill="var(--c)"') + st +
        rect(10, 11, 180, 78, 24, 'fill="none" stroke="#000" stroke-opacity=".17" stroke-width="6"') +
        rect(50, 19, 100, 62, 19, 'fill="#000" fill-opacity=".3"') +
        rect(72, 24, 52, 52, 13, 'fill="var(--c)"') + rect(72, 24, 52, 52, 13, 'fill="#fff" fill-opacity=".17"') +
        (v.hero ? rect(72, 39, 52, 7, 0, 'fill="#fff" fill-opacity=".9"') + rect(72, 54, 52, 7, 0, 'fill="#fff" fill-opacity=".9"') : '') +
        '<path d="M163 31v38" stroke="#000" stroke-opacity=".15" stroke-width="3" stroke-linecap="round"/>' +
        rect(179, 21, 9, 15, 4.5, 'fill="#FFF4CC" fill-opacity=".95"') + rect(179, 64, 9, 15, 4.5, 'fill="#FFF4CC" fill-opacity=".95"') +
        rect(12, 23, 6, 13, 3, 'fill="#000" fill-opacity=".3"') + rect(12, 64, 6, 13, 3, 'fill="#000" fill-opacity=".3"');
    }
    var ribs = ''; for (var x = 52; x <= 172; x += 40) ribs += '<path d="M' + x + ' 23v54" stroke="#000" stroke-opacity=".13" stroke-width="3" stroke-linecap="round"/>';
    return s + [26, 72, 236].map(function (wx) { return rect(wx, 2, 34, 14, 5, TYRE) + rect(wx, 84, 34, 14, 5, TYRE); }).join('') +
      rect(7, 8, 286, 84, 23, 'fill="var(--c)"') + rect(10, 11, 280, 78, 20, 'fill="none" stroke="#000" stroke-opacity=".17" stroke-width="6"') +
      rect(18, 18, 188, 64, 10, 'fill="#fff" fill-opacity=".15"') + ribs + rect(211, 15, 5, 70, 2.5, 'fill="#000" fill-opacity=".26"') +
      rect(221, 21, 32, 58, 10, 'fill="#fff" fill-opacity=".17"') + rect(256, 20, 17, 60, 8, 'fill="#000" fill-opacity=".32"') +
      rect(280, 21, 9, 15, 4.5, 'fill="#FFF4CC" fill-opacity=".95"') + rect(280, 64, 9, 15, 4.5, 'fill="#FFF4CC" fill-opacity=".95"');
  }
  function floorCars() {
    var s = '', r, c, x, y;
    for (r = 0; r < 6; r++) for (c = 0; c < 6; c++) {
      x = c * 100 + 21; y = r * 100 + 21;
      s += '<rect class="stud" x="' + x + '" y="' + y + '" width="58" height="58" rx="9"/><path class="stud-hi" d="M' + (x + 2) + ' ' + (y + 50) + 'V' + (y + 9) + 'a7 7 0 0 1 7-7H' + (x + 50) + '"/>';
      if (c < 5) s += '<rect class="dash" x="' + (c * 100 + 91) + '" y="' + (r * 100 + 47.5) + '" width="18" height="5" rx="2.5"/>';
      if (r < 5) s += '<rect class="dash" x="' + (c * 100 + 47.5) + '" y="' + (r * 100 + 91) + '" width="5" height="18" rx="2.5"/>';
    }
    return s;
  }

  var COATS = [['#7A4A28', '#2A190D'], ['#33271F', '#0F0B08'], ['#D8B475', '#F3E6C6'], ['#A06D3C', '#3E2613']]; // bay, black, palomino, chestnut
  function horse(x, coat, mane) { // seen from above, nose to the right, 98 units long
    var edge = ' stroke="#000" stroke-opacity=".3" stroke-width="1.6"';
    return '<g transform="translate(' + x + ',0)">' +
      '<path d="M-9 27.5H46M-9 72.5H46" stroke="#3A2815" stroke-width="4.5" stroke-linecap="round"/>' +
      '<ellipse cx="8" cy="50" rx="10" ry="5.5" fill="' + mane + '"' + edge + '/>' +
      '<ellipse cx="40" cy="50" rx="31" ry="21" fill="' + coat + '"' + edge + '/>' +
      rect(24, 30.5, 32, 39, 9, 'fill="var(--c)" stroke="#000" stroke-opacity=".3" stroke-width="2.5"') +
      '<path d="M61 35L85 42V58L61 65Z" fill="' + coat + '"/>' +
      '<path d="M79 42l-8.5-6.5 2.5 10zM79 58l-8.5 6.5 2.5-10z" fill="' + coat + '"' + edge + '/>' +
      '<ellipse cx="86" cy="50" rx="12" ry="10" fill="' + coat + '"' + edge + '/><ellipse cx="95" cy="50" rx="4.5" ry="6.5" fill="#000" fill-opacity=".26"/>' +
      rect(57, 46, 26, 8, 4, 'fill="' + mane + '"') + '</g>';
  }
  function artMedieval(v, so) {
    var L = v.len * 100, cw = L - 106, coat = v.hero ? ['#F4F0E8', '#CFC8BA'] : COATS[(v.line * 3 + v.len + (v.horiz ? 1 : 0)) % 4];
    var wheelsAt = v.len === 2 ? [36] : [24, 142], WH = 'fill="#2B1D11"', s;
    s = '<g transform="translate(' + so[0] + ',' + so[1] + ')" fill="#000" fill-opacity=".34">' + rect(6, 14, cw, 72, 10) + '<ellipse cx="' + (L - 60) + '" cy="50" rx="33" ry="22"/><ellipse cx="' + (L - 14) + '" cy="50" rx="13" ry="10.5"/></g>';
    s += wheelsAt.map(function (wx) { return rect(wx, 3, 30, 13, 5, WH) + rect(wx, 84, 30, 13, 5, WH); }).join('');
    if (v.hero) { // the royal coach: crimson, gold trim, a crown on the roof
      s += rect(6, 14, cw, 72, 17, 'fill="var(--c)" stroke="#F2C24B" stroke-width="4.5"') + rect(17, 25, cw - 22, 50, 10, 'fill="#fff" fill-opacity=".1"') +
        '<path d="M35 62V43l9 8 9-13 9 13 9-8v19z" fill="#F2C24B" stroke="#7A5C0E" stroke-width="1.6" stroke-linejoin="round"/>' +
        '<circle cx="' + (cw - 3) + '" cy="24" r="4.5" fill="#FFE9A6"/><circle cx="' + (cw - 3) + '" cy="76" r="4.5" fill="#FFE9A6"/>';
    } else {
      s += rect(6, 14, cw, 72, 9, 'fill="#A8733A" stroke="#55361A" stroke-width="3"') + rect(cw - 8, 27, 10, 46, 3, 'fill="#55361A" fill-opacity=".75"') +
        rect(13, 20, cw - 24, 60, 13, 'fill="var(--c)"') + rect(13, 20, cw - 24, 60, 13, 'fill="none" stroke="#000" stroke-opacity=".22" stroke-width="3"');
      for (var i = 1, n = v.len === 2 ? 2 : 4; i <= n; i++) s += '<path d="M' + Math.round(13 + (cw - 24) * i / (n + 1)) + ' 22v56" stroke="#000" stroke-opacity=".16" stroke-width="3"/>';
      s += '<path d="M24 26H' + (cw - 22) + '" stroke="#fff" stroke-opacity=".4" stroke-width="3.5" stroke-linecap="round"/>';
    }
    return s + horse(L - 100, coat[0], coat[1]);
  }
  function floorMedieval() {
    var s = '', r, c, x, y, tones = ['--slab-a', '--slab-b', '--slab-c'];
    for (r = 0; r < 6; r++) for (c = 0; c < 6; c++) {
      x = c * 100; y = r * 100;
      s += rect(x + 4, y + 4, 92, 92, 11, 'fill="var(' + tones[(r * 5 + c * 3 + ((r * c) % 2)) % 3] + ')"') +
        '<path d="M' + (x + 8) + ' ' + (y + 84) + 'V' + (y + 15) + 'a7 7 0 0 1 7-7H' + (x + 84) + '" fill="none" stroke="var(--slab-hi)" stroke-opacity=".6" stroke-width="3" stroke-linecap="round"/>';
      if ((r * 7 + c * 11) % 5 === 0) s += '<path d="M' + (x + 58) + ' ' + (y + 30) + 'l8 14-5 10 9 16" fill="none" stroke="#000" stroke-opacity=".17" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>';
    }
    return s;
  }

  var GLASS = 'fill="#15303F" fill-opacity=".88"';
  function artHarbor(v, so) {
    var two = v.len === 2, hull, deck, s;
    if (two) { hull = 'M10 26Q10 12 24 12H118Q168 16 193 50Q168 84 118 88H24Q10 88 10 74Z'; deck = 'M25 33Q25 25 33 25H114Q152 29 171 50Q152 71 114 75H33Q25 75 25 67Z'; }
    else { hull = 'M10 24Q10 10 24 10H212Q266 14 293 50Q266 86 212 90H24Q10 90 10 76Z'; deck = 'M25 31Q25 23 33 23H208Q250 27 271 50Q250 73 208 77H33Q25 77 25 69Z'; }
    s = '<path d="' + hull + '" transform="translate(' + so[0] + ',' + so[1] + ')" fill="#00121A" fill-opacity=".45"/>' + rect(1, 40, 13, 20, 4, 'fill="#1B1F24"') +
      '<path d="' + hull + '" fill="var(--c)"/><path d="' + hull + '" fill="none" stroke="#000" stroke-opacity=".2" stroke-width="4"/>' +
      '<path d="' + deck + '" fill="#fff" fill-opacity="' + (v.hero ? '.1' : '.32') + '"/>';
    if (v.hero) return s + rect(16, 39, 160, 7, 0, 'fill="#fff" fill-opacity=".92"') + rect(16, 54, 160, 7, 0, 'fill="#fff" fill-opacity=".92"') +
      rect(50, 31, 46, 38, 10, 'fill="#000" fill-opacity=".3"') + rect(57, 37, 13, 26, 5, 'fill="#F5F2EA"') + rect(76, 37, 13, 26, 5, 'fill="#F5F2EA"') +
      '<path d="M104 29Q124 50 104 71L113 74Q136 50 113 26Z" ' + GLASS + '/>';
    if (two) return s + rect(46, 29, 62, 42, 11, 'fill="#F5F2EA"') + rect(46, 29, 62, 42, 11, 'fill="none" stroke="#000" stroke-opacity=".18" stroke-width="2.5"') +
      rect(93, 35, 10, 30, 4, GLASS) + rect(51, 39, 6, 22, 3, GLASS) + rect(64, 41, 20, 18, 6, 'fill="#000" fill-opacity=".1"') +
      '<circle cx="148" cy="50" r="5" fill="#000" fill-opacity=".22"/>';
    s += rect(24, 26, 42, 48, 9, 'fill="#F5F2EA"') + rect(24, 26, 42, 48, 9, 'fill="none" stroke="#000" stroke-opacity=".18" stroke-width="2.5"') + rect(55, 32, 7, 36, 3, GLASS) +
      '<circle cx="39" cy="50" r="10.5" fill="#22272E"/><circle cx="39" cy="50" r="5" fill="var(--c)"/>';
    [80, 130, 180].forEach(function (x) { s += rect(x, 30, 40, 40, 6, 'fill="#000" fill-opacity=".2" stroke="#fff" stroke-opacity=".3" stroke-width="2.5"'); });
    return s + '<circle cx="246" cy="50" r="6" fill="#000" fill-opacity=".24"/>';
  }
  function floorHarbor() {
    var s = '', r, c, x, y, k;
    for (r = 0; r < 6; r++) for (c = 0; c < 6; c++) {
      x = c * 100; y = r * 100; k = (r * 3 + c * 5) % 4;
      s += rect(x + 4, y + 4, 92, 92, 15, 'fill="var(--cellmark)" fill-opacity=".6"') +
        '<path d="M' + (x + 16 + k * 6) + ' ' + (y + 36 + k * 3) + 'q7-7 14 0t14 0M' + (x + 44 - k * 5) + ' ' + (y + 68 - k * 2) + 'q7-7 14 0t14 0" fill="none" stroke="var(--wave)" stroke-opacity=".6" stroke-width="3" stroke-linecap="round"/>';
    }
    return s;
  }

  /* Pixel: every shape sits on a 10-unit grid (10 x 10 "pixels" per square). */
  function px(x, y, w, h, attrs) { return '<rect x="' + x * 10 + '" y="' + y * 10 + '" width="' + w * 10 + '" height="' + h * 10 + '" ' + attrs + '/>'; }
  function artPixel(v, so) {
    var K = 'fill="#1B1230"', C = 'fill="var(--c)"', LT = 'fill="#fff" fill-opacity=".38"', DK = 'fill="#000" fill-opacity=".26"', G = 'fill="#273A78"', Y = 'fill="#FFE58A"', W = 'fill="#fff"';
    var n = v.len * 10, s = '<g transform="translate(' + so[0] * 2 + ',' + so[1] * 2 + ')" fill="#000" fill-opacity=".3">' + px(1, 1, n - 2, 8, '') + '</g>';
    (v.len === 2 ? [3, 13] : [3, 9, 23]).forEach(function (x) { s += px(x, 0, 4, 1, K) + px(x, 9, 4, 1, K); });
    s += px(2, 1, n - 4, 1, K) + px(2, 8, n - 4, 1, K) + px(1, 2, 1, 6, K) + px(n - 2, 2, 1, 6, K) + px(2, 2, n - 4, 6, C) + px(2, 2, n - 4, 1, LT) + px(2, 7, n - 4, 1, DK);
    if (v.len === 2) {
      if (v.hero) s += px(2, 4, 16, 2, W);
      s += px(4, 3, 2, 4, G) + px(6, 3, 6, 4, C) + px(6, 3, 6, 4, 'fill="#fff" fill-opacity=".24"') + (v.hero ? px(6, 4, 6, 2, W) : '') + px(12, 3, 2, 4, G) + px(12, 3, 1, 1, 'fill="#fff" fill-opacity=".75"') +
        px(15, 3, 1, 4, 'fill="#000" fill-opacity=".14"') + px(17, 2, 1, 2, Y) + px(17, 6, 1, 2, Y) + px(2, 3, 1, 1, DK) + px(2, 6, 1, 1, DK);
    } else {
      s += px(3, 3, 17, 4, 'fill="#fff" fill-opacity=".22"') + px(7, 3, 1, 4, DK) + px(11, 3, 1, 4, DK) + px(15, 3, 1, 4, DK) + px(21, 2, 1, 6, 'fill="#000" fill-opacity=".34"') +
        px(22, 3, 2, 4, 'fill="#fff" fill-opacity=".24"') + px(24, 3, 2, 4, G) + px(24, 3, 1, 1, 'fill="#fff" fill-opacity=".75"') + px(27, 2, 1, 2, Y) + px(27, 6, 1, 2, Y);
    }
    return s;
  }
  function floorPixel() {
    var s = '', r, c, x, y, k;
    for (r = 0; r < 6; r++) for (c = 0; c < 6; c++) {
      x = c * 10; y = r * 10; k = (r * 7 + c * 3) % 5;
      s += px(x, y, 10, 10, 'fill="var(--grass-' + ((r + c) % 2 ? 'a' : 'b') + ')"') +
        px(x + 2 + k, y + 2, 1, 1, 'fill="var(--grass-d)"') + px(x + 3 + k, y + 3, 1, 1, 'fill="var(--grass-d)"') + px(x + 7 - k, y + 7, 1, 1, 'fill="var(--grass-d)"') + px(x + 6 - k, y + 6, 1, 1, 'fill="var(--grass-d)"');
      if (k === 0) s += px(x + 7, y + 2, 1, 1, 'fill="#fff"') + px(x + 6, y + 3, 1, 1, 'fill="#fff"') + px(x + 8, y + 3, 1, 1, 'fill="#fff"') + px(x + 7, y + 4, 1, 1, 'fill="#fff"') + px(x + 7, y + 3, 1, 1, 'fill="#FFC21A"');
    }
    return s;
  }

  /* Pastello: flat colours, wobbly plum outlines, as if drawn with a felt-tip pen. */
  function artPastel(v, so) {
    var INK = '#4A3B52', ST = ' stroke="' + INK + '" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"', L = v.len * 100, two = v.len === 2, s, body;
    body = two ? 'M24 11C70 8 130 9 174 12C188 13 192 26 191 50C192 75 187 88 173 89C125 92 70 91 25 88C11 87 8 74 9 50C8 25 11 12 24 11Z'
      : 'M24 11C100 8 220 9 276 12C289 13 292 26 291 50C292 75 288 88 275 89C220 92 100 91 25 88C11 87 8 74 9 50C8 25 11 12 24 11Z';
    s = '<path d="' + body + '" transform="translate(' + so[0] * 1.4 + ',' + so[1] * 1.4 + ')" fill="#2F5E2A" fill-opacity=".3"/>';
    (two ? [36, 134] : [30, 96, 232]).forEach(function (x) { s += rect(x, 1, 32, 16, 8, 'fill="' + INK + '"') + rect(x, 83, 32, 16, 8, 'fill="' + INK + '"'); });
    s += '<path d="' + body + '" fill="var(--c)"' + ST + '/>' +                                          // a little volume: light along one side, shade along the other
      '<path d="' + (two ? 'M28 19C70 16 130 17 170 20' : 'M28 19C100 16 220 17 272 20') + '" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="6" stroke-linecap="round"/>' +
      '<path d="' + (two ? 'M28 81C70 84 130 83 170 80' : 'M28 81C100 84 220 83 272 80') + '" fill="none" stroke="#000" stroke-opacity=".13" stroke-width="7" stroke-linecap="round"/>';
    if (v.hero) s += '<path d="M13 39.5C70 38 130 40 188 39.5V46.5C130 47 70 45.5 12 46.5ZM12 54C70 53 130 55 188 54V61C130 61.5 70 60 13 61Z" fill="#fff"/>';
    if (two) {
      s += '<path d="M52 27C57 25 64 25 68 27C66 42 66 58 68 73C64 75 57 75 52 73C49 58 49 42 52 27Z" fill="#DFF3FC"' + ST + '/>' +
        '<path d="M74 25C90 23 104 24 116 25C117 42 117 58 116 75C104 77 90 76 74 75C73 58 73 42 74 25Z" fill="#fff" fill-opacity=".3"/>' + (v.hero ? '<path d="M74 40H116V46.5H74ZM74 54H116V60.5H74Z" fill="#fff"/>' : '') +
        '<path d="M122 24C131 23 140 26 143 31C146 43 146 57 143 69C140 74 131 77 122 76C119 60 119 40 122 24Z" fill="#DFF3FC"' + ST + '/>' +
        '<path d="M128 33C131 33 134 35 135 38" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/>';
    } else {
      s += '<path d="M26 22C80 19 150 20 204 22C207 40 207 60 204 78C150 81 80 80 26 78C23 60 23 40 26 22Z" fill="#fff" fill-opacity=".34" stroke="' + INK + '" stroke-opacity=".55" stroke-width="4" stroke-dasharray="9 8" stroke-linecap="round"/>' +
        '<path d="M216 14C218 38 218 62 216 87" fill="none"' + ST + '/>' +
        '<path d="M244 24C253 23 262 26 265 31C268 43 268 57 265 69C262 74 253 77 244 76C241 60 241 40 244 24Z" fill="#DFF3FC"' + ST + '/>' +
        '<path d="M250 33C253 33 256 35 257 38" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/>';
    }
    return s + '<circle cx="' + (L - 21) + '" cy="28" r="6.5" fill="#FFF3A6" stroke="' + INK + '" stroke-width="3.5"/><circle cx="' + (L - 21) + '" cy="72" r="6.5" fill="#FFF3A6" stroke="' + INK + '" stroke-width="3.5"/>';
  }
  function floorPastel() {
    var s = '', r, c, x, y, k, a, INK = '#4A3B52';
    for (r = 0; r < 6; r++) for (c = 0; c < 6; c++) {
      x = c * 100; y = r * 100; k = (r * 5 + c * 7) % 6;
      s += rect(x + 7, y + 7, 86, 86, 30, 'fill="var(--meadow)"');
      if (k === 0 || k === 3) { // a daisy
        var cx = x + (k ? 68 : 30), cy = y + (k ? 30 : 66);
        for (a = 0; a < 5; a++) s += '<circle cx="' + (cx + 8 * Math.cos(a * 1.2566)).toFixed(1) + '" cy="' + (cy + 8 * Math.sin(a * 1.2566)).toFixed(1) + '" r="5.5" fill="#fff" stroke="' + INK + '" stroke-opacity=".35" stroke-width="1.5"/>';
        s += '<circle cx="' + cx + '" cy="' + cy + '" r="4.5" fill="#FFD95A"/>';
      } else if (k === 1) s += '<path d="M' + (x + 26) + ' ' + (y + 62) + 'c4-16 22-20 34-12c12-4 22 6 16 16c2 10-16 14-26 10c-12 4-28-2-24-14z" fill="#B98C62" stroke="' + INK + '" stroke-opacity=".45" stroke-width="3"/><path d="M' + (x + 40) + ' ' + (y + 58) + 'q8-5 16-1" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="3.5" stroke-linecap="round"/>';
      else s += '<path d="M' + (x + 30 + k * 6) + ' ' + (y + 40 + k * 4) + 'l4-11l4 11l5-9l2 9" fill="none" stroke="#6DB24A" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>';
    }
    return s;
  }

  var COLOR = { r: ['rosso', 'rossa'], y: ['giallo', 'gialla'], b: ['blu', 'blu'], g: ['verde', 'verde'] };
  var SKINS = {
    cars: { label: 'Traffico', art: artCars, floor: floorCars, shine: true, hero: "l'auto a strisce", two: ["l'auto", 1], three: ['il camion', 0],
      intro: "Trascina i veicoli per liberare la strada: l'auto a strisce deve raggiungere l'uscita a destra.", out: "Porta l'auto a strisce fuori dall'uscita." },
    medieval: { label: 'Medioevo', art: artMedieval, floor: floorMedieval, shine: false, hero: 'la carrozza reale', two: ['il carretto', 0], three: ['il carro', 0],
      intro: 'Trascina carri e carretti per liberare il cortile: la carrozza reale deve raggiungere il portone a destra.', out: 'Porta la carrozza reale fuori dal portone.' },
    harbor: { label: 'Porto', art: artHarbor, floor: floorHarbor, shine: false, hero: 'il motoscafo a strisce', two: ['la barca', 1], three: ['la nave', 1],
      intro: "Trascina barche e navi per liberare il canale: il motoscafo a strisce deve raggiungere l'uscita del porto a destra.", out: 'Porta il motoscafo a strisce fuori dal porto.' }
  };
  ['pixel', 'pastel'].forEach(function (k) { var o = {}; Object.keys(SKINS.cars).forEach(function (f) { o[f] = SKINS.cars[f]; }); o.shine = false; SKINS[k] = o; }); // same vocabulary as the cars
  SKINS.pixel.label = 'Pixel'; SKINS.pixel.art = artPixel; SKINS.pixel.floor = floorPixel;
  SKINS.pastel.label = 'Pastello'; SKINS.pastel.art = artPastel; SKINS.pastel.floor = floorPastel;
  function vehicleSVG(v, skin) {
    var sk = SKINS[skin], L = v.len * 100, vb, tf, so, shine = '';
    if (v.horiz) {
      vb = '0 0 ' + L + ' 100'; tf = v.face > 0 ? '' : 'translate(' + L + ',0) scale(-1,1)'; so = [0, 5];
      if (sk.shine) shine = '<path d="M34 15.5H' + Math.round(L * 0.46) + '" stroke="#fff" stroke-opacity=".5" stroke-width="4" stroke-linecap="round"/>';
    } else {
      vb = '0 0 100 ' + L;
      if (v.face > 0) { tf = 'rotate(-90) translate(' + (-L) + ',0)'; so = [-5, 0]; } else { tf = 'rotate(90) translate(0,-100)'; so = [5, 0]; }
      if (sk.shine) shine = '<path d="M15.5 34V' + Math.round(L * 0.46) + '" stroke="#fff" stroke-opacity=".5" stroke-width="4" stroke-linecap="round"/>';
    }
    return '<svg viewBox="' + vb + '" aria-hidden="true"><g transform="' + tf + '">' + sk.art(v, so) + '</g>' + shine + '</svg>';
  }
  function nameOf(v) { var sk = SKINS[S().skin]; if (v.hero) return sk.hero; var n = v.len === 2 ? sk.two : sk.three; return n[0] + ' ' + COLOR[v.color][n[1]]; }
  function labelOf(v) { var n = nameOf(v).replace(/^(l'|il |la |lo )/, ''); return n.charAt(0).toUpperCase() + n.slice(1) + (v.horiz ? ', si muove in orizzontale' : ', si muove in verticale'); }
  function paintBoard() {
    var skin = S().skin, old = grid.querySelector('.floor');
    document.body.setAttribute('data-skin', skin);
    if (old) old.remove();
    grid.insertAdjacentHTML('afterbegin', '<svg class="floor" viewBox="0 0 600 600" aria-hidden="true">' + SKINS[skin].floor() + '</svg>');
    vehicles.forEach(function (v) { v.el.innerHTML = vehicleSVG(v, skin); v.el.setAttribute('aria-label', labelOf(v)); });
  }

  /* =====================================================================
     The game
     ===================================================================== */
  var level = 0, vehicles = [], history = [], histBase = 0, minMoves = 0, won = false, drag = null, winTimer = 0, byKeyboard = false, notice = '';
  function place(v, p) { v.el.style.setProperty('--x', v.horiz ? p : v.line); v.el.style.setProperty('--y', v.horiz ? v.line : p); }
  function positions() { return vehicles.map(function (v) { return v.pos; }); }
  function moveCount() { return histBase + history.length; }
  function tierOf(i) { return TIERS[Math.min(TIERS.length - 1, Math.floor(i / PER_TIER))]; }
  function solvedCount(s) { return Object.keys((s || S()).best).length; }
  var statusDefault = true;
  function setStatus(t) { statusDefault = !t; statusEl.textContent = t || (solvedCount() === 0 && moveCount() === 0 ? SKINS[S().skin].intro : 'Partita «' + S().name + '»'); }
  function validBoard(b, vs) {
    if (!b || b.level !== level || b.pos.length !== vs.length) return false;
    var occ = {}, ok = true;
    vs.forEach(function (v, i) { var p = b.pos[i]; if (p < 0 || p + v.len > 6) ok = false; for (var t = 0; t < v.len; t++) { var c = VL.cellOf(v, p + t); if (occ[c]) ok = false; occ[c] = 1; } });
    return ok && b.pos[0] < 4;
  }
  function snapshot() { // remember the board exactly as it is, so the game can be resumed mid-level
    var s = S();
    s.level = level;
    s.board = moveCount() === 0 ? null : { level: level, pos: positions(), base: histBase + Math.max(0, history.length - 400), hist: history.slice(-400).map(function (m) { return [vehicles.indexOf(m.v), m.from, m.to]; }) };
  }

  function loadLevel(i, resume) {
    clearTimeout(winTimer);
    level = clampInt(i, 0, RAW.length - 1);
    won = false; drag = null; history = []; histBase = 0; clearHint();
    Array.prototype.slice.call(grid.querySelectorAll('.veh')).forEach(function (el) { el.remove(); });
    var def = VL.parseLevel(RAW[level]), s = S(), saved = resume && validBoard(s.board, def.vehicles) ? s.board : null; minMoves = def.min;
    if (saved) def.vehicles.forEach(function (v, k) { v.home = v.pos; v.pos = saved.pos[k]; });
    vehicles = def.vehicles.map(makeVehicle);
    if (saved) { histBase = saved.base; history = saved.hist.filter(function (h) { return vehicles[h[0]]; }).map(function (h) { return { v: vehicles[h[0]], from: h[1], to: h[2] }; }); }
    else if (s.level !== level || s.board) { s.level = level; s.board = null; commitSave(false); }
    hideResult(); exitEl.classList.remove('flash');
    var t = tierOf(level), app = $('app');
    app.style.setProperty('--tier', t.color); app.style.setProperty('--tier-ink', t.ink);
    $('badge').textContent = level + 1; $('tierName').textContent = t.name; $('lvOf').textContent = 'livello ' + (level + 1) + ' di ' + RAW.length;
    setStatus(notice); notice = '';
    gateReset(HINT_FIRST); updateStats();
  }
  function makeVehicle(v, idx) {
    var el = document.createElement('div');
    el.className = 'veh enter ' + (v.horiz ? 'h' : 'v') + (v.hero ? ' hero' : '');
    el.tabIndex = 0; el.setAttribute('role', 'button');
    el.style.setProperty('--w', v.horiz ? v.len : 1); el.style.setProperty('--h', v.horiz ? 1 : v.len);
    el.style.setProperty('--c', 'var(--c-' + v.color + ')'); el.style.setProperty('--i', idx);
    v.el = el; v.start = v.home == null ? v.pos : v.home;
    el.innerHTML = vehicleSVG(v, S().skin); el.setAttribute('aria-label', labelOf(v)); place(v, v.pos);
    el.addEventListener('pointerdown', function (e) { onDown(e, v); });
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);
    el.addEventListener('lostpointercapture', onUp);
    el.addEventListener('keydown', function (e) { onKey(e, v); });
    el.addEventListener('animationend', function (e) { if (e.animationName === 'drop') el.classList.remove('enter'); if (e.animationName === 'nopeX' || e.animationName === 'nopeY') el.classList.remove('nope'); });
    grid.appendChild(el);
    return v;
  }
  function updateStats() {
    $('statMoves').textContent = moveCount(); $('statMin').textContent = minMoves;
    var b = S().best[level + 1]; $('statBest').textContent = b ? b : '–';
    $('btnUndo').disabled = won || history.length === 0; $('btnReset').disabled = !won && moveCount() === 0; gateTick();
  }

  function rubber(d) { return 0.13 * (1 - 1 / (d * 3 + 1)); }
  function onDown(e, v) {
    if (won || drag || (e.pointerType === 'mouse' && e.button !== 0)) return;
    e.preventDefault(); byKeyboard = false;
    var r = VL.range(vehicles, positions(), vehicles.indexOf(v));
    drag = { v: v, id: e.pointerId, cell: grid.getBoundingClientRect().width / 6, origin: v.horiz ? e.clientX : e.clientY, from: v.pos, min: r[0], max: r[1], p: v.pos, raw: v.pos, open: v.hero && r[1] === 4 };
    try { v.el.setPointerCapture(e.pointerId); } catch (err) {}
    v.el.classList.add('dragging'); v.el.classList.remove('enter'); clearHint();
  }
  function onMove(e) {
    var d = drag; if (!d || e.pointerId !== d.id) return;
    var p = d.from + ((d.v.horiz ? e.clientX : e.clientY) - d.origin) / d.cell, hi = d.open ? 6.3 : d.max;
    d.raw = p;
    if (p < d.min) p = d.min - rubber(d.min - p); else if (p > hi) p = d.open ? hi : hi + rubber(p - hi);
    d.p = p; place(d.v, p);
  }
  function onUp(e) {
    var d = drag; if (!d || e.pointerId !== d.id) return;
    drag = null; var v = d.v; v.el.classList.remove('dragging');
    try { v.el.releasePointerCapture(e.pointerId); } catch (err) {}
    var to = Math.max(d.min, Math.min(d.max, Math.round(d.p)));
    if (d.open && d.p >= 3.5) to = 4;
    if (to === d.from && (d.raw > d.max + 0.3 || d.raw < d.min - 0.3)) blocked(v); // pushed against another piece or the wall
    if (!(v.hero && to === 4)) place(v, to);
    commit(v, d.from, to);
  }
  function blocked(v) { v.el.classList.remove('nope'); void v.el.offsetWidth; v.el.classList.add('nope'); sfx('block'); }
  function onKey(e, v) {
    if (won || drag) return;
    var step = 0;
    if (v.horiz) { if (e.key === 'ArrowLeft') step = -1; else if (e.key === 'ArrowRight') step = 1; }
    else { if (e.key === 'ArrowUp') step = -1; else if (e.key === 'ArrowDown') step = 1; }
    if (!step) return;
    e.preventDefault(); clearHint(); byKeyboard = true;
    var r = VL.range(vehicles, positions(), vehicles.indexOf(v)), to = v.pos + step;
    if (to < r[0] || to > r[1]) { blocked(v); return; }
    if (!(v.hero && to === 4)) place(v, to);
    commit(v, v.pos, to);
  }
  // Consecutive slides of the same piece count as one move, like lifting a finger mid-way.
  function commit(v, from, to) {
    if (to !== from) {
      var last = history[history.length - 1];
      if (last && last.v === v) { last.to = to; if (last.to === last.from) history.pop(); } else history.push({ v: v, from: from, to: to });
      v.pos = to; touched = true; buzz(8);
      if (v.hero && to === 4) { win(); return; }
      sfx('move'); snapshot(); commitSave(false); setStatus('');
    }
    updateStats();
  }
  function undo() {
    if (won || !history.length) return;
    var m = history.pop(); m.v.pos = m.from; place(m.v, m.from); clearHint(); sfx('move', 0.7); touched = true; snapshot(); commitSave(false); setStatus(''); updateStats();
  }
  function restart() {
    touched = true;
    if (won) { loadLevel(level, false); return; }
    if (!moveCount()) return;
    history = []; histBase = 0; clearHint(); vehicles.forEach(function (v) { v.pos = v.start; place(v, v.start); }); sfx('move', 0.7); snapshot(); commitSave(false); setStatus(''); updateStats();
  }

  /* The hint has to be earned: it unlocks after some time on the level or some
     moves, and each hint used starts the wait again. The ring around the sign
     shows how much is left, so a child who cannot read still sees it coming. */
  var HINT_FIRST = { s: 40, moves: 8 }, HINT_AGAIN = { s: 30, moves: 6 };
  var gate = { acc: 0, t0: 0, base: 0, need: HINT_FIRST, timer: 0 };
  function gateSeconds() { return gate.acc + (gate.t0 ? (now() - gate.t0) / 1000 : 0); }
  function gateReset(need) {
    gate.acc = 0; gate.t0 = document.hidden ? 0 : now(); gate.base = moveCount(); gate.need = need;
    clearInterval(gate.timer); gate.timer = setInterval(gateTick, 250); gateTick();
  }
  function gateProgress() {
    if (hintMode() === 'subito') return 1;
    if (hintMode() === 'mai') return 0;
    return Math.max(Math.min(1, gateSeconds() / gate.need.s), Math.min(1, (moveCount() - gate.base) / gate.need.moves));
  }
  function soundOn() { return !window.OPZ || OPZ.get('suoni'); }
  function hintMode() { return window.OPZ ? OPZ.get('aiuto') : store.hintMode; }
  function hintReady() { return hintMode() !== 'mai' && gateProgress() >= 1; }
  function gateTick() {
    var p = gateProgress(), btn = $('btnHint'), ring = $('hintRing'), show = !won && hintMode() === 'attesa' && p < 1;
    btn.hidden = hintMode() === 'mai'; btn.disabled = won || !hintReady();
    btn.classList.toggle('waiting', show);
    if (show) ring.querySelector('.fill').setAttribute('stroke-dashoffset', (188.5 * (1 - p)).toFixed(1));
    else { clearInterval(gate.timer); gate.timer = 0; }
  }
  document.addEventListener('visibilitychange', function () { // time only runs while the game is on screen
    if (document.hidden) { gate.acc = gateSeconds(); gate.t0 = 0; } else if (!gate.t0) gate.t0 = now();
  });

  function clearHint() { ghost.hidden = true; vehicles.forEach(function (v) { if (v.el) v.el.classList.remove('hint'); }); }
  function hint() {
    if (won || !hintReady()) return;
    gateReset(HINT_AGAIN);
    clearHint();
    var sol = VL.solve(vehicles, positions());
    if (!sol || !sol.length) { setStatus('Nessuna mossa trovata: ricomincia il livello.'); return; }
    var v = vehicles[sol[0].i], to = sol[0].to, n = Math.abs(to - v.pos), dir = v.horiz ? (to > v.pos ? 'a destra' : 'a sinistra') : (to > v.pos ? 'in basso' : 'in alto');
    v.el.classList.add('hint');
    ghost.style.setProperty('--w', v.horiz ? v.len : 1); ghost.style.setProperty('--h', v.horiz ? 1 : v.len);
    ghost.style.setProperty('--x', v.horiz ? to : v.line); ghost.style.setProperty('--y', v.horiz ? v.line : to); ghost.hidden = false;
    setStatus((v.hero && to === 4 ? SKINS[S().skin].out : 'Sposta ' + nameOf(v) + ' di ' + n + (n === 1 ? ' casella ' : ' caselle ') + dir + '.') + (sol.length > 1 ? ' Da qui mancano ' + sol.length + ' mosse.' : ''));
  }

  function win() {
    won = true; clearInterval(gate.timer); gate.timer = 0; var hero = vehicles[0], moves = moveCount(), s = S(), prev = s.best[level + 1];
    hero.el.classList.add('leaving'); place(hero, 9.5); exitEl.classList.add('flash');
    if (!prev || moves < prev) s.best[level + 1] = moves;
    s.board = null; s.level = Math.min(RAW.length - 1, level + 1); commitSave(true);
    updateStats(); sfx('win'); buzz([12, 60, 18]); confetti();
    var perfect = moves <= minMoves, text;
    if (perfect) text = 'Risolto in ' + moves + (moves === 1 ? ' mossa' : ' mosse') + ': meno di così non si può.';
    else if (!prev || moves < prev) text = 'Risolto in ' + moves + ' mosse' + (prev ? ', nuovo record' : '') + '. Il minimo è ' + minMoves + '.';
    else text = 'Risolto in ' + moves + ' mosse. Il tuo record è ' + prev + ', il minimo è ' + minMoves + '.';
    var lastLevel = level >= RAW.length - 1;
    $('resTitle').textContent = lastLevel ? 'Via libera, fino in fondo!' : 'Via libera!';
    $('resPerfect').hidden = !perfect; $('resText').textContent = text + (lastLevel ? " Era l'ultimo livello." : '');
    $('btnNextLevel').textContent = lastLevel ? 'Scegli un livello' : 'Livello successivo';
    statusDefault = false; statusEl.textContent = '';
    winTimer = setTimeout(showResult, 560);
  }
  function confetti() {                                          // a shower of paper over the whole screen, behind the result panel
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var box = document.createElement('div'), h = '', cols = ['#EE5E4D', '#FFD95A', '#7DB7F7', '#8DD68A', '#4FC3C7', '#F59A3A'], i; box.className = 'confbox';
    for (i = 0; i < 60; i++) h += '<i style="left:' + (Math.random() * 100).toFixed(1) + '%;background:' + cols[i % 6] + ';--dx:' + ((Math.random() - 0.5) * 160).toFixed(0) + 'px;--r:' + ((Math.random() * 900 - 450) | 0) + 'deg;--t:' + (1.9 + Math.random() * 1.7).toFixed(2) + 's;--dl:' + (Math.random() * 0.8).toFixed(2) + 's"></i>';
    box.innerHTML = h; document.body.appendChild(box); setTimeout(function () { if (box.parentNode) box.parentNode.removeChild(box); }, 4600);
  }
  function showResult() { result.hidden = false; void result.offsetWidth; result.classList.add('show'); controls.style.visibility = 'hidden'; if (byKeyboard) { try { $('btnNextLevel').focus({ preventScroll: true }); } catch (e) {} } }
  function hideResult() { result.classList.remove('show'); result.hidden = true; controls.style.visibility = ''; }
  // Show the active saved game: its look, its level, the board as it was left.
  function applyActive(message) { notice = message; paintBoard(); loadLevel(S().level, true); }

  /* =====================================================================
     Level sheet
     ===================================================================== */
  function buildSheet() {
    var html = '';
    TIERS.forEach(function (t, ti) {
      var from = ti * PER_TIER, to = Math.min(RAW.length, from + PER_TIER); if (from >= RAW.length) return;
      html += '<section class="tier" style="--tier:' + t.color + ';--tier-ink:' + t.ink + '"><h3><i></i>' + t.name + '<small>' + (from + 1) + '–' + to + '</small><em data-count="' + ti + '"></em></h3><div class="cells">';
      for (var i = from; i < to; i++) html += '<button class="lv" type="button" data-level="' + i + '">' + (i + 1) + '</button>';
      html += '</div></section>';
    });
    $('sheetBody').innerHTML = html;
    $('sheetBody').addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.lv') : null; if (!b) return;
      touched = true; loadLevel(+b.getAttribute('data-level'), false); closeDlg(sheet);
    });
  }
  function refreshSheet() {
    var counts = TIERS.map(function () { return 0; }), perfect = 0, best = S().best;
    Array.prototype.forEach.call(sheet.querySelectorAll('.lv'), function (b) {
      var i = +b.getAttribute('data-level'), mine = best[i + 1], min = +RAW[i].split(':')[2], label = 'Livello ' + (i + 1);
      b.classList.toggle('done', !!mine); b.classList.toggle('perfect', !!mine && mine <= min); b.classList.toggle('current', i === level);
      if (mine) { counts[Math.floor(i / PER_TIER)]++; label += mine <= min ? ', risolto con il minimo di mosse' : ', risolto in ' + mine + ' mosse'; if (mine <= min) perfect++; }
      b.setAttribute('aria-label', label); if (i === level) b.setAttribute('aria-current', 'true'); else b.removeAttribute('aria-current');
    });
    Array.prototype.forEach.call(sheet.querySelectorAll('[data-count]'), function (el) { var ti = +el.getAttribute('data-count'); el.textContent = counts[ti] + ' su ' + Math.min(PER_TIER, RAW.length - ti * PER_TIER); });
    var n = solvedCount();
    $('sheetSummary').textContent = n === 0 ? 'Scegli da quale livello partire: sono tutti aperti.' : n + ' di ' + RAW.length + ' risolti, ' + perfect + ' con il minimo di mosse.';
  }
  function openSheet() {
    refreshSheet(); openDlg(sheet);
    var cur = sheet.querySelector('.lv.current'); if (cur) { try { cur.scrollIntoView({ block: 'center' }); cur.focus({ preventScroll: true }); } catch (e) {} }
  }

  /* =====================================================================
     Menu: saved games, look, sound
     ===================================================================== */
  function summary(s) { var n = solvedCount(s); return 'livello ' + (s.level + 1) + ', ' + (n === 1 ? '1 risolto' : n + ' risolti'); }
  function dateOf(s) { try { return new Date(s.updated).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' }); } catch (e) { return ''; } }
  function skinPreview(name) {
    var a = { hero: true, horiz: true, len: 2, line: 2, face: 1, color: 'h' }, b = { hero: false, horiz: true, len: 2, line: 3, face: -1, color: 'y' };
    return '<span class="pv" data-skin="' + name + '"' + (name === 'cars' ? ' style="background:#202328"' : '') + '><span style="display:block;--c:var(--c-h)">' + vehicleSVG(a, name) + '</span><span style="display:block;margin-top:4px;--c:var(--c-' + (name === 'harbor' ? 'y' : 'b') + ')">' + vehicleSVG(b, name) + '</span></span>';
  }
  var TRASH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 002 2h6a2 2 0 002-2l1-12M9 7V4h6v3"/></svg>';
  function renderMenu() {
    var s = S(), others = liveSaves().filter(function (x) { return x.id !== s.id; }), full = liveSaves().length >= MAX_SAVES, h = '';
    h += '<section class="blk"><h3>Partita</h3><div class="save current"><div class="who"><strong>' + esc(s.name) + '</strong><span>in corso, ' + summary(s) + '</span></div><button class="chip" type="button" data-act="rename">Rinomina</button></div>';
    h += '<div class="row2"><button class="btn" type="button" data-act="saveas"' + (full ? ' disabled' : '') + '>Salva con nome</button><button class="btn" type="button" data-act="new"' + (full ? ' disabled' : '') + '>Nuova partita</button></div>';
    if (others.length) {
      h += '<h4>Altre partite salvate</h4>';
      others.forEach(function (o) { h += '<div class="save"><div class="who"><strong>' + esc(o.name) + '</strong><span>' + summary(o) + (dateOf(o) ? ', ' + dateOf(o) : '') + '</span></div><button class="chip solid" type="button" data-act="load" data-id="' + o.id + '">Carica</button><button class="chip icon" type="button" data-act="delete" data-id="' + o.id + '" aria-label="Elimina la partita ' + esc(o.name) + '">' + TRASH + '</button></div>'; });
    }
    h += '<p>' + (full ? 'Hai raggiunto il massimo di ' + MAX_SAVES + ' partite: eliminane una per crearne altre. ' : '') + (cloud.state === 'on' ? 'Ogni mossa viene salvata da sola, su questo dispositivo e nel tuo account Claude.' : 'Ogni mossa viene salvata da sola su questo dispositivo.') + '</p></section>';
    h += '<section class="blk"><h3>Stile</h3><div class="skins">';
    SKIN_ORDER.forEach(function (k) { h += '<button class="skin" type="button" data-act="skin" data-skin-name="' + k + '" aria-pressed="' + (s.skin === k) + '">' + skinPreview(k) + SKINS[k].label + '</button>'; });
    h += '</div></section>';
    h += '<section class="blk"><h3>Aiuti</h3><div class="chips">';
    [['subito', 'Subito'], ['attesa', 'Dopo un po\''], ['mai', 'Mai']].forEach(function (m) { h += '<button class="chip" type="button" data-act="hintmode" data-mode="' + m[0] + '" aria-pressed="' + (hintMode() === m[0]) + '">' + m[1] + '</button>'; });
    h += '</div><p>Con «Dopo un po\'» il pulsante Aiuto si sblocca dopo ' + HINT_FIRST.s + ' secondi sul livello o dopo ' + HINT_FIRST.moves + ' mosse, e dopo ogni aiuto usato l\'attesa ricomincia. L\'anello attorno al pulsante mostra quanto manca, senza bisogno di saper leggere.</p></section>';
    h += '<section class="blk"><button class="switchrow" type="button" role="switch" data-act="sound" aria-checked="' + (store.sound && soundOn()) + '">Suoni<span class="switch"></span></button><p>Su iPhone i suoni seguono la modalità silenzioso: quando è attiva non si sentono.</p></section>';
    if (!(navigator.standalone || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches))) h += '<section class="blk"><h3>Sulla schermata Home</h3><p style="margin-top:0">Apri questa pagina in Safari, tocca Condividi e scegli «Aggiungi alla schermata Home»: da lì il gioco si apre con un tocco, come un\'app.</p></section>';
    h += '<section class="blk"><h3>Come si gioca</h3><ul><li>Il pezzo cremisi (l\'auto a strisce, la carrozza reale o il motoscafo, secondo lo stile) deve uscire dal varco a destra.</li><li>Ogni pezzo si muove solo avanti e indietro, lungo la propria corsia.</li><li>Ogni spostamento conta una mossa, di quante caselle vuoi.</li></ul></section>';
    $('menuBody').innerHTML = h;
    $('menuSummary').textContent = 'Partita «' + s.name + '», ' + summary(s) + '.';
  }
  function refreshOpenPanels() { if (menu.open) renderMenu(); if (sheet.open) refreshSheet(); if (statusDefault && !won) setStatus(''); updateStats(); }
  function openMenu() {
    renderMenu(); openDlg(menu);
    if (cloud.state === 'on' && !cloud.busy) cloud.col.get().then(mergeFromCloud, function () {});
  }
  function activate(id, message) { store.active = id; touched = true; saveLocal(); applyActive(message); }
  var pendingDelete = '';
  $('menuBody').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-act]') : null; if (!b || b.disabled) return;
    var act = b.getAttribute('data-act'), id = b.getAttribute('data-id');
    if (act === 'rename' || act === 'saveas' || act === 'new') openName(act);
    else if (act === 'load' && store.saves[id]) { snapshot(); activate(id, 'Partita «' + store.saves[id].name + '» caricata.'); closeDlg(menu); }
    else if (act === 'delete' && store.saves[id]) { pendingDelete = id; $('confirmTitle').textContent = 'Eliminare «' + store.saves[id].name + '»?'; $('confirmText').textContent = 'I livelli risolti e i record di questa partita vengono cancellati.'; openDlg(confirmDlg); }
    else if (act === 'skin') { var k = b.getAttribute('data-skin-name'); if (SKINS[k] && k !== S().skin) { S().skin = k; touched = true; commitSave(true); paintBoard(); setStatus(''); renderMenu(); sfx('move'); } }
    else if (act === 'sound') { var v = !(store.sound && soundOn()); store.sound = v; if (window.OPZ) OPZ.set('suoni', v); saveLocal(); renderMenu(); if (v) { wakeAudio(); sfx('move'); } }
    else if (act === 'hintmode') { var m = b.getAttribute('data-mode'); if (HINT_MODES.indexOf(m) >= 0 && m !== hintMode()) { store.hintMode = m; if (window.OPZ) OPZ.set('aiuto', m); saveLocal(); gateReset(gate.need); renderMenu(); } }
  });

  var nameMode = '';
  function nameTaken(n, exceptId) { n = n.toLowerCase(); return liveSaves().some(function (s) { return s.id !== exceptId && s.name.toLowerCase() === n; }); }
  function suggestName() { for (var i = 1; i < 99; i++) if (!nameTaken('Partita ' + i)) return 'Partita ' + i; return 'Partita'; }
  function syncStart() { var n = clampInt($('startInput').value, 1, RAW.length); $('startInput').value = n; return n; }
  function openName(mode) {
    nameMode = mode;
    $('nameTitle').textContent = mode === 'rename' ? 'Rinomina la partita' : mode === 'new' ? 'Nuova partita' : 'Salva con nome';
    $('nameIntro').textContent = mode === 'saveas' ? 'Crea una copia della partita in corso, con i livelli risolti e il tabellone com\'è adesso, e continua da lì.' : mode === 'new' ? 'Riparte da zero: la partita in corso resta salvata.' : '';
    $('nameIntro').hidden = mode === 'rename'; $('startField').hidden = mode !== 'new';
    $('nameInput').value = mode === 'rename' ? S().name : suggestName(); $('nameErr').textContent = ''; $('startInput').value = 1;
    $('btnNameYes').textContent = mode === 'new' ? 'Inizia' : 'Salva';
    openDlg(nameDlg);
    try { $('nameInput').focus(); $('nameInput').select(); } catch (e) {}
  }
  function confirmName() {
    var n = $('nameInput').value.replace(/\s+/g, ' ').trim().slice(0, 24), cur = S();
    if (!n) { $('nameErr').textContent = 'Scrivi un nome per la partita.'; return; }
    if (nameTaken(n, nameMode === 'rename' ? cur.id : '')) { $('nameErr').textContent = 'Esiste già una partita con questo nome.'; return; }
    touched = true;
    if (nameMode === 'rename') { cur.name = n; commitSave(true); setStatus(''); }
    else {
      snapshot(); cur.updated = now(); cloudNow(cur.id);
      var s = blankSave(n, 0, cur.skin);
      if (nameMode === 'saveas') { s.level = cur.level; s.best = JSON.parse(JSON.stringify(cur.best)); s.board = cur.board ? JSON.parse(JSON.stringify(cur.board)) : null; }
      else s.level = syncStart() - 1;
      s.updated = now() + 1; store.saves[s.id] = s; store.active = s.id; saveLocal(); cloudNow(s.id);
      if (nameMode === 'saveas') setStatus('Partita salvata come «' + n + '».'); else applyActive('Partita «' + n + '» creata.');
    }
    closeDlg(nameDlg);
    if (nameMode === 'new') closeDlg(menu); else renderMenu();
  }
  $('btnNameYes').addEventListener('click', confirmName);
  $('btnNameNo').addEventListener('click', function () { closeDlg(nameDlg); });
  $('nameInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); confirmName(); } });
  $('nameInput').addEventListener('input', function () { $('nameErr').textContent = ''; });
  $('startMinus').addEventListener('click', function () { $('startInput').value = syncStart() - 1; syncStart(); });
  $('startPlus').addEventListener('click', function () { $('startInput').value = syncStart() + 1; syncStart(); });
  $('startInput').addEventListener('change', syncStart);
  $('tierPick').innerHTML = TIERS.map(function (t, i) { return i * PER_TIER < RAW.length ? '<button type="button" data-start="' + (i * PER_TIER + 1) + '" style="--tier:' + t.color + ';--tier-ink:' + t.ink + '">' + t.name + '</button>' : ''; }).join('');
  $('tierPick').addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-start]') : null; if (b) $('startInput').value = b.getAttribute('data-start'); });
  $('btnConfirmNo').addEventListener('click', function () { closeDlg(confirmDlg); });
  $('btnConfirmYes').addEventListener('click', function () {
    var s = store.saves[pendingDelete];
    if (s && s.id !== store.active) { store.saves[s.id] = { id: s.id, name: s.name, created: s.created, updated: now(), level: 0, skin: 'cars', best: {}, board: null, deleted: true }; saveLocal(); cloudNow(s.id); }
    pendingDelete = ''; closeDlg(confirmDlg); renderMenu();
  });

  /* ---------- wiring ---------- */
  grid.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  $('btnUndo').addEventListener('click', undo);
  $('btnReset').addEventListener('click', restart);
  $('btnHint').addEventListener('click', hint);
  $('btnLevels').addEventListener('click', openSheet);
  $('btnMenu').addEventListener('click', openMenu);
  $('btnCloseSheet').addEventListener('click', function () { closeDlg(sheet); });
  $('btnCloseMenu').addEventListener('click', function () { closeDlg(menu); });
  $('btnAgain').addEventListener('click', function () { touched = true; loadLevel(level, false); });
  $('btnNextLevel').addEventListener('click', function () { touched = true; if (level >= RAW.length - 1) { hideResult(); openSheet(); } else loadLevel(level + 1, false); });

  loadLocal(); buildSheet(); applyActive(''); saveLocal(); cloudInit();
})();
