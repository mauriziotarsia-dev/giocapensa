// Level generator for a 6x6 sliding-car puzzle (exit on the right of row 2).
// For a random set of vehicles it enumerates the whole reachable state graph,
// runs a multi-source BFS from every solved state and keeps the state that is
// farthest from a solution. Hill-climbing mutations push the difficulty up.
// Finally vehicles that do not affect the optimal solution length are removed.
#include <bits/stdc++.h>
using namespace std;
typedef uint64_t u64;

struct Veh { int horiz, len, line; };

static std::mt19937_64 rng(12345);
static inline int rnd(int n) { return (int)(rng() % (u64)n); }

struct HashMap {
  vector<u64> keys; vector<int> vals; size_t mask = 0, count = 0;
  static constexpr u64 EMPTY = ~0ULL;
  void init(size_t capPow2) { keys.assign(capPow2, EMPTY); vals.assign(capPow2, 0); mask = capPow2 - 1; count = 0; }
  static inline u64 h(u64 x) { x ^= x >> 33; x *= 0xff51afd7ed558ccdULL; x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53ULL; x ^= x >> 33; return x; }
  void grow() {
    vector<u64> ok; vector<int> ov; ok.swap(keys); ov.swap(vals);
    size_t ncap = (mask + 1) * 2; keys.assign(ncap, EMPTY); vals.assign(ncap, 0); mask = ncap - 1;
    for (size_t i = 0; i < ok.size(); i++) if (ok[i] != EMPTY) {
      size_t j = h(ok[i]) & mask; while (keys[j] != EMPTY) j = (j + 1) & mask; keys[j] = ok[i]; vals[j] = ov[i];
    }
  }
  // returns existing value, or -1 after inserting (k -> val)
  inline int getOrInsert(u64 k, int val) {
    if ((count + 1) * 2 > mask + 1) grow();
    size_t i = h(k) & mask;
    while (true) {
      if (keys[i] == EMPTY) { keys[i] = k; vals[i] = val; count++; return -1; }
      if (keys[i] == k) return vals[i];
      i = (i + 1) & mask;
    }
  }
};

static inline u64 cellBit(const Veh& v, int q) { return v.horiz ? (1ULL << (v.line * 6 + q)) : (1ULL << (q * 6 + v.line)); }

static HashMap hm;
static vector<u64> states;
static vector<int> adjStart, adj, distv, bfsq;

struct Eval { bool ok; int maxDist; u64 far; int nStates; };

static u64 packPos(const vector<int>& p) { u64 s = 0; for (size_t i = 0; i < p.size(); i++) s |= (u64)p[i] << (3 * i); return s; }
static vector<int> unpackPos(u64 s, int n) { vector<int> p(n); for (int i = 0; i < n; i++) p[i] = (s >> (3 * i)) & 7; return p; }

// Expand state s, calling f(nextState) for every single-vehicle slide.
template <class F>
static inline void expand(const vector<Veh>& V, const u64 cm[][5], u64 s, F f) {
  int n = (int)V.size(); int p[20]; u64 occ = 0;
  for (int i = 0; i < n; i++) { p[i] = (s >> (3 * i)) & 7; occ |= cm[i][p[i]]; }
  for (int i = 0; i < n; i++) {
    const Veh& v = V[i]; u64 base = s & ~(7ULL << (3 * i));
    for (int q = p[i] - 1; q >= 0; q--) { if (occ & cellBit(v, q)) break; f(base | ((u64)q << (3 * i))); }
    for (int q = p[i] + 1; q + v.len - 1 < 6; q++) { if (occ & cellBit(v, q + v.len - 1)) break; f(base | ((u64)q << (3 * i))); }
  }
}

static void buildMasks(const vector<Veh>& V, u64 cm[][5]) {
  for (size_t i = 0; i < V.size(); i++) for (int p = 0; p + V[i].len <= 6; p++) {
    u64 m = 0; for (int k = 0; k < V[i].len; k++) m |= cellBit(V[i], p + k); cm[i][p] = m;
  }
}

// Whole-component analysis: farthest state from any solved state.
static Eval evaluate(const vector<Veh>& V, const vector<int>& start, int cap) {
  u64 cm[20][5]; buildMasks(V, cm);
  states.clear(); adjStart.clear(); adj.clear(); hm.init(1 << 12);
  u64 s0 = packPos(start); hm.getOrInsert(s0, 0); states.push_back(s0);
  bool overflow = false;
  for (size_t head = 0; head < states.size() && !overflow; head++) {
    adjStart.push_back((int)adj.size());
    expand(V, cm, states[head], [&](u64 ns) {
      int id = hm.getOrInsert(ns, (int)states.size());
      if (id < 0) { id = (int)states.size(); states.push_back(ns); if ((int)states.size() > cap) overflow = true; }
      adj.push_back(id);
    });
  }
  if (overflow) return {false, 0, 0, (int)states.size()};
  adjStart.push_back((int)adj.size());
  int N = (int)states.size(); distv.assign(N, -1); bfsq.clear();
  for (int i = 0; i < N; i++) if ((states[i] & 7) == 4) { distv[i] = 0; bfsq.push_back(i); }
  if (bfsq.empty()) return {false, 0, 0, N};
  for (size_t h = 0; h < bfsq.size(); h++) { int u = bfsq[h]; for (int e = adjStart[u]; e < adjStart[u + 1]; e++) { int w = adj[e]; if (distv[w] < 0) { distv[w] = distv[u] + 1; bfsq.push_back(w); } } }
  int md = 0; for (int i = 0; i < N; i++) md = max(md, distv[i]);
  int cnt = 0; u64 far = 0; for (int i = 0; i < N; i++) if (distv[i] == md) { cnt++; if (rnd(cnt) == 0) far = states[i]; }
  return {true, md, far, N};
}

// Shortest solution length from one start state (-1 if none / too big).
static int solveLen(const vector<Veh>& V, const vector<int>& start, int cap) {
  u64 cm[20][5]; buildMasks(V, cm);
  states.clear(); distv.clear(); hm.init(1 << 12);
  u64 s0 = packPos(start); if ((s0 & 7) == 4) return 0;
  hm.getOrInsert(s0, 0); states.push_back(s0); distv.push_back(0);
  int found = -1;
  for (size_t head = 0; head < states.size() && found < 0; head++) {
    int d = distv[head];
    expand(V, cm, states[head], [&](u64 ns) {
      if (found >= 0) return;
      int id = hm.getOrInsert(ns, (int)states.size());
      if (id < 0) { states.push_back(ns); distv.push_back(d + 1); if ((ns & 7) == 4) found = d + 1; }
    });
    if ((int)states.size() > cap) return -1;
  }
  return found;
}

static u64 occupancy(const vector<Veh>& V, const vector<int>& pos) {
  u64 o = 0; for (size_t i = 0; i < V.size(); i++) for (int k = 0; k < V[i].len; k++) o |= cellBit(V[i], pos[i] + k); return o;
}

static const int MAX_TRUCKS = 4, MAX_VEH = 14; // target included in MAX_VEH

static bool addRandom(vector<Veh>& V, vector<int>& pos) {
  if ((int)V.size() >= MAX_VEH) return false;
  int trucks = 0; for (auto& v : V) if (v.len == 3) trucks++;
  u64 occ = occupancy(V, pos);
  for (int t = 0; t < 60; t++) {
    Veh v; v.horiz = rnd(2); v.len = (trucks < MAX_TRUCKS && rnd(100) < 30) ? 3 : 2; v.line = rnd(6);
    if (v.horiz && v.line == 2) continue; // only the target drives on the exit row
    int p = rnd(7 - v.len); u64 m = 0; for (int k = 0; k < v.len; k++) m |= cellBit(v, p + k);
    if (m & occ) continue;
    V.push_back(v); pos.push_back(p); return true;
  }
  return false;
}
static void removeRandom(vector<Veh>& V, vector<int>& pos) {
  if (V.size() <= 2) return; int i = 1 + rnd((int)V.size() - 1); V.erase(V.begin() + i); pos.erase(pos.begin() + i);
}

static string gridString(const vector<Veh>& V, const vector<int>& pos) {
  string g(36, 'o');
  for (size_t i = 0; i < V.size(); i++) for (int k = 0; k < V[i].len; k++) {
    int q = pos[i] + k; int cell = V[i].horiz ? V[i].line * 6 + q : q * 6 + V[i].line; g[cell] = (char)('A' + i);
  }
  return g;
}

int main(int argc, char** argv) {
  double seconds = argc > 1 ? atof(argv[1]) : 60; u64 seed = argc > 2 ? strtoull(argv[2], 0, 10) : 1; rng.seed(seed); int mode = argc > 3 ? atoi(argv[3]) : 0;
  const int CAP = 250000;
  auto t0 = chrono::steady_clock::now();
  auto elapsed = [&]() { return chrono::duration<double>(chrono::steady_clock::now() - t0).count(); };
  long evals = 0, runs = 0; map<int, int> hist;
  static const int stepChoices[] = {0, 0, 0, 3, 6, 10, 15, 25, 40, 60, 100, 160, 250, 400};
  while (elapsed() < seconds) {
    runs++;
    vector<Veh> V; vector<int> pos; V.push_back({1, 2, 2}); pos.push_back(rnd(4));
    int n0 = 1 + rnd(12); for (int i = 0; i < n0; i++) addRandom(V, pos);
    Eval e = evaluate(V, pos, CAP); evals++;
    if (!e.ok) continue;
    pos = unpackPos(e.far, (int)V.size()); int score = e.maxDist;
    static const int longChoices[] = {160, 250, 400, 600};
    int steps = mode == 1 ? longChoices[rnd(4)] : stepChoices[rnd(14)];
    for (int s = 0; s < steps && elapsed() < seconds; s++) {
      vector<Veh> V2 = V; vector<int> p2 = pos; int r = rnd(10);
      if (r < 4) { if (!addRandom(V2, p2)) { removeRandom(V2, p2); addRandom(V2, p2); } }
      else if (r < 6) removeRandom(V2, p2);
      else { removeRandom(V2, p2); addRandom(V2, p2); if (rnd(3) == 0) addRandom(V2, p2); }
      Eval e2 = evaluate(V2, p2, CAP); evals++;
      if (e2.ok && e2.maxDist >= score) { V = V2; pos = unpackPos(e2.far, (int)V2.size()); score = e2.maxDist; }
    }
    if (score < 2) continue;
    // drop vehicles that do not change the optimal length
    vector<int> order; for (int i = 1; i < (int)V.size(); i++) order.push_back(i); shuffle(order.begin(), order.end(), rng);
    vector<char> keep(V.size(), 1);
    for (int idx : order) {
      vector<Veh> V2; vector<int> p2; for (int i = 0; i < (int)V.size(); i++) if (keep[i] && i != idx) { V2.push_back(V[i]); p2.push_back(pos[i]); }
      if (solveLen(V2, p2, CAP) == score) keep[idx] = 0;
    }
    vector<Veh> VF; vector<int> PF; for (int i = 0; i < (int)V.size(); i++) if (keep[i]) { VF.push_back(V[i]); PF.push_back(pos[i]); }
    int check = solveLen(VF, PF, CAP); if (check != score) continue;
    hist[score]++;
    printf("%d %d %s\n", score, (int)VF.size(), gridString(VF, PF).c_str()); fflush(stdout);
  }
  fprintf(stderr, "runs=%ld evals=%ld time=%.1f\n", runs, evals, elapsed());
  for (auto& kv : hist) fprintf(stderr, "%d:%d ", kv.first, kv.second); fprintf(stderr, "\n");
  return 0;
}
