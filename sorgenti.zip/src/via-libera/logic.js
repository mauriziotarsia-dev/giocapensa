/* Pure game logic: level parsing and shortest-path solver (no DOM). */
(function (root) {
  'use strict';
  // "grid:colors:min" — grid is 36 chars (row-major), 'o' empty, 'A' the car to free, 'B'.. other vehicles.
  function parseLevel(str) {
    var parts = str.split(':'), g = parts[0], colors = parts[1] || '', cellsOf = {}, i;
    for (i = 0; i < 36; i++) { var ch = g.charAt(i); if (ch !== 'o') (cellsOf[ch] = cellsOf[ch] || []).push(i); }
    var vehicles = Object.keys(cellsOf).sort().map(function (ch, k) {
      var cells = cellsOf[ch], horiz = cells[1] - cells[0] === 1, r = Math.floor(cells[0] / 6), c = cells[0] % 6, line = horiz ? r : c;
      return { hero: ch === 'A', horiz: horiz, len: cells.length, line: line, pos: horiz ? c : r, color: ch === 'A' ? 'h' : (colors.charAt(k - 1) || 'b'), face: line % 2 === 0 ? 1 : -1 };
    });
    return { vehicles: vehicles, min: parseInt(parts[2], 10) || 0 };
  }
  function cellOf(v, q) { return v.horiz ? v.line * 6 + q : q * 6 + v.line; }
  // Free range [min, max] for vehicle i given every vehicle position.
  function range(vs, pos, i) {
    var occ = new Uint8Array(36), j, t, v = vs[i];
    for (j = 0; j < vs.length; j++) if (j !== i) for (t = 0; t < vs[j].len; t++) occ[cellOf(vs[j], pos[j] + t)] = 1;
    var lo = pos[i], hi = pos[i];
    while (lo > 0 && !occ[cellOf(v, lo - 1)]) lo--;
    while (hi + v.len < 6 && !occ[cellOf(v, hi + v.len)]) hi++;
    return [lo, hi];
  }
  // Breadth-first search; one move = one vehicle sliding any distance. Returns [{i, to}, ...] or null.
  function solve(vs, start, limit) {
    var n = vs.length, pow = [], m = 1, i;
    for (i = 0; i < n; i++) { pow.push(m); m *= 5; }
    var enc = 0; for (i = 0; i < n; i++) enc += start[i] * pow[i];
    var seen = new Map(), keys = [enc], parent = [-1], mvI = [-1], mvTo = [-1], p = new Array(n), occ = new Uint8Array(36);
    seen.set(enc, 0); limit = limit || 600000;
    for (var h = 0; h < keys.length; h++) {
      var k = keys[h], t, q;
      for (i = 0; i < n; i++) { p[i] = k % 5; k = (k - p[i]) / 5; }
      if (p[0] === 4) { var out = []; for (var s = h; parent[s] >= 0; s = parent[s]) out.push({ i: mvI[s], to: mvTo[s] }); return out.reverse(); }
      occ.fill(0);
      for (i = 0; i < n; i++) for (t = 0; t < vs[i].len; t++) occ[cellOf(vs[i], p[i] + t)] = 1;
      for (i = 0; i < n; i++) {
        var v = vs[i], base = keys[h] - p[i] * pow[i], nk;
        for (q = p[i] - 1; q >= 0 && !occ[cellOf(v, q)]; q--) { nk = base + q * pow[i]; if (!seen.has(nk)) { seen.set(nk, 1); keys.push(nk); parent.push(h); mvI.push(i); mvTo.push(q); } }
        for (q = p[i] + 1; q + v.len - 1 < 6 && !occ[cellOf(v, q + v.len - 1)]; q++) { nk = base + q * pow[i]; if (!seen.has(nk)) { seen.set(nk, 1); keys.push(nk); parent.push(h); mvI.push(i); mvTo.push(q); } }
      }
      if (keys.length > limit) return null;
    }
    return null;
  }
  root.VL = { parseLevel: parseLevel, range: range, solve: solve, cellOf: cellOf };
})(typeof window !== 'undefined' ? window : globalThis);
