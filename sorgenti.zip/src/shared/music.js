/* Home-screen music: a short, gentle loop played by Web Audio (no audio files).
   Four chords, a marimba melody, a soft pad and a light bass, with a little room reverb.
   Browsers only let sound start from a touch, so the loop begins at the first tap on the page
   (a tap on a game tile doesn't count: that one is leaving) and stops when the page is left or hidden. */
window.MUSICA = (function () {
  'use strict';
  var AC = window.AudioContext || window.webkitAudioContext, KEY = 'giocapensa.musica';
  var ctx = null, master = null, wet = null, on = true, started = false, timer = 0, nextT = 0, btn = null;
  var BPM = 96, BEAT = 60 / BPM, BAR = BEAT * 4, BLOCK = BAR * 8, VOL = 0.5;
  on = window.OPZ ? OPZ.get('musica') : true;
  function f(n) { return 261.63 * Math.pow(2, n / 12); }                       // semitones from middle C
  var CH = [[0, 4, 7], [-3, 0, 4], [-7, 0, 5], [-5, 2, 7]];                    // C, Am, F, G — one per bar, repeated
  var MEL = [                                                                   // [bar, beat, semitone, beats long]
    [0, 0, 4, 1], [0, 1, 7, 1], [0, 2, 9, 1.5], [0, 3.5, 7, 0.5],
    [1, 0, 4, 1], [1, 1.5, 2, 0.5], [1, 2, 0, 2],
    [2, 0, 9, 1], [2, 1, 7, 1], [2, 2, 5, 1.5],
    [3, 0, 7, 1], [3, 1, 9, 1], [3, 2, 11, 0.5], [3, 3, 14, 1],
    [4, 0, 12, 1], [4, 1, 9, 1], [4, 2, 7, 1.5],
    [5, 0, 4, 1], [5, 1, 7, 1], [5, 2, 9, 1], [5, 3, 12, 1],
    [6, 0, 9, 1.5], [6, 1.5, 7, 1], [6, 2.5, 4, 1.5],
    [7, 0, 2, 1], [7, 1, 4, 1], [7, 2, 7, 2]
  ];
  function build(c) {
    ctx = c; master = ctx.createGain(); master.gain.value = 0.0001;
    var comp = ctx.createDynamicsCompressor(); comp.threshold.value = -16; comp.ratio.value = 3; master.connect(comp); comp.connect(ctx.destination);
    var n = Math.floor(ctx.sampleRate * 1.6), ir = ctx.createBuffer(2, n, ctx.sampleRate), ch, i, d;
    for (ch = 0; ch < 2; ch++) { d = ir.getChannelData(ch); for (i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 3) * (i < 500 ? i / 500 : 1); }
    var conv = ctx.createConvolver(); conv.buffer = ir; wet = ctx.createGain(); wet.gain.value = 0.55; wet.connect(conv); conv.connect(master);   // the reverb goes through the volume too, so it fades out with it
  }
  function note(t, freq, dur, peak, type, attack, send) {
    var o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); if (send) { var s = ctx.createGain(); s.gain.value = send; g.connect(s); s.connect(wet); }
    o.start(t); o.stop(t + dur + 0.08);
  }
  function pad(t, freq, dur, peak) {                                            // a chord that really holds: rises, stays, then fades
    var o = ctx.createOscillator(), g = ctx.createGain(), s2 = ctx.createGain(); o.type = 'triangle'; o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + dur * 0.22); g.gain.setValueAtTime(peak, t + dur * 0.72); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); s2.gain.value = 0.8; g.connect(s2); s2.connect(wet); o.start(t); o.stop(t + dur + 0.08);
  }
  function marimba(t, semi, beats) { var fr = f(semi); note(t, fr, Math.min(1.1, beats * BEAT + 0.35), 0.22, 'sine', 0.008, 0.5); note(t, fr * 4, 0.09, 0.05, 'sine', 0.005); }
  function block(t0) {                                                          // one turn of the loop: eight bars
    var b, i, c;
    for (b = 0; b < 8; b++) {
      var t = t0 + b * BAR; c = CH[b % 4];
      c.forEach(function (s) { pad(t, f(s) / 2, BAR * 1.06, 0.055); });                                                // the chord carries across the whole bar, so the loop never has a hole
      note(t, f(c[0] - 12) / 2, BEAT * 0.9, 0.11, 'sine', 0.02, 0.2); note(t + BEAT * 2, f(c[0] - 12) / 2, BEAT * 0.9, 0.09, 'sine', 0.02, 0.2);   // bass
      if (b === 3 || b === 7) note(t + BEAT * 3, f(24), 1.4, 0.05, 'sine', 0.01, 0.9);                                  // a bell to close the phrase
    }
    for (i = 0; i < MEL.length; i++) marimba(t0 + MEL[i][0] * BAR + MEL[i][1] * BEAT, MEL[i][2], MEL[i][3]);
  }
  function pump() { var now = ctx.currentTime; while (nextT < now + 2) { block(nextT); nextT += BLOCK; } }
  function begin() {
    started = true; nextT = ctx.currentTime + 0.15; pump(); clearInterval(timer); timer = setInterval(pump, 700);
    master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setValueAtTime(0.0001, ctx.currentTime); master.gain.exponentialRampToValueAtTime(VOL, ctx.currentTime + 2.2);
  }
  function start() {
    if (started || !on) return;
    try {
      if (!ctx) { if (!AC) return; build(new AC()); }
      if (ctx.state === 'running') { begin(); return; }
      if (!ctx.resume) return;
      var r = ctx.resume();                                                      // resuming takes a moment: start playing once it is really running
      if (r && r.then) r.then(function () { if (!started && on && ctx.state === 'running') begin(); }, function () {});
      else if (ctx.state === 'running') begin();
    } catch (e) {}
  }
  function stop() {
    if (!started) return; started = false; clearInterval(timer); timer = 0;
    try { master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setValueAtTime(master.gain.value, ctx.currentTime); master.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.7); setTimeout(function () { if (!started && ctx.suspend) ctx.suspend(); }, 800); } catch (e) {}
  }
  function paint() { if (btn) { btn.setAttribute('aria-pressed', on ? 'true' : 'false'); btn.setAttribute('aria-label', on ? 'Spegni la musica' : 'Accendi la musica'); } }
  function set(v) { on = v; if (window.OPZ) OPZ.set('musica', v); paint(); if (v) start(); else stop(); }
  window.addEventListener('opz', function (e) { if (e.detail && e.detail.nome === 'musica' && e.detail.valore !== on) { on = e.detail.valore; paint(); if (on) start(); else stop(); } });
  function init(button) {
    btn = button; paint();
    if (btn) btn.addEventListener('click', function () { set(!on); });
    window.addEventListener('pointerdown', function (e) { if (e.target.closest && e.target.closest('a')) return; start(); }, true);   // a tap on a game is leaving, not listening
    ['touchend', 'keydown'].forEach(function (ev) { window.addEventListener(ev, function () { start(); }, true); });
    document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); else if (on) start(); });
    window.addEventListener('pagehide', stop);
  }
  return { init: init, on: function () { set(true); }, off: function () { set(false); }, isOn: function () { return on; }, isPlaying: function () { return started; },
    _use: function (c) { build(c); master.gain.value = VOL; }, _block: block, _BLOCK: BLOCK };
})();
