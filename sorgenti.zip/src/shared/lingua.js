/* Interface language. «auto» follows the phone; the setting lives in OPZ ('ui': auto | it | en).
   In the code every visible text is written as L('italiano', 'English'); in the markup an element with
   data-en="…" gets that English text, data-en-aria / data-en-title do the same for aria-label and title. */
(function () {
  'use strict';
  function pick() {
    var v = window.OPZ ? OPZ.get('ui') : 'auto';
    if (v === 'it' || v === 'en') return v;
    var langs = (navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || 'it']);
    return /^it/i.test(langs[0] || '') ? 'it' : (/^en/i.test(langs[0] || '') ? 'en' : 'en');      // Italian phones get Italian, everyone else English
  }
  window.LANG = pick();
  window.L = function (it, en) { return window.LANG === 'en' && en != null ? en : it; };
  window.applyLang = function (root) {
    if (window.LANG !== 'en') return;
    root = root || document;
    Array.prototype.forEach.call(root.querySelectorAll('[data-en]'), function (el) { el.textContent = el.getAttribute('data-en'); });
    Array.prototype.forEach.call(root.querySelectorAll('[data-en-aria]'), function (el) { el.setAttribute('aria-label', el.getAttribute('data-en-aria')); });
    Array.prototype.forEach.call(root.querySelectorAll('[data-en-title]'), function (el) { el.setAttribute('title', el.getAttribute('data-en-title')); });
  };
  document.documentElement.lang = window.LANG;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { window.applyLang(document); });
  else window.applyLang(document);
})();
