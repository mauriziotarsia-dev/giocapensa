/* Interface language. «auto» follows the phone; the setting lives in OPZ ('ui': auto | one of LINGUE).
   Nine languages: Italian (the source), English, Spanish, Portuguese, French, German, Japanese, Chinese (traditional and simplified).
   In the code every visible text is written as L('italiano', 'English'), with placeholders {n} filled from a third argument:
   L('livello {n} di {tot}', 'level {n} of {tot}', { n: 3, tot: 120 }). The other languages come from window.TESTI[lang][italian text],
   which src/build.py puts in each page from src/lingue/<lang>.json (only the texts that page uses). In the markup an element with
   data-en="…" gets the text of the current language; data-en-aria / data-en-title do the same for aria-label and title. */
(function () {
  'use strict';
  var LINGUE = ['it', 'en', 'es', 'pt', 'fr', 'de', 'ja', 'zh-Hant', 'zh-Hans'];
  var NOMI = { it: 'Italiano', en: 'English', es: 'Español', pt: 'Português', fr: 'Français', de: 'Deutsch', ja: '日本語', 'zh-Hant': '繁體中文', 'zh-Hans': '简体中文' };
  var LOCALI = { it: 'it-IT', en: 'en-GB', es: 'es-ES', pt: 'pt-BR', fr: 'fr-FR', de: 'de-DE', ja: 'ja-JP', 'zh-Hant': 'zh-TW', 'zh-Hans': 'zh-CN' };
  function fromTag(t) {                                     // 'pt-BR' → 'pt', 'zh-TW' → 'zh-Hant', 'nl' → null
    t = String(t || '').toLowerCase();
    if (/^zh/.test(t)) return /^zh[-_](hant|tw|hk|mo)/.test(t) ? 'zh-Hant' : 'zh-Hans';
    var b = t.split(/[-_]/)[0];
    return LINGUE.indexOf(b) >= 0 ? b : null;
  }
  function phone() {                                        // the first language of the phone that the app speaks, otherwise English
    var langs = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || 'en'];
    for (var i = 0; i < langs.length; i++) { var l = fromTag(langs[i]); if (l) return l; }
    return 'en';
  }
  function pick() { var v = window.OPZ ? OPZ.get('ui') : 'auto'; return LINGUE.indexOf(v) >= 0 ? v : phone(); }
  window.LINGUE = LINGUE; window.LINGUA_NOME = NOMI; window.LINGUA_TEL = phone; window.LINGUA_DA = fromTag;
  window.LANG = pick();
  window.LOCALE = LOCALI[window.LANG];
  window.LOCALE_DI = function (lang) { return LOCALI[lang] || 'en-GB'; };
  var T = window.TESTI || {}, miss = window.__mancanti = {};
  function tr(lang, it, en) {
    if (it == null || lang === 'it') return it;
    if (lang === 'en') return en != null ? en : it;
    var d = T[lang], t = d ? d[it] : null;
    if (t != null) return t;
    miss[lang + ' | ' + it] = 1;                            // the automatic check reads this
    return en != null ? en : it;
  }
  function fill(s, v) { return v && s ? String(s).replace(/\{(\w+)\}/g, function (m, k) { return v[k] != null ? v[k] : m; }) : s; }
  window.L = function (it, en, v) { return fill(tr(window.LANG, it, en), v); };
  window.LT = function (lang, it, en, v) { return fill(tr(lang, it, en), v); };            // a given language (the voice of Stickers)
  window.LP = function (o, lang) { return tr(lang || window.LANG, o.it, o.en); };          // an {it, en} pair from a table
  window.TROVA = function (lang, key) { var d = T[lang]; return d && d[key] != null ? d[key] : null; };   // an optional entry, such as the German «auf dem Bett» ('sul letto#loc')
  window.FRASI = function () {                              // sentences one after the other: with a space, without one in Japanese and Chinese
    return Array.prototype.filter.call(arguments, Boolean).join(/^(ja|zh)/.test(window.LANG) ? '' : ' ');
  };
  window.PICK = function (o, lang) {                        // a value per language from a table {it: …, en: …, es: …}
    lang = lang || window.LANG;
    if (o[lang] != null) return o[lang];
    if (/^zh/.test(lang) && o.zh != null) return o.zh;
    return o.en != null ? o.en : o.it;
  };
  window.applyLang = function (root) {
    if (window.LANG === 'it') return;
    root = root || document;
    function each(sel, f) { Array.prototype.forEach.call(root.querySelectorAll(sel), f); }
    function keep(el, attr, now) { var k = el.getAttribute(attr); if (k == null) { k = now == null ? '' : now; el.setAttribute(attr, k); } return k; }   // the Italian original, so a second pass translates from it again
    each('[data-en]', function (el) { el.textContent = tr(window.LANG, keep(el, 'data-it', el.textContent.trim()), el.getAttribute('data-en')); });
    each('[data-en-aria]', function (el) { el.setAttribute('aria-label', tr(window.LANG, keep(el, 'data-it-aria', el.getAttribute('aria-label')), el.getAttribute('data-en-aria'))); });
    each('[data-en-title]', function (el) { el.setAttribute('title', tr(window.LANG, keep(el, 'data-it-title', el.getAttribute('title')), el.getAttribute('data-en-title'))); });
  };
  document.documentElement.lang = window.LANG;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { window.applyLang(document); });
  else window.applyLang(document);
})();
