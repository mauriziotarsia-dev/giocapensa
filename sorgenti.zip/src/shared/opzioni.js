/* Settings shared by the home screen and all six games, kept in localStorage under one key.
   Games read them at every use, so a change on the home screen reaches a game as soon as it is opened. */
window.OPZ = (function () {
  'use strict';
  var KEY = 'giocapensa.opzioni';
  var DEF = { musica: true, suoni: true, voce: true, lingua: 'it', aiuto: 'attesa' };
  var val = {}, k;
  for (k in DEF) val[k] = DEF[k];
  try {
    var raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (raw && typeof raw === 'object') {
      ['musica', 'suoni', 'voce'].forEach(function (n) { if (typeof raw[n] === 'boolean') val[n] = raw[n]; });
      if (raw.lingua === 'it' || raw.lingua === 'en') val.lingua = raw.lingua;
      if (['subito', 'attesa', 'mai'].indexOf(raw.aiuto) >= 0) val.aiuto = raw.aiuto;
    } else if (localStorage.getItem('giocapensa.musica') === '0') val.musica = false;      // the old music-only switch
  } catch (e) {}
  function save() { try { localStorage.setItem(KEY, JSON.stringify(val)); } catch (e) {} }
  return {
    get: function (n) { return val[n]; },
    set: function (n, v) { if (!(n in DEF)) return; val[n] = v; save(); try { window.dispatchEvent(new CustomEvent('opz', { detail: { nome: n, valore: v } })); } catch (e) {} },
    all: function () { var o = {}, q; for (q in val) o[q] = val[q]; return o; }
  };
})();
