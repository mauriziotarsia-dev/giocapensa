/* Shared shell: header, counters, earned hint, level sheet, result panel, sounds, progress. A game plugs in with Kit.start({...}). */
window.Kit = (function () {
  'use strict';
  var INK = '#4A3B52', $ = function (id) { return document.getElementById(id); };
  var TIERS = [{ name: 'Principiante', color: '#8DD68A' }, { name: 'Intermedio', color: '#FFD95A' }, { name: 'Avanzato', color: '#7DB7F7' }, { name: 'Esperto', color: '#F59A3A' }, { name: 'Maestro', color: '#EE5E4D' }];
  var cfg, data = { best: {}, last: 0 }, level = 0, won = false, statusDefault = true, N = 0, PER = 24;
  var calm = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function now() { return Date.now(); }
  function persist() { try { localStorage.setItem(cfg.key, JSON.stringify(data)); } catch (e) {} }

  // sounds: src/shared/sound.js. A game asks by name — tap, pick, place, back, no, step, star, key, turn, water, done, win — with an optional index for the pitch
  function tone() {}
  function sfx(kind, n) { var S = window.SFX; if (S) S.play({ good: 'place', bad: 'no' }[kind] || kind, typeof n === 'number' ? { i: n } : {}); }
  function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }
  function k(w) { return ' stroke="' + INK + '" stroke-width="' + (w == null ? 5 : w) + '" stroke-linejoin="round" stroke-linecap="round"'; }
  function star(cx, cy, rad, f, sw) {
    var d = '', i, a, rr;
    for (i = 0; i < 10; i++) { a = -Math.PI / 2 + i * Math.PI / 5; rr = i % 2 ? rad * 0.47 : rad; d += (i ? 'L' : 'M') + (cx + rr * Math.cos(a)).toFixed(1) + ' ' + (cy + rr * Math.sin(a)).toFixed(1); }
    return '<path d="' + d + 'Z" fill="' + (f || '#FFD95A') + '"' + k(sw == null ? 4 : sw) + '/>';
  }
  function sparkle(layer, x, y, size) {
    if (calm || !layer) return;
    var h = '', i, a, cols = ['#FFD95A', '#F59A3A', '#7DB7F7', '#8DD68A'], s = size || 17;
    for (i = 0; i < 8; i++) { a = i * 0.785 + 0.3; h += '<g class="spark" style="--dx:' + (Math.cos(a) * s * 5.6).toFixed(0) + 'px;--dy:' + (Math.sin(a) * s * 5.6).toFixed(0) + 'px">' + star(x, y, s, cols[i % 4], 3.5) + '</g>'; }
    layer.insertAdjacentHTML('beforeend', '<g>' + h + '</g>');
    var g = layer.lastElementChild; setTimeout(function () { if (g.parentNode) g.parentNode.removeChild(g); }, 800);
  }
  function confetti(layer, W, H) {
    if (calm || !layer) return;
    var h = '', cols = ['#EE5E4D', '#FFD95A', '#7DB7F7', '#8DD68A', '#4FC3C7', '#F59A3A', '#4C8FE0'], i;
    for (i = 0; i < 56; i++) { var w = 10 + Math.random() * 11; h += '<rect class="conf" x="' + (Math.random() * W).toFixed(0) + '" y="-50" width="' + w.toFixed(0) + '" height="' + (w * 1.5).toFixed(0) + '" rx="3" fill="' + cols[i % cols.length] + '" style="--x:' + ((Math.random() - 0.5) * W * 0.4).toFixed(0) + 'px;--y:' + (H + 160) + 'px;--r:' + ((Math.random() * 900 - 450) | 0) + 'deg;--t:' + (1.9 + Math.random() * 1.7).toFixed(2) + 's;--dl:' + (Math.random() * 0.8).toFixed(2) + 's"/>'; }
    layer.insertAdjacentHTML('beforeend', '<g>' + h + '</g>'); var g = layer.lastElementChild; setTimeout(function () { if (g.parentNode) g.parentNode.removeChild(g); }, 4600);
  }
  function tween(ms, fn, done) {
    if (calm || ms <= 0) { fn(1); if (done) done(); return; }
    var t0 = performance.now();
    (function step(t) { var q = Math.min(1, Math.max(0, (t - t0) / ms)); fn(q); if (q < 1) requestAnimationFrame(step); else if (done) done(); })(t0);
  }

  function solvedCount() { return Object.keys(data.best).length; }
  function setStatus(t) { statusDefault = !t; $('status').textContent = t || (solvedCount() === 0 && cfg.moves() === 0 ? cfg.intro : ''); }
  function tierOf(i) { return TIERS[Math.min(TIERS.length - 1, Math.floor(i / PER))]; }
  function changed(keepStatus) {
    $('statMoves').textContent = cfg.moves(); $('statMin').textContent = cfg.minOf(level); $('statBest').textContent = data.best[level + 1] || '–';
    $('btnUndo').disabled = won || !cfg.canUndo(); $('btnReset').disabled = !won && cfg.moves() === 0;
    if (!keepStatus && statusDefault) setStatus('');
    gateTick();
  }
  function load(i) {
    level = Math.max(0, Math.min(N - 1, i)); data.last = level; persist(); won = false; hideResult();
    var t = tierOf(level), app = $('app'); app.style.setProperty('--tier', t.color); app.style.setProperty('--tier-ink', INK);
    $('badge').textContent = level + 1; $('tierName').textContent = t.name; $('lvOf').textContent = 'livello ' + (level + 1) + ' di ' + N;
    var msg = cfg.load(level); setStatus(msg || ''); gateReset(FIRST); changed();   // a game may greet the level with its own hint text
  }

  /* the hint is earned: 40 s on the level or 8 moves, then 30 s or 6 moves after each use */
  var FIRST = { s: 40, moves: 8 }, AGAIN = { s: 30, moves: 6 }, gate = { acc: 0, t0: 0, base: 0, need: FIRST, timer: 0 };
  function gateSeconds() { return gate.acc + (gate.t0 ? (now() - gate.t0) / 1000 : 0); }
  function gateReset(need) { gate.acc = 0; gate.t0 = document.hidden ? 0 : now(); gate.base = cfg.moves(); gate.need = need; clearInterval(gate.timer); gate.timer = setInterval(gateTick, 250); gateTick(); }
  function hintMode() { return window.OPZ ? OPZ.get('aiuto') : 'attesa'; }
  function gateProgress() { if (hintMode() === 'subito') return 1; if (hintMode() === 'mai') return 0; return Math.max(Math.min(1, gateSeconds() / gate.need.s), Math.min(1, Math.max(0, cfg.moves() - gate.base) / gate.need.moves)); }
  function gateTick() {
    var p = gateProgress(), btn = $('btnHint'), show = !won && hintMode() === 'attesa' && p < 1;
    btn.hidden = hintMode() === 'mai'; btn.disabled = won || p < 1; btn.classList.toggle('waiting', show);
    if (show) $('ringFill').setAttribute('stroke-dashoffset', (188.5 * (1 - p)).toFixed(1)); else { clearInterval(gate.timer); gate.timer = 0; }
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden) { gate.acc = gateSeconds(); gate.t0 = 0; } else if (!gate.t0) gate.t0 = now(); });

  function win() {
    if (won) return; won = true; clearInterval(gate.timer); gate.timer = 0;
    var moves = cfg.moves(), min = cfg.minOf(level), prev = data.best[level + 1], w = cfg.word || ['mossa', 'mosse'];
    if (!prev || moves < prev) data.best[level + 1] = moves;
    data.last = Math.min(N - 1, level + 1); persist(); changed(true); sfx('win'); buzz([12, 60, 18]);
    var perfect = moves <= min, text;
    if (perfect) text = 'Risolto in ' + moves + ' ' + (moves === 1 ? w[0] : w[1]) + ': meno di così non si può.';
    else if (!prev || moves < prev) text = 'Risolto in ' + moves + ' ' + w[1] + (prev ? ', nuovo record' : '') + '. Il minimo è ' + min + '.';
    else text = 'Risolto in ' + moves + ' ' + w[1] + '. Il tuo record è ' + prev + ', il minimo è ' + min + '.';
    var last = level >= N - 1;
    $('resTitle').textContent = cfg.winTitle; $('resPerfect').hidden = !perfect; $('resPerfectTxt').textContent = 'Minimo di ' + w[1];
    $('resText').textContent = text + (last ? " Era l'ultimo livello." : ''); $('btnNext').textContent = last ? 'Scegli un livello' : 'Livello successivo';
    statusDefault = false; $('status').textContent = '';
    setTimeout(function () { if (won) { var r = $('result'); r.hidden = false; void r.offsetWidth; r.classList.add('show'); $('controls').style.visibility = 'hidden'; } }, calm ? 200 : (cfg.winDelay || 1200));
  }
  function hideResult() { var r = $('result'); r.classList.remove('show'); r.hidden = true; $('controls').style.visibility = ''; }

  function openDlg(d) { if (d.showModal) { if (!d.open) d.showModal(); } else d.setAttribute('open', ''); }
  function closeDlg(d) { if (d.close) { if (d.open) d.close(); } else d.removeAttribute('open'); }
  function buildSheet() {
    var html = '', ti, i;
    for (ti = 0; ti * PER < N; ti++) {
      var t = TIERS[Math.min(ti, TIERS.length - 1)], from = ti * PER, to = Math.min(N, from + PER);
      html += '<section class="tier" style="--tier:' + t.color + ';--tier-ink:' + INK + '"><h3><i></i>' + t.name + '<small>' + (from + 1) + '–' + to + '</small><em data-count="' + ti + '"></em></h3><div class="cells">';
      for (i = from; i < to; i++) html += '<button class="lv" type="button" data-level="' + i + '">' + (i + 1) + '</button>';
      html += '</div></section>';
    }
    html += '<section class="rules"><h3>Come si gioca</h3><ul>' + cfg.rules.map(function (r) { return '<li>' + r + '</li>'; }).join('') + '</ul></section>';
    $('sheetBody').innerHTML = html;
    $('sheetBody').addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('.lv') : null; if (!b) return; load(+b.getAttribute('data-level')); closeDlg($('sheet')); });
  }
  function openSheet() {
    var counts = {}, perfect = 0, sh = $('sheet');
    Array.prototype.forEach.call(sh.querySelectorAll('.lv'), function (b) {
      var i = +b.getAttribute('data-level'), mine = data.best[i + 1], min = cfg.minOf(i), ti = Math.floor(i / PER);
      b.classList.toggle('done', !!mine); b.classList.toggle('perfect', !!mine && mine <= min); b.classList.toggle('current', i === level);
      if (mine) { counts[ti] = (counts[ti] || 0) + 1; if (mine <= min) perfect++; }
      b.setAttribute('aria-label', 'Livello ' + (i + 1) + (mine ? ', risolto' : ''));
    });
    Array.prototype.forEach.call(sh.querySelectorAll('[data-count]'), function (el) { var ti = +el.getAttribute('data-count'); el.textContent = (counts[ti] || 0) + ' su ' + Math.min(PER, N - ti * PER); });
    var n = solvedCount();
    $('sheetSummary').textContent = n === 0 ? 'Scegli da quale livello partire: sono tutti aperti.' : n + ' di ' + N + ' risolti, ' + perfect + ' con il minimo.';
    openDlg(sh); var cur = sh.querySelector('.lv.current'); if (cur) { try { cur.scrollIntoView({ block: 'center' }); } catch (e) {} }
  }

  function start(c) {
    cfg = c; N = c.count; PER = c.perTier || 24;
    try {
      var saved = JSON.parse(localStorage.getItem(cfg.key) || 'null');
      if (saved && typeof saved === 'object') {
        if (saved.best && typeof saved.best === 'object') Object.keys(saved.best).forEach(function (q) { var n = +saved.best[q]; if (isFinite(n) && n > 0) data.best[q] = Math.floor(n); });
        if (typeof saved.last === 'number' && saved.last >= 0) data.last = Math.floor(saved.last);
      }
    } catch (e) {}
    if (c.moveLabel) $('lblMoves').textContent = c.moveLabel;
    if (window.KIT_HOME) { $('btnHome').hidden = false; $('btnHome').setAttribute('href', window.KIT_HOME); }
    $('btnUndo').addEventListener('click', function () { if (!won && cfg.canUndo()) { cfg.clearHint(); cfg.undo(); setStatus(''); } });
    $('btnReset').addEventListener('click', function () { load(level); });
    $('btnHint').addEventListener('click', function () { if (won || gateProgress() < 1) return; cfg.clearHint(); var t = cfg.hint(); if (t) { gateReset(AGAIN); setStatus(t); } });
    $('btnLevels').addEventListener('click', openSheet);
    $('btnCloseSheet').addEventListener('click', function () { closeDlg($('sheet')); });
    $('btnAgain').addEventListener('click', function () { load(level); });
    $('btnNext').addEventListener('click', function () { if (level >= N - 1) { hideResult(); openSheet(); } else load(level + 1); });
    buildSheet(); load(Math.min(data.last, N - 1));
  }
  return { start: start, changed: changed, win: win, status: setStatus, sfx: sfx, tone: tone, buzz: buzz, sparkle: sparkle, confetti: confetti, star: star, tween: tween, k: k, INK: INK, calm: calm, isWon: function () { return won; } };
})();
