/* A cheering dinosaur over every «well done» panel (with a gold star when the level was solved in the fewest moves),
   and a soft confetti pattern behind the games. Shared by all pages; does nothing where there is no result panel. */
(function () {
  'use strict';
  var INK = '#4A3B52';
  var DINO = '<svg viewBox="0 0 150 124" aria-hidden="true">' +
    '<ellipse cx="74" cy="117" rx="44" ry="6" fill="' + INK + '" opacity=".16"/>' +
    '<g class="ch-tail"><path d="M40 92q-26 4-34-16q18 8 36 0Z" fill="#7CCB78" stroke="' + INK + '" stroke-width="4" stroke-linejoin="round"/></g>' +
    '<path d="M52 104v10h14v-10M80 104v10h14v-10" fill="#7CCB78" stroke="' + INK + '" stroke-width="4" stroke-linejoin="round"/>' +
    '<path d="M60 56l6-12 6 12M74 52l7-12 6 13M88 52l7-11 5 13" fill="#F59A3A" stroke="' + INK + '" stroke-width="3.5" stroke-linejoin="round"/>' +
    '<ellipse cx="74" cy="84" rx="36" ry="30" fill="#8DD68A" stroke="' + INK + '" stroke-width="4"/><ellipse cx="74" cy="92" rx="21" ry="16" fill="#DDF3CF"/>' +
    '<g class="ch-arm l"><path d="M46 76q-14-8-18-26" fill="none" stroke="' + INK + '" stroke-width="12" stroke-linecap="round"/><path d="M46 76q-14-8-18-26" fill="none" stroke="#8DD68A" stroke-width="6" stroke-linecap="round"/></g>' +
    '<g class="ch-arm r"><path d="M102 76q14-8 18-26" fill="none" stroke="' + INK + '" stroke-width="12" stroke-linecap="round"/><path d="M102 76q14-8 18-26" fill="none" stroke="#8DD68A" stroke-width="6" stroke-linecap="round"/></g>' +
    '<ellipse cx="74" cy="44" rx="27" ry="23" fill="#8DD68A" stroke="' + INK + '" stroke-width="4"/>' +
    '<path d="M60 40q5-6 10 0M78 40q5-6 10 0" fill="none" stroke="' + INK + '" stroke-width="3.5" stroke-linecap="round"/>' +
    '<path d="M62 52q12 14 24 0Z" fill="#7A3B46" stroke="' + INK + '" stroke-width="3" stroke-linejoin="round"/><circle cx="56" cy="51" r="4.5" fill="#FFB59A"/><circle cx="92" cy="51" r="4.5" fill="#FFB59A"/>' +
    '<g class="ch-gold"><path d="M74 2l6 12 13 2-9 9 2 13-12-6-12 6 2-13-9-9 13-2Z" fill="#FFD95A" stroke="' + INK + '" stroke-width="3.5" stroke-linejoin="round"/></g>' +
    '<g class="ch-dots"><circle cx="16" cy="30" r="4" fill="#EE5E4D"/><circle cx="134" cy="26" r="4" fill="#7DB7F7"/><rect x="24" y="10" width="7" height="10" rx="2" fill="#FFD95A" transform="rotate(20 27 15)"/><rect x="118" y="6" width="7" height="10" rx="2" fill="#8DD68A" transform="rotate(-20 121 11)"/></g></svg>';
  var CSS = '.result .cheer{position:absolute; left:50%; top:-84px; width:118px; height:98px; margin-left:-59px; pointer-events:none; transform-origin:50% 100%}' +
    '.result .cheer svg{width:100%; height:100%; overflow:visible}' +
    '.result.show .cheer{animation:chHop 1.1s cubic-bezier(.3,1.5,.5,1) both, chBounce 1.6s ease-in-out 1.1s infinite}' +
    '@keyframes chHop{0%{transform:translateY(60px) scale(.4); opacity:0}60%{opacity:1}100%{transform:none; opacity:1}}' +
    '@keyframes chBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}' +
    '.result .ch-arm{transform-box:fill-box; animation:chWave .5s ease-in-out infinite alternate}' +
    '.result .ch-arm.l{transform-origin:100% 100%} .result .ch-arm.r{transform-origin:0 100%; animation-delay:-.25s}' +
    '@keyframes chWave{from{transform:rotate(-10deg)}to{transform:rotate(10deg)}}' +
    '.result .ch-tail{transform-box:fill-box; transform-origin:100% 50%; animation:chWave .7s ease-in-out infinite alternate}' +
    '.result .ch-gold{display:none} .result .cheer.gold .ch-gold{display:inline; transform-box:fill-box; transform-origin:50% 50%; animation:chSpin 2.4s linear infinite}' +
    '@keyframes chSpin{0%,100%{transform:rotate(-12deg) scale(1)}50%{transform:rotate(12deg) scale(1.12)}}' +
    'body.festa-bg{background-image:radial-gradient(rgba(74,59,82,.055) 2px,transparent 2.6px),radial-gradient(rgba(255,196,90,.2) 3px,transparent 3.6px);background-size:36px 36px,58px 58px;background-position:0 0,18px 29px}' +
    '@media (prefers-reduced-motion: reduce){.result .cheer,.result .ch-arm,.result .ch-tail,.result .cheer.gold .ch-gold{animation:none !important}}';
  function setup() {
    var res = document.getElementById('result'); if (!res || res.querySelector('.cheer')) return;
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    document.body.classList.add('festa-bg');
    var d = document.createElement('div'); d.className = 'cheer'; d.setAttribute('aria-hidden', 'true'); d.innerHTML = DINO; res.insertBefore(d, res.firstChild);
    var mo = new MutationObserver(function () {
      if (!res.classList.contains('show')) return;
      var gp = document.getElementById('resPerfect'); d.classList.toggle('gold', !!(gp && !gp.hidden && gp.offsetParent !== null));
    });
    mo.observe(res, { attributes: true, attributeFilter: ['class'] });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup); else setup();
})();
