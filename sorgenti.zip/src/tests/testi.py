#!/usr/bin/env python3
"""Inventory of every visible text and check of the translations.

    python3 src/tests/testi.py            # check: every Italian text has its translation in src/lingue/<lang>.json
    python3 src/tests/testi.py --elenco   # print every text found (Italian | English | where)

The Italian text is the key. Texts come from:
  - L('italiano', 'English') in the code (also L('… {n} …', '… {n} …', {n: …}) with placeholders);
  - markup with data-en="…" (the element's own text), data-en-aria="…" (its aria-label), data-en-title="…" (its title);
  - the tables listed in TABLES below (scene names, zones, shapes…), which hold {it: …, en: …} pairs.
A call whose arguments are not plain strings is reported: it must become a template with placeholders."""
import glob, json, os, re, sys

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/'
LANGS = ['es', 'pt', 'fr', 'de', 'ja', 'zh-Hant', 'zh-Hans']
SKIP = ('tests/', 'native/', 'lingue/')


def js_string(s, i):
    """Parse a JS string literal starting at s[i] (quote). Returns (value, index after it) or None."""
    q = s[i]
    if q not in '\'"`': return None
    out, j = [], i + 1
    while j < len(s):
        c = s[j]
        if c == '\\':
            n = s[j + 1]; out.append({'n': '\n', 't': '\t', "'": "'", '"': '"', '\\': '\\', '`': '`'}.get(n, n)); j += 2; continue
        if c == q: return ''.join(out), j + 1
        if q == '`' and c == '$' and s[j + 1:j + 2] == '{': return None
        out.append(c); j += 1
    return None


def skip_ws(s, i):
    while i < len(s) and s[i] in ' \t\r\n': i += 1
    return i


def skip_arg(s, i):
    """Skip one JS argument (an expression) up to the comma that ends it."""
    depth = 0
    while i < len(s):
        c = s[i]
        if c in '\'"`':
            r = js_string(s, i); i = r[1] if r else i + 1; continue
        if c in '([{': depth += 1
        elif c in ')]}':
            if depth == 0: return i
            depth -= 1
        elif c == ',' and depth == 0: return i + 1
        i += 1
    return i


ALLOWED = (r"LT\(l, z\.it, z\.en\)", r"LT\(vlang\(\), it, enText\)", r"LT\(vlang\(\), lb\.getAttribute\('data-it'\)")   # their texts come from tables or from the markup


def calls(text):
    """Every L( … ), LT(lang, … ) and say( … ) call: yields (line, it, en, ok) — ok is False when the texts are not two plain strings (optionally + an object)."""
    for m in re.finditer(r'(?<![\w$.])(L|LT|say)\(', text):
        if any(re.match(a, text[m.start():]) for a in ALLOWED): continue
        i = skip_ws(text, m.end()); line = text.count('\n', 0, m.start()) + 1
        if m.group(1) == 'LT': i = skip_ws(text, skip_arg(text, i))
        if m.group(1) == 'say' and text[i:i + 1] not in ('\'', '"'): continue      # the definition, function say(it, enText)
        a = js_string(text, i) if i < len(text) else None
        if not a: yield line, None, text[m.start():m.start() + 120], False; continue
        i = skip_ws(text, a[1])
        if text[i:i + 1] != ',': yield line, a[0], text[m.start():m.start() + 120], False; continue
        i = skip_ws(text, i + 1); b = js_string(text, i)
        if not b: yield line, a[0], text[m.start():m.start() + 120], False; continue
        i = skip_ws(text, b[1])
        if text[i:i + 1] in (')', ','): yield line, a[0], b[0], True
        else: yield line, a[0], text[m.start():m.start() + 120], False


def unhtml(t):
    return (t.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'").replace('&nbsp;', ' '))


def markup(text):
    """data-en / data-en-aria / data-en-title in HTML (also inside JS strings that build markup)."""
    for m in re.finditer(r'<([a-zA-Z0-9]+)((?:[^>"\']|"[^"]*"|\'[^\']*\')*)>', text):
        attrs = m.group(2); line = text.count('\n', 0, m.start()) + 1
        def attr(name):
            a = re.search(r'\s' + name + r'="([^"]*)"', attrs) or re.search(r"\s" + name + r"='([^']*)'", attrs)
            return unhtml(a.group(1)) if a else None
        en = attr('data-en')
        if en is not None:
            close = text.find('</' + m.group(1) + '>', m.end())
            inner = text[m.end():close] if close > 0 else ''
            if '<' in inner: yield line, None, en, 'text'   # data-en on an element with children: not allowed
            else: yield line, unhtml(inner).strip(), en, 'text'
        for kind, src in (('aria', 'aria-label'), ('title', 'title')):
            e2 = attr('data-en-' + kind)
            if e2 is not None: yield line, attr(src), e2, kind


PAIR = re.compile(r"\bit:\s*('(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\")\s*,\s*en:\s*('(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\")")


def pairs(text):
    for m in PAIR.finditer(text):
        a = js_string(m.group(1), 0); b = js_string(m.group(2), 0)
        if a and b: yield text.count('\n', 0, m.start()) + 1, a[0], b[0]


def inventory():
    found, bad = {}, []
    files = sorted(f for f in glob.glob(SRC + '**/*', recursive=True) if f.endswith(('.js', '.html')) and not f[len(SRC):].startswith(SKIP))
    for f in files:
        rel = f[len(SRC):]; text = open(f, encoding='utf-8').read()
        for line, it, en, ok in calls(text):
            if rel == 'shared/lingua.js': continue
            if ok: found.setdefault(it, (en, rel + ':%d' % line))
            else: bad.append((rel, line, en))
        for line, it, en, kind in markup(text):
            if it is None: bad.append((rel, line, 'data-%s senza testo semplice: %s' % (kind, en))); continue
            if it: found.setdefault(it, (en, rel + ':%d' % line))
        if rel in ('adesivi/scene.js', 'adesivi/scene2.js'):           # the {it: …, en: …} pairs of scenes, zones and places
            for line, it, en in pairs(text): found.setdefault(it, (en, rel + ':%d' % line))
    return found, bad


def main():
    found, bad = inventory()
    if '--elenco' in sys.argv:
        for k in sorted(found): print('%s | %s | %s' % (k, found[k][0], found[k][1]))
        print(len(found), 'testi')
    for rel, line, what in bad: print('DA SISTEMARE %s:%d  %s' % (rel, line, what.replace('\n', ' ')[:110]))
    missing = 0
    for lg in LANGS:
        p = SRC + 'lingue/' + lg + '.json'
        d = json.load(open(p, encoding='utf-8')) if os.path.exists(p) else {}
        miss = [k for k in found if k not in d]
        extra = [k for k in d if k not in found and '#' not in k]
        holes = [k for k in found if k in d and not str(d[k]).strip()]
        for k in miss[:8]: print('  %s manca: %s' % (lg, k))
        if len(miss) > 8: print('  %s … e altri %d' % (lg, len(miss) - 8))
        for k in extra[:5]: print('  %s non più usato: %s' % (lg, k))
        for k in holes[:5]: print('  %s vuoto: %s' % (lg, k))
        missing += len(miss) + len(holes)
        ph = [k for k in found if k in d and sorted(re.findall(r'\{\w+\}', k)) != sorted(re.findall(r'\{\w+\}', str(d[k])))]
        for k in ph[:5]: print('  %s segnaposto diversi: %s → %s' % (lg, k, d[k]))
        missing += len(ph)
    print('Testi: %d, da sistemare: %d, traduzioni mancanti o sbagliate: %d' % (len(found), len(bad), missing))
    sys.exit(1 if bad or missing else 0)


if __name__ == '__main__':
    main()
