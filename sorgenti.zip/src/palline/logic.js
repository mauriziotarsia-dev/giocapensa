/* Pure logic for the ball-sorting game (no DOM): parsing, rules, A* solver. */
(function (root) {
  'use strict';
  // "K|tube,tube,...|min" — each tube lists its balls from the bottom up, one letter per colour
  function parse(str) { var p = str.split('|'); return { K: +p[0], tubes: p[1].split(',').map(function (t) { return t.split(''); }), min: +p[2] }; }
  function solved(tubes, K) {
    for (var i = 0; i < tubes.length; i++) { var t = tubes[i]; if (!t.length) continue; if (t.length !== K) return false; for (var j = 1; j < t.length; j++) if (t[j] !== t[0]) return false; }
    return true;
  }
  function full(t, K) { if (t.length !== K) return false; for (var j = 1; j < K; j++) if (t[j] !== t[0]) return false; return true; }
  // lower bound: for each colour the longest run sitting at the bottom of a tube may stay, every other ball moves at least once
  function heur(tubes) {
    var best = {}, total = 0, keep = 0, i, t, run, c;
    for (i = 0; i < tubes.length; i++) { t = tubes[i]; total += t.length; if (!t.length) continue; run = 1; while (run < t.length && t[run] === t[0]) run++; if (!(best[t[0]] >= run)) best[t[0]] = run; }
    for (c in best) keep += best[c];
    return total - keep;
  }
  function keyOf(tubes) { return tubes.map(function (t) { return t.join(''); }).sort().join('|'); }
  // A* (w = 1 gives the true minimum; w > 1 is faster and still returns a valid way to finish)
  function solve(tubes, K, w, cap) {
    w = w || 1; cap = cap || 60000;
    if (solved(tubes, K)) return [];
    var nodes = [{ t: tubes.map(function (x) { return x.slice(); }), g: 0, p: -1, m: null }], seen = {}, buckets = [], f0 = Math.round(w * heur(tubes)), expanded = 0, f, idx, n, i, j, k;
    seen[keyOf(tubes)] = 0; (buckets[f0] = buckets[f0] || []).push(0);
    for (f = 0; f < buckets.length; f++) {
      if (!buckets[f]) continue;
      for (idx = 0; idx < buckets[f].length; idx++) {
        n = nodes[buckets[f][idx]];
        if (n.g + Math.round(w * heur(n.t)) !== f || seen[keyOf(n.t)] !== n.g) continue;     // a better copy was found later
        if (solved(n.t, K)) { var out = []; for (k = buckets[f][idx]; nodes[k].p >= 0; k = nodes[k].p) out.push(nodes[k].m); return out.reverse(); }
        if (++expanded > cap) return null;
        for (i = 0; i < n.t.length; i++) {
          var src = n.t[i]; if (!src.length) continue;
          var usedEmpty = false;
          for (j = 0; j < n.t.length; j++) {
            if (j === i || n.t[j].length >= K) continue;
            if (!n.t[j].length) { if (usedEmpty || src.length === 1) continue; usedEmpty = true; }
            var nt = n.t.map(function (x, q) { return q === i || q === j ? x.slice() : x; });
            nt[j].push(nt[i].pop());
            var key = keyOf(nt), ng = n.g + 1;
            if (seen[key] !== undefined && seen[key] <= ng) continue;
            seen[key] = ng; nodes.push({ t: nt, g: ng, p: buckets[f][idx], m: { from: i, to: j } });
            var nf = ng + Math.round(w * heur(nt)); (buckets[nf] = buckets[nf] || []).push(nodes.length - 1);
          }
        }
      }
    }
    return null;
  }
  root.TB = { parse: parse, solved: solved, full: full, heur: heur, solve: solve };
})(typeof window !== 'undefined' ? window : globalThis);
