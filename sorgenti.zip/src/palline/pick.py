#!/usr/bin/env python3
"""Choose 120 graded levels (5 tiers x 24) from the generated pools and give every level its own colours."""
import json, random
from collections import defaultdict
random.seed(31)
G = '/home/claude/tubi/'
def pool(c, k):
    out = []
    for line in open(G + f'pool_{c}_{k}.txt'):
        a = line.split(); out.append({'c': int(a[0]), 'k': int(a[1]), 'm': int(a[2]), 'tubes': a[3].split(',')})
    return out
def take(items, n, lo, hi):
    """n levels with minimum moves spread evenly between lo and hi"""
    by = defaultdict(list)
    for it in items:
        if lo <= it['m'] <= hi and not it.get('used'): by[it['m']].append(it)
    for v in by.values(): random.shuffle(v)
    ms = sorted(by); got = []
    while len(got) < n and any(by[m] for m in ms):
        for m in ms:
            if by[m] and len(got) < n: it = by[m].pop(); it['used'] = True; got.append(it)
    assert len(got) == n, (n, len(got), lo, hi)
    return got
P = {(c, k): pool(c, k) for c, k in [(2, 2), (2, 3), (3, 2), (2, 4), (3, 3), (3, 4), (4, 3), (4, 4)]}
tiers = [
    take(P[2, 2], 3, 2, 3) + take(P[2, 3], 11, 2, 7) + take(P[3, 2], 10, 2, 5),
    take(P[2, 4], 8, 5, 11) + take(P[3, 3], 16, 4, 8),
    take(P[3, 3], 8, 8, 10) + take(P[3, 4], 16, 7, 11),
    take(P[3, 4], 8, 12, 15) + take(P[4, 3], 16, 8, 12),
    take(P[4, 3], 6, 12, 13) + take(P[4, 4], 18, 13, 20),
]
PAL = 'rybgp'
levels = []
for t in tiers:
    t.sort(key=lambda it: (it['m'], it['c'] * it['k'], it['c']))
    for it in t:
        cols = random.sample(PAL, it['c'])
        tubes = [''.join(cols[int(ch) - 1] for ch in tube) for tube in it['tubes']]
        levels.append('%d|%s|%d' % (it['k'], ','.join(tubes), it['m']))
json.dump(levels, open(G + 'levels.json', 'w'))
for i in range(5): print('fascia', i + 1, 'minimi:', ' '.join(l.split('|')[2] for l in levels[i * 24:(i + 1) * 24]))
print(levels[0], levels[30], levels[119])
