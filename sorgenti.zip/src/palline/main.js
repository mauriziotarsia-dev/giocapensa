(function () {
  'use strict';
  var RAW = window.TB_LEVELS, TB = window.TB, PER_TIER = 24, KEY = 'palline.v1', INK = '#4A3B52';
  var TIERS = [
    { name: 'Principiante', color: '#8DD68A' }, { name: 'Intermedio', color: '#FFD95A' }, { name: 'Avanzato', color: '#7DB7F7' },
    { name: 'Esperto', color: '#F59A3A' }, { name: 'Maestro', color: '#EE5E4D' }
  ];
  var NAME = { r: 'rossa', y: 'gialla', b: 'blu', g: 'verde', p: 'arancione' }, NOTE = { r: 523.25, y: 587.33, b: 659.25, g: 783.99, p: 880 };
  var ORD = ['primo', 'secondo', 'terzo', 'quarto', 'quinto', 'sesto'];
  var $ = function (id) { return document.getElementById(id); };
  var scene = $('scene'), statusEl = $('status'), result = $('result'), controls = $('controls'), sheet = $('sheet');
  var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function now() { return Date.now(); }

  /* ---------- saved progress (this device) ---------- */
  var data = { best: {}, last: 0 };
  try {
    var saved = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (saved && typeof saved === 'object') {
      if (saved.best && typeof saved.best === 'object') Object.keys(saved.best).forEach(function (k) { var n = +saved.best[k]; if (isFinite(n) && n > 0) data.best[k] = Math.floor(n); });
      if (typeof saved.last === 'number' && saved.last >= 0) data.last = Math.floor(saved.last);
    }
  } catch (e) {}
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) {} }

  /* ---------- sound: src/shared/sound.js; every colour still rings its own note ---------- */
  function sfx(kind, col) { var S = window.SFX; if (S) S.play({ lift: 'pick', drop: 'drop', nope: 'no', done: 'done', win: 'win' }[kind] || kind, NOTE[col] ? { note: NOTE[col] } : {}); }
  function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

  /* ---------- drawing ---------- */
  var SP = 136, M = 34, R = 41, STEP = 86, TOP = 200, W = 0, H = 0, K = 0, T = 0, BY = 0;
  function k(w) { return ' stroke="' + INK + '" stroke-width="' + (w == null ? 5 : w) + '" stroke-linejoin="round" stroke-linecap="round"'; }
  function dot(x, y, r, f) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + (f || INK) + '"/>'; }
  function star(cx, cy, rad, f, sw) {
    var d = '', i, a, rr;
    for (i = 0; i < 10; i++) { a = -Math.PI / 2 + i * Math.PI / 5; rr = i % 2 ? rad * 0.47 : rad; d += (i ? 'L' : 'M') + (cx + rr * Math.cos(a)).toFixed(1) + ' ' + (cy + rr * Math.sin(a)).toFixed(1); }
    return '<path d="' + d + 'Z" fill="' + (f || '#FFD95A') + '"' + k(sw == null ? 4 : sw) + '/>';
  }
  function cx(i) { return M + SP * i + SP / 2; }
  function slotY(j) { return BY - R - 5 - j * STEP; }
  function liftY() { return TOP - 68; }
  function glass(i, close) { var x = cx(i); return 'M' + (x - 52) + ' ' + TOP + 'V' + (BY - 52) + 'A52 52 0 0 0 ' + (x + 52) + ' ' + (BY - 52) + 'V' + TOP + (close ? 'Z' : ''); }

  function backdrop() {
    var s = '<rect x="-3000" y="-3000" width="9000" height="9000" fill="#FFE9D2"/><rect x="-700" y="-500" width="' + (W + 1400) + '" height="' + (BY + 540) + '" fill="url(#gWall)"/>', x, y, i;
    for (y = -340; y < H + 400; y += 96) for (x = -620 + ((y / 96) % 2 ? 61 : 0); x < W + 640; x += 122) s += dot(x, y, 7, '#F6D6B4');
    s += '<path d="M-700 34q' + (W / 2 + 700) + ' 70 ' + (W + 1400) + ' 0" fill="none"' + k(5) + '/>';
    for (i = -5; i < T * 2 + 6; i++) {
      var bx = i * 96 - 20, u = (bx + 700) / (W + 1400), by = 34 + 70 * 2 * u * (1 - u) + 6;
      s += '<g class="rm flag" style="--d:' + (-((i + 9) * 0.37) % 3.2).toFixed(2) + 's"><path d="M' + bx + ' ' + by.toFixed(0) + 'h52l-26 48Z" fill="' + ['#EE5E4D', '#FFD95A', '#8DD68A', '#7DB7F7'][(i + 8) % 4] + '"' + k(4.5) + '/></g>';
    }
    s += '<rect x="-3000" y="' + (BY + 40) + '" width="9000" height="4000" fill="#FFE4C8"/>';
    s += '<rect x="-3000" y="' + (BY + 44) + '" width="9000" height="16" fill="#4A3B52" opacity=".12"/><rect x="-3000" y="' + (BY + 8) + '" width="9000" height="36" fill="url(#gShelf)"' + k(5) + '/>';
    s += '<path d="M-3000 ' + (BY + 16) + 'h9000" stroke="#F0C596" stroke-width="5" opacity=".8"/>';
    for (i = -8; i < 14; i++) s += '<path d="M' + (i * 170 + 40) + ' ' + (BY + 27 + (i % 3) * 4) + 'q40 -5 86 0" fill="none" stroke="#9A6636" stroke-width="3" stroke-linecap="round" opacity=".45"/>';
    return s;
  }
  var FACE = {
    r: '<path d="M-13 12q13 12 26 0" fill="none"' + k(4) + '/>',
    y: '<path d="M-12 10h24q-2 14-12 14t-12-14Z" fill="#7A3B46"' + k(3.5) + '/>',
    b: '<ellipse cx="0" cy="15" rx="6" ry="7" fill="#7A3B46"' + k(3.5) + '/>',
    g: '<path d="M-16 9q16 18 32 0" fill="none"' + k(4) + '/>',
    p: '<path d="M-13 11q6 9 13 0 7 9 13 0" fill="none"' + k(4) + '/>'
  };
  var SHADE = { r: ['#FF9C8C', '#EE5E4D', '#BF3A2A'], y: ['#FFF3A8', '#FFD95A', '#DDA21C'], b: ['#B4D9FF', '#5FA4F2', '#3672C4'], g: ['#BDF0B7', '#7CCB78', '#4A9A4B'], p: ['#FFCB96', '#F5903A', '#CC661A'] };
  function defs() {
    var s = '<defs><linearGradient id="gGlass" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset=".3" stop-color="#DFF3FC" stop-opacity=".45"/><stop offset=".75" stop-color="#CFEBF8" stop-opacity=".5"/><stop offset="1" stop-color="#fff" stop-opacity=".7"/></linearGradient>' +
      '<linearGradient id="gShelf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#DDA670"/><stop offset="1" stop-color="#B57A45"/></linearGradient>' +
      '<radialGradient id="gWall" cx="50%" cy="35%" r="80%"><stop offset="0" stop-color="#FFF6EA"/><stop offset="1" stop-color="#FFE3C6"/></radialGradient>';
    Object.keys(SHADE).forEach(function (c) { s += '<radialGradient id="gb-' + c + '" cx="36%" cy="30%" r="78%"><stop offset="0" stop-color="' + SHADE[c][0] + '"/><stop offset=".55" stop-color="' + SHADE[c][1] + '"/><stop offset="1" stop-color="' + SHADE[c][2] + '"/></radialGradient>'; });
    return s + '</defs>';
  }
  function ballMarkup(c, n) {                                    // a shiny marble with a face: calm in the jar, amazed in the air
    return '<g class="ball" data-c="' + c + '" style="--d:' + (-(n * 0.83 % 4.6)).toFixed(2) + 's"><g class="bi">' +
      '<circle r="' + R + '" fill="url(#gb-' + c + ')"' + k(5) + '/><path d="M-27 22a36 36 0 0 0 54 0" fill="none" stroke="#000" stroke-opacity=".1" stroke-width="7" stroke-linecap="round"/>' +
      '<ellipse cx="-16" cy="-20" rx="12" ry="7.500" fill="#fff" opacity=".75" transform="rotate(-32 -16 -20)"/><circle cx="-27" cy="-6" r="3" fill="#fff" opacity=".6"/>' +
      '<g class="blink"><ellipse cx="-13" cy="-4" rx="5" ry="6" fill="' + INK + '"/><ellipse cx="13" cy="-4" rx="5" ry="6" fill="' + INK + '"/>' + dot(-11.5, -6.5, 1.8, '#fff') + dot(14.5, -6.5, 1.8, '#fff') + '</g>' + dot(-24, 8, 6, '#fff') + dot(24, 8, 6, '#fff') +
      '<g class="mN">' + FACE[c] + '</g><ellipse class="mO" cx="0" cy="16" rx="7" ry="8.500" fill="#7A3B46"' + k(3.5) + '/></g></g>';
  }

  /* ---------- game state ---------- */
  var level = 0, tubes = [], els = [], lifted = -1, busy = false, history = [], won = false, minMoves = 0, seq = 0, press = null, dragging = false;
  var ballsG, hintG, fxG;
  function setPos(el, x, y) { el._x = x; el._y = y; el.setAttribute('transform', 'translate(' + x.toFixed(1) + ',' + y.toFixed(1) + ')'); }
  function tween(ms, fn, done) {
    if (calm || ms <= 0) { fn(1); if (done) done(); return; }
    var t0 = performance.now();
    (function step(t) { var q = Math.min(1, (t - t0) / ms); fn(q); if (q < 1) requestAnimationFrame(step); else if (done) done(); })(t0);
  }
  function outBack(q) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(q - 1, 3) + c1 * Math.pow(q - 1, 2); }
  function inQuad(q) { return q * q; }
  function smooth(q) { return q * q * (3 - 2 * q); }
  function tierOf(i) { return TIERS[Math.min(TIERS.length - 1, Math.floor(i / PER_TIER))]; }
  function solvedCount() { return Object.keys(data.best).length; }
  var statusDefault = true;
  function setStatus(t) {
    statusDefault = !t;
    statusEl.textContent = t || (solvedCount() === 0 && history.length === 0 ? 'Tocca un barattolo per sollevare la pallina in cima, poi tocca quello dove vuoi metterla. Ogni barattolo deve avere un solo colore.' : '');
  }

  function loadLevel(i) {
    level = Math.max(0, Math.min(RAW.length - 1, i)); data.last = level; persist();
    var def = TB.parse(RAW[level]); K = def.K; tubes = def.tubes; T = tubes.length; minMoves = def.min;
    lifted = -1; busy = false; history = []; won = false; press = null; dragging = false;
    W = 2 * M + T * SP; BY = TOP + K * STEP + 22; H = BY + 104;
    scene.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    var back = '', front = '', n;
    for (n = 0; n < T; n++) {
      var x = cx(n);
      back += '<g class="tube" data-b="' + n + '"><ellipse cx="' + x + '" cy="' + (BY + 12) + '" rx="62" ry="10" fill="' + INK + '" opacity=".2"/><path d="' + glass(n, true) + '" fill="url(#gGlass)"/></g>';
      front += '<g class="tube" data-f="' + n + '"><path class="tint" d="' + glass(n, true) + '"/><path d="' + glass(n, false) + '" fill="none"' + k(5) + '/>' +
        '<path d="M' + (x - 35) + ' ' + (TOP + 34) + 'V' + (BY - 74) + '" stroke="#fff" stroke-width="10" stroke-linecap="round" opacity=".75"/><path d="M' + (x - 20) + ' ' + (TOP + 40) + 'v34" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".5"/><path d="M' + (x + 36) + ' ' + (BY - 120) + 'V' + (BY - 66) + '" stroke="#fff" stroke-width="6" stroke-linecap="round" opacity=".4"/>' +
        '<rect x="' + (x - 61) + '" y="' + (TOP - 15) + '" width="122" height="27" rx="13.5" fill="#EAF7FD"' + k(5) + '/>' +
        '<g class="cork"><rect x="' + (x - 40) + '" y="' + (TOP - 44) + '" width="80" height="42" rx="13" fill="#C98A5B"' + k(5) + '/><path d="M' + (x - 26) + ' ' + (TOP - 30) + 'h52" stroke="#DFA877" stroke-width="6" stroke-linecap="round"/>' + star(x, TOP - 78, 22) + '</g></g>';
    }
    scene.innerHTML = defs() + '<g>' + backdrop() + '</g><g>' + back + '</g><g id="balls"></g><g>' + front + '</g><g id="hintG"></g><g id="fxG"></g>';
    ballsG = scene.querySelector('#balls'); hintG = scene.querySelector('#hintG'); fxG = scene.querySelector('#fxG');
    els = tubes.map(function (t, ti) { return t.map(function (c, j) { ballsG.insertAdjacentHTML('beforeend', ballMarkup(c, ++seq)); var el = ballsG.lastElementChild; setPos(el, cx(ti), slotY(j)); return el; }); });
    hideResult(); refreshDone(true);
    var t = tierOf(level), app = $('app');
    app.style.setProperty('--tier', t.color); app.style.setProperty('--tier-ink', INK);
    $('badge').textContent = level + 1; $('tierName').textContent = t.name; $('lvOf').textContent = 'livello ' + (level + 1) + ' di ' + RAW.length;
    setStatus(''); gateReset(HINT_FIRST); updateStats();
    if (!calm) els.forEach(function (col, ti) { col.forEach(function (el, j) { var y1 = el._y; setPos(el, el._x, y1 - 420); setTimeout(function () { tween(300, function (q) { setPos(el, el._x, y1 - 420 * (1 - inQuad(q))); }, function () { land(el); }); }, 60 * ti + 70 * j); }); });
  }
  function tubeEls(i) { return [scene.querySelector('[data-b="' + i + '"]'), scene.querySelector('[data-f="' + i + '"]')]; }
  function land(el) { el.classList.remove('land'); void el.getBoundingClientRect(); el.classList.add('land'); }
  function refreshDone(quiet) {
    for (var i = 0; i < T; i++) {
      var done = TB.full(tubes[i], K) && lifted !== i, pair = tubeEls(i), was = pair[1].classList.contains('done');
      pair[1].classList.toggle('done', done);
      if (done) pair[1].querySelector('.tint').setAttribute('fill', 'var(--b-' + tubes[i][0] + ')');
      if (done && !was && !quiet && !TB.solved(tubes, K)) { sparkle(cx(i), TOP - 40); sfx('done', tubes[i][0]); }
    }
  }
  function sparkle(x, y) {
    if (calm) return;
    var h = '', i, a, cols = ['#FFD95A', '#F59A3A', '#7DB7F7', '#8DD68A'];
    for (i = 0; i < 8; i++) { a = i * 0.785 + 0.3; h += '<g class="spark" style="--dx:' + (Math.cos(a) * 96).toFixed(0) + 'px;--dy:' + (Math.sin(a) * 96).toFixed(0) + 'px">' + star(x, y, 17, cols[i % 4], 3.5) + '</g>'; }
    fxG.insertAdjacentHTML('beforeend', '<g>' + h + '</g>');
    var g = fxG.lastElementChild; setTimeout(function () { if (g.parentNode) g.parentNode.removeChild(g); }, 800);
  }
  function confetti() {
    if (calm) return; var h = '', cols = ['#EE5E4D', '#FFD95A', '#7DB7F7', '#8DD68A', '#4FC3C7', '#F59A3A'], i;
    for (i = 0; i < 56; i++) { var w = 10 + Math.random() * 11; h += '<rect class="conf" x="' + (Math.random() * W).toFixed(0) + '" y="-50" width="' + w.toFixed(0) + '" height="' + (w * 1.5).toFixed(0) + '" rx="3" fill="' + cols[i % 6] + '" style="--x:' + ((Math.random() - 0.5) * W * 0.4).toFixed(0) + 'px;--y:' + (H + 160) + 'px;--r:' + ((Math.random() * 900 - 450) | 0) + 'deg;--t:' + (1.9 + Math.random() * 1.7).toFixed(2) + 's;--dl:' + (Math.random() * 0.8).toFixed(2) + 's"/>'; }
    fxG.insertAdjacentHTML('beforeend', '<g>' + h + '</g>');
  }
  function nope(i) { tubeEls(i).forEach(function (el) { el.classList.remove('nope'); void el.getBoundingClientRect(); el.classList.add('nope'); }); sfx('nope'); buzz(14); }
  function updateStats() {
    $('statMoves').textContent = history.length; $('statMin').textContent = minMoves; $('statBest').textContent = data.best[level + 1] || '–';
    $('btnUndo').disabled = won || busy || history.length === 0; $('btnReset').disabled = !won && history.length === 0; gateTick();
  }

  /* ---------- moving a ball ---------- */
  function topEl(i) { return els[i][els[i].length - 1]; }
  function lift(i) {
    var el = topEl(i); lifted = i; ballsG.appendChild(el); el.classList.add('lifted'); refreshDone(true);
    var y0 = el._y; tween(150, function (q) { setPos(el, cx(i), y0 + (liftY() - y0) * outBack(q)); });
    sfx('lift', tubes[i][tubes[i].length - 1]); buzz(6);
  }
  function lower() {
    var i = lifted, el = topEl(i), y0 = el._y, x0 = el._x, y1 = slotY(tubes[i].length - 1); lifted = -1; el.classList.remove('lifted');
    tween(170, function (q) { setPos(el, x0 + (cx(i) - x0) * q, y0 + (y1 - y0) * inQuad(q)); }, function () { land(el); refreshDone(true); });
  }
  function hover() { var el = topEl(lifted), x0 = el._x, y0 = el._y, i = lifted; tween(160, function (q) { setPos(el, x0 + (cx(i) - x0) * smooth(q), y0 + (liftY() - y0) * smooth(q)); }); }
  function transfer(from, to, isUndo) {
    busy = true; lifted = -1;
    var el = els[from].pop(), c = tubes[from].pop(); tubes[to].push(c); els[to].push(el);
    if (!isUndo) history.push({ from: from, to: to });
    el.classList.remove('lifted'); ballsG.appendChild(el);
    var x0 = el._x, y0 = el._y, x1 = cx(to), yl = liftY(), y1 = slotY(tubes[to].length - 1), rise = Math.abs(y0 - yl) > 4 && Math.abs(x0 - x1) > 4 && y0 > yl;
    updateStats();
    function fly() {
      var xa = el._x, ya = el._y, span = Math.abs(x1 - xa);
      tween(120 + span * 0.28, function (q) { var e = smooth(q); setPos(el, xa + (x1 - xa) * e, ya + (yl - ya) * e - Math.sin(Math.PI * q) * Math.min(46, span * 0.2)); }, function () {
        tween(150 + (y1 - yl) * 0.22, function (q) { setPos(el, x1, yl + (y1 - yl) * inQuad(q)); }, function () {
          land(el); sfx('drop', c); buzz(10); busy = false; refreshDone(isUndo); updateStats();
          if (!isUndo && TB.solved(tubes, K)) win();
        });
      });
    }
    if (rise) tween(120, function (q) { setPos(el, x0, y0 + (yl - y0) * smooth(q)); }, fly); else fly();
  }

  function geom() { var b = scene.getBoundingClientRect(), s = Math.min(b.width / W, b.height / H); return { s: s, ox: b.left + (b.width - W * s) / 2, oy: b.top + (b.height - H * s) / 2 }; }
  function toScene(x, y) { var g = geom(); return { x: (x - g.ox) / g.s, y: (y - g.oy) / g.s }; }
  function tubeAt(x, y) {
    var p = toScene(x, y); if (p.x < M - 46 || p.x > W - M + 46) return -1;
    return Math.max(0, Math.min(T - 1, Math.floor((p.x - M) / SP)));
  }
  scene.addEventListener('pointerdown', function (ev) {
    if (busy || won || press || (ev.pointerType === 'mouse' && ev.button !== 0)) return;
    var i = tubeAt(ev.clientX, ev.clientY); if (i < 0) { if (lifted >= 0) lower(); return; }      // a touch outside the jars puts the ball back
    ev.preventDefault(); clearHint();
    if (lifted < 0) { if (!tubes[i].length) return; lift(i); press = { i: i, x: ev.clientX, y: ev.clientY, fresh: true, pid: ev.pointerId }; }
    else press = { i: i, x: ev.clientX, y: ev.clientY, fresh: false, pid: ev.pointerId };
    try { scene.setPointerCapture(ev.pointerId); } catch (e) {}
  });
  scene.addEventListener('pointermove', function (ev) {
    if (!press || ev.pointerId !== press.pid || lifted < 0) return;
    var far = Math.sqrt(Math.pow(ev.clientX - press.x, 2) + Math.pow(ev.clientY - press.y, 2));
    if (far > 44) press.far = true;                                       // a real drag, not a finger that wobbles while tapping
    if (!dragging && press.i === lifted && far > 16) dragging = true;
    if (dragging) { var p = toScene(ev.clientX, ev.clientY); setPos(topEl(lifted), Math.max(R, Math.min(W - R, p.x)), Math.max(30, Math.min(BY - R, p.y - 74))); } // the ball rides above the finger
  });
  function onUp(ev) {
    if (!press || ev.pointerId !== press.pid) return;
    var pr = press; press = null;
    if (busy || lifted < 0) { dragging = false; return; }
    if (dragging) {
      dragging = false; var to = tubeAt(ev.clientX, ev.clientY);
      if (to >= 0 && to !== lifted && tubes[to].length < K) transfer(lifted, to);
      else if (to >= 0 && to !== lifted) { nope(to); hover(); }            // a full jar says no: the ball waits in the air
      else if (pr.fresh && !pr.far && to === lifted) hover();              // it was only a wobbly first tap: the ball stays up, waiting
      else lower();                                                        // dropped on its own jar, or nowhere: back where it came from
      return;
    }
    if (pr.fresh) return;                                   // first tap: the ball stays up, waiting for a destination
    if (pr.i === lifted) lower(); else if (tubes[pr.i].length < K) transfer(lifted, pr.i); else nope(pr.i);
  }
  scene.addEventListener('pointerup', onUp); scene.addEventListener('pointercancel', onUp);
  scene.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  function settle() { if (lifted >= 0) { var el = topEl(lifted); el.classList.remove('lifted'); setPos(el, cx(lifted), slotY(tubes[lifted].length - 1)); lifted = -1; refreshDone(true); } }
  function undo() { if (busy || won || !history.length) return; clearHint(); settle(); var m = history.pop(); transfer(m.to, m.from, true); setStatus(''); }
  function restart() { if (busy) return; loadLevel(level); }

  /* ---------- hint, earned by time or by moves (same rule as Via libera) ---------- */
  var HINT_FIRST = { s: 40, moves: 8 }, HINT_AGAIN = { s: 30, moves: 6 }, gate = { acc: 0, t0: 0, base: 0, need: HINT_FIRST, timer: 0 };
  function gateSeconds() { return gate.acc + (gate.t0 ? (now() - gate.t0) / 1000 : 0); }
  function gateReset(need) { gate.acc = 0; gate.t0 = document.hidden ? 0 : now(); gate.base = history.length; gate.need = need; clearInterval(gate.timer); gate.timer = setInterval(gateTick, 250); gateTick(); }
  function hintMode() { return window.OPZ ? OPZ.get('aiuto') : 'attesa'; }
  function gateProgress() { if (hintMode() === 'subito') return 1; if (hintMode() === 'mai') return 0; return Math.max(Math.min(1, gateSeconds() / gate.need.s), Math.min(1, Math.max(0, history.length - gate.base) / gate.need.moves)); }
  function gateTick() {
    var p = gateProgress(), btn = $('btnHint'), show = !won && hintMode() === 'attesa' && p < 1;
    btn.hidden = hintMode() === 'mai'; btn.disabled = won || p < 1; btn.classList.toggle('waiting', show);
    if (show) $('ringFill').setAttribute('stroke-dashoffset', (188.5 * (1 - p)).toFixed(1)); else { clearInterval(gate.timer); gate.timer = 0; }
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden) { gate.acc = gateSeconds(); gate.t0 = 0; } else if (!gate.t0) gate.t0 = now(); });
  function clearHint() { if (hintG) hintG.innerHTML = ''; }
  function hint() {
    if (won || busy || gateProgress() < 1) return;
    clearHint(); settle();
    var sol = TB.solve(tubes, K, 1, 15000) || TB.solve(tubes, K, 2, 60000) || TB.solve(tubes, K, 4, 200000);
    if (!sol || !sol.length) return;
    gateReset(HINT_AGAIN);
    var m = sol[0], xa = cx(m.from), xb = cx(m.to), ya = slotY(tubes[m.from].length - 1), yb = slotY(tubes[m.to].length), top = liftY() - 6, mid = (xa + xb) / 2, dir = xb > xa ? 1 : -1;
    hintG.innerHTML = '<circle class="ring2" cx="' + xa + '" cy="' + ya + '" r="' + (R + 11) + '"/><circle class="ring2" cx="' + xb + '" cy="' + yb + '" r="' + (R + 11) + '"/>' +
      '<g class="arrowG"><path d="M' + xa + ' ' + top + 'Q' + mid + ' ' + (top - 96) + ' ' + xb + ' ' + top + '" fill="none" stroke="#FF8A3D" stroke-width="10" stroke-linecap="round"/>' +
      '<path d="M' + (xb - dir * 30) + ' ' + (top - 30) + 'L' + xb + ' ' + top + 'L' + (xb - dir * 34) + ' ' + (top + 8) + '" fill="none" stroke="#FF8A3D" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/></g>';
    var c = tubes[m.from][tubes[m.from].length - 1];
    setStatus('Sposta la pallina ' + NAME[c] + ' dal ' + ORD[m.from] + ' al ' + ORD[m.to] + ' barattolo.' + (sol.length > 1 ? ' Da qui mancano ' + sol.length + ' mosse.' : ''));
  }

  /* ---------- winning ---------- */
  function win() {
    won = true; clearInterval(gate.timer); gate.timer = 0; clearHint();
    var moves = history.length, prev = data.best[level + 1];
    if (!prev || moves < prev) data.best[level + 1] = moves;
    data.last = Math.min(RAW.length - 1, level + 1); persist(); updateStats();
    els.forEach(function (col, ti) { col.forEach(function (el, j) { el.style.setProperty('--pd', (ti * 0.09 + j * 0.05).toFixed(2) + 's'); el.classList.remove('land'); el.classList.add('party'); }); if (col.length) setTimeout(function () { sparkle(cx(ti), TOP - 50); }, 120 * ti); });
    var perfect = moves <= minMoves, text;
    sfx(perfect ? 'perfect' : 'win'); buzz(perfect ? [12, 60, 18, 60, 22] : [12, 60, 18]); confetti();
    if (perfect) text = 'Risolto in ' + moves + ' mosse: meno di così non si può.';
    else if (!prev || moves < prev) text = 'Risolto in ' + moves + ' mosse' + (prev ? ', nuovo record' : '') + '. Il minimo è ' + minMoves + '.';
    else text = 'Risolto in ' + moves + ' mosse. Il tuo record è ' + prev + ', il minimo è ' + minMoves + '.';
    var last = level >= RAW.length - 1;
    $('resPerfect').hidden = !perfect; $('resText').textContent = text + (last ? " Era l'ultimo livello." : '');
    $('btnNext').textContent = last ? 'Scegli un livello' : 'Livello successivo';
    statusDefault = false; statusEl.textContent = '';
    setTimeout(function () { if (won) { result.hidden = false; void result.offsetWidth; result.classList.add('show'); controls.style.visibility = 'hidden'; } }, calm ? 200 : 1250);
  }
  function hideResult() { result.classList.remove('show'); result.hidden = true; controls.style.visibility = ''; }

  /* ---------- level sheet ---------- */
  function openDlg(d) { if (d.showModal) { if (!d.open) d.showModal(); } else d.setAttribute('open', ''); }
  function closeDlg(d) { if (d.close) { if (d.open) d.close(); } else d.removeAttribute('open'); }
  function buildSheet() {
    var html = '';
    TIERS.forEach(function (t, ti) {
      var from = ti * PER_TIER, to = Math.min(RAW.length, from + PER_TIER); if (from >= RAW.length) return;
      html += '<section class="tier" style="--tier:' + t.color + ';--tier-ink:' + INK + '"><h3><i></i>' + t.name + '<small>' + (from + 1) + '–' + to + '</small><em data-count="' + ti + '"></em></h3><div class="cells">';
      for (var i = from; i < to; i++) html += '<button class="lv" type="button" data-level="' + i + '">' + (i + 1) + '</button>';
      html += '</div></section>';
    });
    html += '<section class="rules"><h3>Come si gioca</h3><ul><li>Ogni barattolo deve finire con palline di un solo colore.</li><li>Si sposta una pallina alla volta, quella in cima: toccala e poi tocca il barattolo di arrivo, oppure trascinala.</li><li>Una pallina entra in qualsiasi barattolo che abbia ancora posto.</li><li>Ogni spostamento conta una mossa.</li></ul></section>';
    $('sheetBody').innerHTML = html;
    $('sheetBody').addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('.lv') : null; if (!b) return; loadLevel(+b.getAttribute('data-level')); closeDlg(sheet); });
  }
  function refreshSheet() {
    var counts = TIERS.map(function () { return 0; }), perfect = 0;
    Array.prototype.forEach.call(sheet.querySelectorAll('.lv'), function (b) {
      var i = +b.getAttribute('data-level'), mine = data.best[i + 1], min = +RAW[i].split('|')[2], label = 'Livello ' + (i + 1);
      b.classList.toggle('done', !!mine); b.classList.toggle('perfect', !!mine && mine <= min); b.classList.toggle('current', i === level);
      if (mine) { counts[Math.floor(i / PER_TIER)]++; label += mine <= min ? ', risolto con il minimo di mosse' : ', risolto in ' + mine + ' mosse'; if (mine <= min) perfect++; }
      b.setAttribute('aria-label', label);
    });
    Array.prototype.forEach.call(sheet.querySelectorAll('[data-count]'), function (el) { var ti = +el.getAttribute('data-count'); el.textContent = counts[ti] + ' su ' + Math.min(PER_TIER, RAW.length - ti * PER_TIER); });
    var n = solvedCount();
    $('sheetSummary').textContent = n === 0 ? 'Scegli da quale livello partire: sono tutti aperti.' : n + ' di ' + RAW.length + ' risolti, ' + perfect + ' con il minimo di mosse.';
  }
  function openSheet() { refreshSheet(); openDlg(sheet); var cur = sheet.querySelector('.lv.current'); if (cur) { try { cur.scrollIntoView({ block: 'center' }); } catch (e) {} } }

  $('btnUndo').addEventListener('click', undo);
  $('btnReset').addEventListener('click', restart);
  $('btnHint').addEventListener('click', hint);
  $('btnLevels').addEventListener('click', openSheet);
  $('btnCloseSheet').addEventListener('click', function () { closeDlg(sheet); });
  $('btnAgain').addEventListener('click', function () { loadLevel(level); });
  $('btnNext').addEventListener('click', function () { if (level >= RAW.length - 1) { hideResult(); openSheet(); } else loadLevel(level + 1); });
  buildSheet(); loadLevel(Math.min(data.last, RAW.length - 1));
})();
