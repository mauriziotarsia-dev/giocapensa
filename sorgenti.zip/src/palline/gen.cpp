// Level pools for the ball-sorting game. Rule: move the top ball of a tube onto any tube
// that still has room. Sorted = every tube is empty or full of one colour (capacity = balls per colour).
// Exact minimum number of moves by A* (admissible + consistent heuristic) over canonical states.
#include <bits/stdc++.h>
using namespace std;
typedef uint64_t u64;

static int C, K, T;                       // colours, balls per colour (= tube capacity), tubes
static std::mt19937_64 rng(7);

static inline int cnt(uint16_t t) { int n = 0; while (t) { n++; t >>= 3; } return n; }
static inline int topc(uint16_t t, int n) { return (t >> (3 * (n - 1))) & 7; }
static u64 pack(array<uint16_t, 6> a) { sort(a.begin(), a.begin() + T); u64 s = 0; for (int i = 0; i < T; i++) s |= (u64)a[i] << (12 * i); return s; }
static array<uint16_t, 6> unpack(u64 s) { array<uint16_t, 6> a{}; for (int i = 0; i < T; i++) a[i] = (s >> (12 * i)) & 0xFFF; return a; }

static bool solved(const array<uint16_t, 6>& a) {
  for (int i = 0; i < T; i++) { int n = cnt(a[i]); if (!n) continue; if (n != K) return false; int c0 = a[i] & 7; for (int j = 1; j < n; j++) if (((a[i] >> (3 * j)) & 7) != c0) return false; }
  return true;
}
// balls that can stay where they are: for each colour, its longest bottom run in one tube
static int heur(const array<uint16_t, 6>& a) {
  int best[8] = {0};
  for (int i = 0; i < T; i++) { int n = cnt(a[i]); if (!n) continue; int c0 = a[i] & 7, run = 1; while (run < n && ((a[i] >> (3 * run)) & 7) == c0) run++; best[c0] = max(best[c0], run); }
  int keep = 0; for (int c = 1; c <= C; c++) keep += best[c];
  return C * K - keep;
}

static int astar(u64 start, long cap) {
  auto a0 = unpack(start); if (solved(a0)) return 0;
  unordered_map<u64, uint8_t> g; g.reserve(1 << 16);
  vector<vector<u64>> bucket(96);
  g[start] = 0; bucket[heur(a0)].push_back(start);
  long expanded = 0;
  for (int f = 0; f < 96; f++) {
    for (size_t idx = 0; idx < bucket[f].size(); idx++) {
      u64 s = bucket[f][idx]; auto a = unpack(s); int gs = g[s];
      if (gs + heur(a) != f) continue;                       // stale entry
      if (solved(a)) return gs;
      if (++expanded > cap) return -1;
      for (int i = 0; i < T; i++) {
        int ni = cnt(a[i]); if (!ni) continue;
        if (i && a[i] == a[i - 1]) continue;                 // identical source tubes give identical children
        int col = topc(a[i], ni);
        bool triedEmpty = false;
        for (int j = 0; j < T; j++) {
          if (j == i) continue; int nj = cnt(a[j]); if (nj >= K) continue;
          if (!nj) { if (triedEmpty || ni == 1) continue; triedEmpty = true; }
          auto b = a; b[i] = a[i] & ((1 << (3 * (ni - 1))) - 1); b[j] = a[j] | (uint16_t)(col << (3 * nj));
          u64 ns = pack(b); int ng = gs + 1; auto it = g.find(ns);
          if (it != g.end() && it->second <= ng) continue;
          g[ns] = (uint8_t)ng; int nf = ng + heur(b); if (nf < 96) bucket[nf].push_back(ns);
        }
      }
    }
  }
  return -1;
}

int main(int argc, char** argv) {
  C = atoi(argv[1]); K = atoi(argv[2]); T = C + 1; int want = atoi(argv[3]); long cap = argc > 4 ? atol(argv[4]) : 3000000; double seconds = argc > 5 ? atof(argv[5]) : 60;
  auto t0 = chrono::steady_clock::now();
  set<string> seen; int made = 0, tries = 0;
  while (made < want && chrono::duration<double>(chrono::steady_clock::now() - t0).count() < seconds && tries < want * 60) {
    tries++;
    vector<int> balls; for (int c = 1; c <= C; c++) for (int k = 0; k < K; k++) balls.push_back(c);
    shuffle(balls.begin(), balls.end(), rng);
    vector<int> sizes(T, 0);
    if (rng() % 10 < 7) { for (int i = 0; i < C; i++) sizes[i] = K; }                    // the classic look: full tubes and one empty
    else { int left = C * K; while (left) { int i = rng() % T; if (sizes[i] < K) { sizes[i]++; left--; } } }
    shuffle(sizes.begin(), sizes.end(), rng);
    array<uint16_t, 6> a{}; int p = 0; vector<string> tubes(T);
    for (int i = 0; i < T; i++) for (int k = 0; k < sizes[i]; k++) { a[i] |= (uint16_t)(balls[p] << (3 * k)); tubes[i] += char('0' + balls[p]); p++; }
    if (solved(a)) continue;
    // same puzzle up to renaming colours and swapping tubes?
    { vector<string> tt = tubes; map<char, char> ren; char nxt = 'a'; vector<string> canon;
      vector<string> srt = tt; sort(srt.begin(), srt.end(), [](const string& x, const string& y) { return x.size() != y.size() ? x.size() > y.size() : x < y; });
      for (auto& s : srt) { string o; for (char ch : s) { if (!ren.count(ch)) ren[ch] = nxt++; o += ren[ch]; } canon.push_back(o); }
      sort(canon.begin(), canon.end()); string key; for (auto& s : canon) key += s + "/"; if (!seen.insert(key).second) continue; }
    int m = astar(pack(a), cap); if (m < 2) continue;
    string line; for (int i = 0; i < T; i++) { if (i) line += ","; line += tubes[i]; }
    printf("%d %d %d %s\n", C, K, m, line.c_str()); fflush(stdout); made++;
  }
  fprintf(stderr, "C=%d K=%d made=%d tries=%d\n", C, K, made, tries);
  return 0;
}
