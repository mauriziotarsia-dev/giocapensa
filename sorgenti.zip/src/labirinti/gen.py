#!/usr/bin/env python3
"""Maze levels: perfect mazes (plus a few loops at the top), stars to collect, a key and a gate. Minimum steps by BFS over (cell, stars, key)."""
import json, random
from collections import deque
random.seed(11)
DX, DY, OPP = [0, 1, 0, -1], [-1, 0, 1, 0], [2, 3, 0, 1]          # N E S W

def maze(w, h, loops):
    m = [0] * (w * h); seen = [False] * (w * h); st = [random.randrange(w * h)]; seen[st[0]] = True
    while st:
        c = st[-1]; x, y = c % w, c // w
        opts = [d for d in range(4) if 0 <= x + DX[d] < w and 0 <= y + DY[d] < h and not seen[(y + DY[d]) * w + x + DX[d]]]
        if not opts: st.pop(); continue
        d = random.choice(opts); n = (y + DY[d]) * w + x + DX[d]; m[c] |= 1 << d; m[n] |= 1 << OPP[d]; seen[n] = True; st.append(n)
    for _ in range(loops):
        c = random.randrange(w * h); x, y = c % w, c // w; d = random.randrange(4)
        if 0 <= x + DX[d] < w and 0 <= y + DY[d] < h: n = (y + DY[d]) * w + x + DX[d]; m[c] |= 1 << d; m[n] |= 1 << OPP[d]
    return m

def dist(w, h, m, s, door=None):
    D = {s: 0}; q = deque([s])
    while q:
        c = q.popleft(); x, y = c % w, c // w
        for d in range(4):
            if not m[c] >> d & 1: continue
            n = (y + DY[d]) * w + x + DX[d]
            if door and (door == (c, d) or door == (n, OPP[d])): continue
            if n not in D: D[n] = D[c] + 1; q.append(n)
    return D

def solve(w, h, m, s, e, stars, key, door):
    full = (1 << len(stars)) - 1; sidx = {c: i for i, c in enumerate(stars)}
    start = (s, 0, 0); D = {start: 0}; q = deque([start])
    while q:
        c, mask, k = st = q.popleft()
        if c == e and mask == full: return D[st]
        x, y = c % w, c // w
        for d in range(4):
            if not m[c] >> d & 1: continue
            n = (y + DY[d]) * w + x + DX[d]
            if door and not k and (door == (c, d) or door == (n, OPP[d])): continue
            ns = (n, mask | (1 << sidx[n]) if n in sidx else mask, 1 if n == key else k)
            if ns not in D: D[ns] = D[st] + 1; q.append(ns)
    return None

def level(w, h, nstars, use_door, loops):
    for _ in range(400):
        m = maze(w, h, loops)
        s = random.choice([0, w - 1, (h - 1) * w, h * w - 1]); D = dist(w, h, m, s); e = max(D, key=D.get)
        dead = [c for c in range(w * h) if bin(m[c]).count('1') == 1 and c not in (s, e)]
        key, door = -1, None
        if use_door:
            path = [e]                                              # walk back from the exit along decreasing distance
            while path[-1] != s:
                c = path[-1]; x, y = c % w, c // w
                path.append(next((y + DY[d]) * w + x + DX[d] for d in range(4) if m[c] >> d & 1 and D.get((y + DY[d]) * w + x + DX[d], 1e9) == D[c] - 1))
            path.reverse(); i = random.randint(int(len(path) * .45), max(int(len(path) * .45), int(len(path) * .8) - 1))
            a, b = path[i], path[i + 1]; d = next(d for d in range(4) if (a // w + DY[d]) * w + a % w + DX[d] == b and 0 <= a % w + DX[d] < w)
            door = (a, d); near = dist(w, h, m, s, door)
            if e in near: continue                                   # a loop goes round the gate
            cand = [c for c in dead if c in near and c not in path]
            if not cand: continue
            key = max(cand, key=lambda c: near[c] + random.random())
        pool = [c for c in dead if c != key]; random.shuffle(pool)
        if len(pool) < nstars: continue
        stars = pool[:nstars]
        mn = solve(w, h, m, s, e, stars, key, door)
        if mn is None: continue
        if (nstars or use_door) and mn < D[e] + 4: continue            # the extras must really cost a detour
        return {'w': w, 'h': h, 'c': ''.join('%x' % v for v in m), 's': s, 'e': e, 'st': stars, 'k': key, 'd': list(door) if door else None, 'm': mn}
    raise SystemExit('no level for %s' % ((w, h, nstars, use_door, loops),))

plan = [  # (w, h, stars, gate, loops) x how many, tier by tier
    [((4, 4, 0, False, 0), 8), ((4, 5, 0, False, 0), 8), ((5, 5, 0, False, 0), 8)],
    [((5, 6, 0, False, 0), 12), ((6, 7, 0, False, 0), 12)],
    [((5, 6, 2, False, 0), 8), ((6, 7, 2, False, 0), 8), ((6, 7, 3, False, 0), 8)],
    [((6, 7, 0, True, 0), 8), ((7, 8, 0, True, 0), 8), ((7, 8, 1, True, 0), 8)],
    [((7, 8, 2, True, 2), 8), ((8, 9, 2, True, 3), 8), ((8, 10, 3, True, 4), 8)],
]
out = []
for tier in plan:
    lv = [level(*cfg) for cfg, n in tier for _ in range(n * 3)]      # make three times as many, keep a graded third
    lv.sort(key=lambda L: (L['w'] * L['h'], L['m'])); out += lv[1::3]
json.dump(out, open('levels.json', 'w'), separators=(',', ':'))
for t in range(5): print('fascia', t + 1, 'passi minimi:', ' '.join(str(L['m']) for L in out[t * 24:(t + 1) * 24]))
