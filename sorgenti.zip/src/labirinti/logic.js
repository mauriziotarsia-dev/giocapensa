/* Maze rules and shortest-walk solver (no DOM). Sides: 0 N, 1 E, 2 S, 3 W; a cell's digit lists its open sides as bits. */
(function (root) {
  'use strict';
  var DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0], OPP = [2, 3, 0, 1];
  function parse(L) { return { w: L.w, h: L.h, m: L.c.split('').map(function (ch) { return parseInt(ch, 16); }), s: L.s, e: L.e, stars: L.st, key: L.k, door: L.d, min: L.m }; }
  function nb(G, c, d) { return c + DX[d] + DY[d] * G.w; }
  function blocked(G, c, d, hasKey) {
    if (!(G.m[c] >> d & 1)) return true;
    if (G.door && !hasKey) { var n = nb(G, c, d); if ((G.door[0] === c && G.door[1] === d) || (G.door[0] === n && G.door[1] === OPP[d])) return true; }
    return false;
  }
  function pick(G, st, n) { var i = G.stars.indexOf(n); return { c: n, mask: i >= 0 ? st.mask | (1 << i) : st.mask, key: st.key || n === G.key ? 1 : 0 }; }
  function id(G, st) { return ((st.c * 2 + st.key) << G.stars.length) | st.mask; }
  // shortest walk from a state to the house with every star collected: list of cells to step on
  function solve(G, from) {
    var full = (1 << G.stars.length) - 1, q = [from], prev = {}, head = 0, st, d, n, ns, key;
    prev[id(G, from)] = null;
    while (head < q.length) {
      st = q[head++];
      if (st.c === G.e && st.mask === full) { var out = []; for (var s = st; prev[id(G, s)]; s = prev[id(G, s)]) out.push(s.c); return out.reverse(); }
      for (d = 0; d < 4; d++) { if (blocked(G, st.c, d, st.key)) continue; n = nb(G, st.c, d); ns = pick(G, st, n); key = id(G, ns); if (prev[key] === undefined) { prev[key] = st; q.push(ns); } }
    }
    return null;
  }
  // short walk towards the finger: plain shortest path between two cells, at most `limit` steps
  function route(G, a, b, hasKey, limit) {
    if (a === b) return [];
    var q = [a], prev = {}, dist = {}, head = 0, c, d, n; prev[a] = -1; dist[a] = 0;
    while (head < q.length) {
      c = q[head++]; if (dist[c] >= limit) continue;
      for (d = 0; d < 4; d++) { if (blocked(G, c, d, hasKey)) continue; n = nb(G, c, d); if (prev[n] !== undefined) continue; prev[n] = c; dist[n] = dist[c] + 1; if (n === b) { var out = []; for (var s = b; s !== a; s = prev[s]) out.push(s); return out.reverse(); } q.push(n); }
    }
    return null;
  }
  root.LB = { parse: parse, nb: nb, blocked: blocked, pick: pick, solve: solve, route: route, DX: DX, DY: DY };
})(typeof window !== 'undefined' ? window : globalThis);
