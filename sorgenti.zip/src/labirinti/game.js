(function () {
  'use strict';
  var RAW = window.GAME_LEVELS, LB = window.LB, K = window.Kit, INK = K.INK, scene = document.getElementById('scene');
  var G, st, hist, walking = false, PAD = 44, C = 100, W, H, chr, trailG, itemsG, hintG, fxG, lastAim = -1, down = false;
  function cx(c) { return PAD + (c % G.w) * C + C / 2; } function cy(c) { return PAD + Math.floor(c / G.w) * C + C / 2; }
  function dot(x, y, r, f, cls) { return '<circle' + (cls ? ' class="' + cls + '"' : '') + ' cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + (f || INK) + '"/>'; }

  function defs() {
    return '<defs><radialGradient id="gGrass" cx="50%" cy="38%" r="80%"><stop offset="0" stop-color="#D4EFB2"/><stop offset="1" stop-color="#9BD07E"/></radialGradient>' +
      '<linearGradient id="gSand" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF4D9"/><stop offset="1" stop-color="#F0DAA6"/></linearGradient>' +
      '<radialGradient id="gGlow"><stop offset="0" stop-color="#FFF2A0" stop-opacity=".95"/><stop offset=".5" stop-color="#FFD95A" stop-opacity=".4"/><stop offset="1" stop-color="#FFD95A" stop-opacity="0"/></radialGradient>' +
      '<radialGradient id="gHint"><stop offset="0" stop-color="#FF8A3D"/><stop offset=".45" stop-color="#FF8A3D" stop-opacity=".55"/><stop offset="1" stop-color="#FF8A3D" stop-opacity="0"/></radialGradient>' +
      '<linearGradient id="gWall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFFBEF"/><stop offset="1" stop-color="#F3E2BD"/></linearGradient>' +
      '<linearGradient id="gRoof" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF8F86"/><stop offset="1" stop-color="#DB4F55"/></linearGradient>' +
      '<linearGradient id="gGold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF0A3"/><stop offset=".5" stop-color="#FFD24A"/><stop offset="1" stop-color="#E0A51E"/></linearGradient>' +
      '<linearGradient id="gWood" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#D9A06C"/><stop offset="1" stop-color="#A9713F"/></linearGradient>' +
      '<radialGradient id="gDino" cx="45%" cy="25%" r="85%"><stop offset="0" stop-color="#86D98C"/><stop offset="1" stop-color="#4DAE5B"/></radialGradient>' +
      '<linearGradient id="gRock" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C9C3BC"/><stop offset="1" stop-color="#8F8890"/></linearGradient></defs>';
  }
  function hedgeBit(x, y, i) {                                  // what grows on the hedges: mushrooms, blueberries, a few daisies
    if (i % 3 === 0) return '<g class="hfl" style="--d:' + (-(i % 5) * 0.6) + 's"><rect x="' + (x - 3.5) + '" y="' + (y - 1) + '" width="7" height="9" rx="3" fill="#FFF4D9" stroke="' + INK + '" stroke-width="1.6"/><path d="M' + (x - 10) + ' ' + y + 'a10 9 0 0 1 20 0Z" fill="#EE5E4D" stroke="' + INK + '" stroke-width="1.8" stroke-linejoin="round"/>' + dot(x - 4, y - 4, 1.7, '#fff') + dot(x + 3.5, y - 5.5, 1.5, '#fff') + '</g>';
    if (i % 3 === 1) return '<g class="hfl" style="--d:' + (-(i % 5) * 0.6) + 's">' + [[-5, 2], [5, 2], [0, -5]].map(function (o) { return '<circle cx="' + (x + o[0]) + '" cy="' + (y + o[1]) + '" r="5" fill="#4C6FD8" stroke="' + INK + '" stroke-width="1.6"/>' + dot(x + o[0] - 1.5, y + o[1] - 1.5, 1.3, '#BFD0FF'); }).join('') + '</g>';
    return tinyFlower(x, y, '#fff', -(i % 5) * 0.6);
  }
  function tinyFlower(x, y, col, d) {
    var s = '<g class="hfl" style="--d:' + d + 's">', i, a;
    for (i = 0; i < 5; i++) { a = i * 1.2566; s += '<circle cx="' + (x + 6.5 * Math.cos(a)).toFixed(1) + '" cy="' + (y + 6.5 * Math.sin(a)).toFixed(1) + '" r="5" fill="' + col + '" stroke="' + INK + '" stroke-width="1.6"/>'; }
    return s + '<circle cx="' + x + '" cy="' + y + '" r="3.6" fill="#FFD95A"/></g>';
  }
  function backdrop() {
    var s = '<rect x="-3000" y="-3000" width="9000" height="9000" fill="url(#gGrass)"/>', i, x, y;
    for (i = 0; i < 46; i++) {                                                    // tufts and wild flowers all around the garden
      x = ((i * 197) % (W + 700)) - 350; y = ((i * 131) % (H + 700)) - 350;
      if (x > PAD - 30 && x < W - PAD + 30 && y > PAD - 30 && y < H - PAD + 30) continue;
      s += i % 3 ? '<path d="M' + x + ' ' + y + 'l5 -15l5 15l6 -11l3 11" fill="none" stroke="#7DBB63" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>' : tinyFlower(x, y, ['#fff', '#FFE98A', '#BFE0FF'][i % 3 === 0 ? (i / 3) % 3 | 0 : 0], -(i % 7) * 0.4);
    }
    s += '<g class="drift" style="--bt:52s"><ellipse cx="0" cy="' + (H * 0.3) + '" rx="' + (W * 0.34) + '" ry="' + (H * 0.12) + '" fill="#2F5E2A" opacity=".07"/></g><g class="drift" style="--bt:67s;--bd:-31s"><ellipse cx="0" cy="' + (H * 0.74) + '" rx="' + (W * 0.28) + '" ry="' + (H * 0.1) + '" fill="#2F5E2A" opacity=".06"/></g>';
    var px = PAD + 110, py = -92, sx = W - PAD - 70;                                // outside the hedges: a pond with a frog, a signpost, stones
    s += '<ellipse cx="' + px + '" cy="' + (py + 8) + '" rx="112" ry="52" fill="#3E5F2E" opacity=".2"/><ellipse cx="' + px + '" cy="' + py + '" rx="110" ry="50" fill="#8FD3F4"' + K.k(5) + '/><ellipse class="pond" cx="' + (px - 30) + '" cy="' + (py - 8) + '" rx="34" ry="12" fill="none" stroke="#fff" stroke-width="4" opacity=".7"/><ellipse class="pond" style="--d:-1.3s" cx="' + (px + 40) + '" cy="' + (py + 14) + '" rx="26" ry="9" fill="none" stroke="#fff" stroke-width="4" opacity=".7"/>' +
      '<path d="M' + (px + 44) + ' ' + (py - 14) + 'a22 14 0 1 1 -8 -9l-12 10Z" fill="#6CC070"' + K.k(3.5) + '/>' +
      '<g class="frog"><ellipse cx="' + (px - 48) + '" cy="' + (py + 12) + '" rx="22" ry="15" fill="#7CCB78"' + K.k(4) + '/><circle cx="' + (px - 58) + '" cy="' + (py - 2) + '" r="7.500" fill="#7CCB78"' + K.k(3.5) + '/><circle cx="' + (px - 38) + '" cy="' + (py - 2) + '" r="7.500" fill="#7CCB78"' + K.k(3.5) + '/><g class="blink">' + dot(px - 58, py - 2, 3) + dot(px - 38, py - 2, 3) + '</g><path d="M' + (px - 58) + ' ' + (py + 15) + 'q10 7 20 0" fill="none"' + K.k(3) + '/></g>';
    s += '<rect x="' + (sx - 5) + '" y="-96" width="10" height="84" rx="4" fill="url(#gWood)"' + K.k(4) + '/><path d="M' + (sx - 52) + ' -92h84l22 19l-22 19h-84Z" fill="url(#gWood)"' + K.k(4.5) + '/><path d="M' + (sx - 32) + ' -73h52m-16 -11l16 11l-16 11" fill="none" stroke="#FFF4D9" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>';
    for (i = 0; i < 5; i++) s += '<ellipse cx="' + (PAD + 60 + i * ((W - 2 * PAD - 120) / 4)) + '" cy="' + (H + 58 + (i % 2) * 26) + '" rx="' + (26 + (i * 7) % 12) + '" ry="' + (16 + (i * 5) % 7) + '" fill="#C9C3BC"' + K.k(4) + '/><ellipse cx="' + (PAD + 52 + i * ((W - 2 * PAD - 120) / 4)) + '" cy="' + (H + 52 + (i % 2) * 26) + '" rx="9" ry="5" fill="#fff" opacity=".5"/>';
    // the sandy floor, with a soft shadow and stepping stones
    s += '<rect x="' + (PAD - 2) + '" y="' + (PAD + 8) + '" width="' + (G.w * C + 16) + '" height="' + (G.h * C + 12) + '" rx="30" fill="#3E5F2E" opacity=".25"/>';
    s += '<rect x="' + (PAD - 8) + '" y="' + (PAD - 8) + '" width="' + (G.w * C + 16) + '" height="' + (G.h * C + 16) + '" rx="28" fill="url(#gSand)"/>';
    for (i = 0; i < G.w * G.h; i++) {
      x = cx(i); y = cy(i);
      s += '<ellipse cx="' + (x + ((i * 37) % 30 - 15)) + '" cy="' + (y + ((i * 53) % 26 - 9)) + '" rx="' + (19 + (i * 7) % 9) + '" ry="' + (12 + (i * 5) % 6) + '" fill="#E9D3A0" opacity=".7"/>' +
        '<ellipse cx="' + (x + ((i * 71) % 44 - 22)) + '" cy="' + (y + ((i * 29) % 40 - 26)) + '" rx="9" ry="6" fill="#FFF8E6" opacity=".9"/>' + dot(x + ((i * 91) % 60 - 30), y + ((i * 17) % 50 - 20), 3.5, '#DCC48E');
    }
    return s;
  }
  function walls() {
    var d = '', segs = [], c, x, y, s, i;
    function seg(x1, y1, x2, y2) { d += 'M' + x1 + ' ' + y1 + 'L' + x2 + ' ' + y2; segs.push([(x1 + x2) / 2, (y1 + y2) / 2]); }
    for (c = 0; c < G.w * G.h; c++) {
      x = PAD + (c % G.w) * C; y = PAD + Math.floor(c / G.w) * C;
      if (!(G.m[c] & 1)) seg(x, y, x + C, y);
      if (!(G.m[c] & 8)) seg(x, y, x, y + C);
      if (c % G.w === G.w - 1) seg(x + C, y, x + C, y + C);
      if (Math.floor(c / G.w) === G.h - 1) seg(x, y + C, x + C, y + C);
    }
    function st(col, w, extra) { return '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round" stroke-linejoin="round"' + (extra || '') + '/>'; }
    s = st('#3E5F2E', 34, ' opacity=".28" transform="translate(6,10)"') + st(INK, 33) + st('#4FA052', 24) + st('#7CC872', 17, ' transform="translate(-1,-3)"') +
      st('#B7EBA9', 6, ' stroke-dasharray="1 19" transform="translate(-5,-7)"') + st('#C9F2BC', 5, ' stroke-dasharray="1 27" stroke-dashoffset="11" transform="translate(3,-5)"') + st('#3F8A45', 6, ' stroke-dasharray="1 23" stroke-dashoffset="7" transform="translate(5,6)"');
    var bits = 0; for (i = 0; i < segs.length; i++) if ((i * 7 + G.w) % 6 === 0) s += hedgeBit(segs[i][0] + ((i % 3) - 1) * 14, segs[i][1] - 4, bits++);   // mushroom, berries, daisy, in turn
    return s;
  }
  function house(c) {                                           // the way home: a cave, closed by a boulder until every star is collected
    var x = cx(c), y = cy(c) + 2;
    return '<g class="house" id="house"><ellipse cx="' + x + '" cy="' + (y + 38) + '" rx="50" ry="9" fill="#3E5F2E" opacity=".25"/>' +
      '<path d="M' + (x - 48) + ' ' + (y + 38) + 'q-8 -52 20 -70q28 -18 54 4q26 20 22 66Z" fill="url(#gRock)"' + K.k(5) + '/>' +
      '<path d="M' + (x - 30) + ' ' + (y - 24) + 'q12 -14 30 -12q-14 4 -22 16Z" fill="#fff" opacity=".35"/><path d="M' + (x + 26) + ' ' + (y - 8) + 'l8 12l-5 10M' + (x - 36) + ' ' + (y + 6) + 'l-5 12" fill="none" stroke="#6B6470" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="M' + (x - 16) + ' ' + (y - 40) + 'q14 -12 32 -2q-4 10 -18 8t-14 -6Z" fill="#7CC872"' + K.k(3.5) + '/>' +
      '<path d="M' + (x - 22) + ' ' + (y + 38) + 'v-24a22 22 0 0 1 44 0v24Z" fill="#2A2430"' + K.k(4.5) + '/><ellipse class="winlight" cx="' + x + '" cy="' + (y + 30) + '" rx="15" ry="9" fill="#FFB347"/>' +
      '<g class="boulder"><circle cx="' + x + '" cy="' + (y + 19) + '" r="20" fill="#B9B2AA"' + K.k(4.5) + '/><path d="M' + (x - 9) + ' ' + (y + 8) + 'l7 8l-4 9M' + (x + 8) + ' ' + (y + 22) + 'l6 6" fill="none" stroke="#7C7580" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><ellipse cx="' + (x - 7) + '" cy="' + (y + 9) + '" rx="6" ry="3.5" fill="#fff" opacity=".5" transform="rotate(-30 ' + (x - 7) + ' ' + (y + 9) + ')"/></g>' +
      '<g transform="translate(' + (x + 40) + ',' + (y + 36) + ') rotate(-24)"><rect x="-11" y="-2.5" width="22" height="5" rx="2.5" fill="#FFF8E6"' + K.k(2.5) + '/>' + [[-11, -3], [-11, 3], [11, -3], [11, 3]].map(function (o) { return '<circle cx="' + o[0] + '" cy="' + o[1] + '" r="3.6" fill="#FFF8E6"' + K.k(2.5) + '/>'; }).join('') + '</g></g>';
  }
  function starArt(sc, n) {
    var x = cx(sc), y = cy(sc);
    return '<g class="item twk" data-star="' + n + '" style="--d:' + (-n * 0.6) + 's"><circle class="glow" style="--d:' + (-n * 0.5) + 's" cx="' + x + '" cy="' + y + '" r="46" fill="url(#gGlow)"/><g class="spinme">' + K.star(x, y, 28, 'url(#gGold)', 4.5) +
      dot(x - 8, y - 2, 3.4) + dot(x + 8, y - 2, 3.4) + '<path d="M' + (x - 6) + ' ' + (y + 6) + 'q6 6 12 0" fill="none"' + K.k(3) + '/><ellipse cx="' + (x - 9) + '" cy="' + (y - 12) + '" rx="6" ry="3.5" fill="#fff" opacity=".7" transform="rotate(-30 ' + (x - 9) + ' ' + (y - 12) + ')"/></g></g>';
  }
  function keyArt(c) {
    var x = cx(c), y = cy(c), sh = 'M' + (x + 2) + ' ' + y + 'h32M' + (x + 22) + ' ' + y + 'v14M' + (x + 33) + ' ' + y + 'v11';
    return '<g class="item bobk" id="key"><circle class="glow" cx="' + x + '" cy="' + y + '" r="44" fill="url(#gGlow)"/><path d="' + sh + '" fill="none"' + K.k(9) + '/><path d="' + sh + '" fill="none" stroke="#FFD24A" stroke-width="4" stroke-linecap="round"/>' +
      '<circle cx="' + (x - 14) + '" cy="' + y + '" r="16" fill="url(#gGold)"' + K.k(5) + '/>' + dot(x - 14, y, 6, '#FFF4D9') + '<circle cx="' + (x - 14) + '" cy="' + y + '" r="6" fill="none"' + K.k(3) + '/>' +
      '<path class="glint" d="M' + (x - 24) + ' ' + (y - 16) + 'l3 7 7 3-7 3-3 7-3-7-7-3 7-3Z" fill="#fff"/></g>';
  }
  function gateArt() {
    var c = G.door[0], d = G.door[1], x = cx(c) + LB.DX[d] * C / 2, y = cy(c) + LB.DY[d] * C / 2, hz = d === 0 || d === 2, s = '<g transform="translate(' + x + ',' + y + ') rotate(' + (hz ? 0 : 90) + ')"><g class="gate" id="gate">', i;
    for (i = 0; i < 5; i++) s += '<path d="M' + (-42 + i * 17) + ' 17v-27l8 -8l8 8v27Z" fill="url(#gWood)"' + K.k(3.5) + '/>';
    return s + '<rect x="-44" y="-6" width="88" height="8" rx="4" fill="#8A5A30"' + K.k(3) + '/><rect x="-44" y="8" width="88" height="7" rx="3.5" fill="#8A5A30"' + K.k(3) + '/><circle cx="0" cy="4" r="9" fill="url(#gGold)"' + K.k(3.5) + '/>' + dot(0, 3, 2.6) + '<path d="M0 4v5" stroke="' + INK + '" stroke-width="2.4" stroke-linecap="round"/></g></g>';
  }
  function teddy() {                                            // the hero is a little dinosaur, seen from the side
    return '<g class="chr" id="chr"><ellipse cx="0" cy="37" rx="30" ry="8" fill="#3E5F2E" opacity=".28"/><g class="flip"><g class="bi">' +
      '<g class="tailw"><path d="M-16 16q-26 6 -36 -14q14 10 36 0Z" fill="url(#gDino)"' + K.k(4.5) + '/></g>' +
      '<rect class="footL" x="-15" y="20" width="13" height="19" rx="6" fill="#3F9A4E"' + K.k(4) + '/><rect class="footR" x="5" y="20" width="13" height="19" rx="6" fill="#3F9A4E"' + K.k(4) + '/>' +
      '<path d="M-24 14q0 -24 24 -24q10 0 16 5q2 -26 20 -32q18 -3 19 11q0 12 -15 13q-3 22 -12 34q-8 10 -28 10q-24 0 -24 -17Z" fill="url(#gDino)"' + K.k(4.5) + '/>' +
      '<ellipse cx="2" cy="20" rx="15" ry="9" fill="#D6F2C9"/><path d="M-17 -5l5 -12l8 9ZM-3 -11l6 -13l8 11Z" fill="#F59A3A"' + K.k(3.5) + '/><ellipse cx="20" cy="9" rx="4.5" ry="7.5" fill="#3F9A4E"' + K.k(3) + ' transform="rotate(-30 20 9)"/>' +
      '<ellipse cx="33" cy="-40" rx="7" ry="4" fill="#fff" opacity=".35" transform="rotate(-20 33 -40)"/><g class="blink">' + dot(40, -31, 4.4) + dot(41.4, -32.4, 1.5, '#fff') + '</g>' + dot(50, -28, 1.8) + '<path d="M38 -19q8 4 15 -2" fill="none"' + K.k(3) + '/>' +
      '</g></g></g>';
  }
  function butterfly(col, bt, bd) { return '<g class="bfly" style="--bt:' + bt + 's;--bd:' + bd + 's"><g class="bwL"><path d="M0 0q-20 -24 -28 -6t28 6q-24 6 -18 20t18 -20Z" fill="' + col + '"' + K.k(2.5) + '/></g><g class="bwR"><path d="M0 0q20 -24 28 -6t-28 6q24 6 18 20t-18 -20Z" fill="' + col + '"' + K.k(2.5) + '/></g><rect x="-3" y="-10" width="6" height="24" rx="3" fill="' + INK + '"/></g>'; }
  function setChr(x, y) { chr._x = x; chr._y = y; chr.setAttribute('transform', 'translate(' + x.toFixed(1) + ',' + y.toFixed(1) + ')'); }

  function load(i) {
    G = LB.parse(RAW[i]); st = { c: G.s, mask: 0, key: 0 }; hist = []; way = []; if (raf) { cancelAnimationFrame(raf); raf = 0; } walking = false; lastAim = -1; down = false;
    W = G.w * C + PAD * 2; H = G.h * C + PAD * 2; scene.setAttribute('viewBox', '0 0 ' + W + ' ' + H); scene.style.setProperty('--scene-bg', '#B5DE98'); scene.style.setProperty('--w', W + 'px'); scene.style.setProperty('--h', H + 'px');
    var s = defs() + backdrop() + '<g class="world"><g id="trail"></g>' + walls() + '<g id="items">' + house(G.e);
    G.stars.forEach(function (sc, n) { s += starArt(sc, n); });
    if (G.key >= 0) s += keyArt(G.key); if (G.door) s += gateArt();
    scene.innerHTML = s + '</g><g id="hintG"></g>' + teddy() + '</g>' + butterfly('#7DB7F7', 23, -4) + butterfly('#F59A3A', 31, -17) + '<g id="fxG"></g>';
    chr = scene.querySelector('#chr'); trailG = scene.querySelector('#trail'); itemsG = scene.querySelector('#items'); hintG = scene.querySelector('#hintG'); fxG = scene.querySelector('#fxG');
    setChr(cx(G.s), cy(G.s)); refreshHouse();
    if (G.door && G.stars.length) return 'Prendi la chiave per aprire il cancello e raccogli tutte le stelle, poi vai alla grotta.';
    if (G.door) return 'La chiave apre il cancello: prendila, poi raggiungi la grotta.';
    if (G.stars.length) return 'Raccogli tutte le stelle: solo allora il masso libera la grotta.';
    return '';
  }
  function full() { return st.mask === (1 << G.stars.length) - 1; }
  function refreshHouse() { scene.querySelector('#house').classList.toggle('ready', full() && !K.isWon()); }        // the door swings open once every star is in the bag
  function refreshItems() {
    G.stars.forEach(function (sc, n) { var el = itemsG.querySelector('[data-star="' + n + '"]'); var got = !!(st.mask >> n & 1); if (!got) { el.classList.remove('got'); el.style.opacity = ''; } else if (!el.classList.contains('got')) el.style.opacity = '0'; });
    var key = itemsG.querySelector('#key'); if (key) { if (st.key) { if (!key.classList.contains('got')) key.style.opacity = '0'; } else { key.classList.remove('got'); key.style.opacity = ''; } }
    var gate = itemsG.querySelector('#gate'); if (gate) gate.classList.toggle('open', !!st.key);
    refreshHouse();
  }

  /* ---------- walking: the dinosaur follows the path the finger has traced, smoothly and at its own pace ---------- */
  var way = [], raf = 0, lastT = 0, SPEED = 520;
  function mid() { return Math.abs(chr._x - cx(st.c)) + Math.abs(chr._y - cy(st.c)) > 0.5; }
  function arrive(n) {                                           // the centre of a new cell: that is one step
    var prev = { c: st.c, mask: st.mask, key: st.key }, px = cx(prev.c), py = cy(prev.c), x1 = cx(n), y1 = cy(n);
    hist.push(prev); st = LB.pick(G, st, n);
    var ang = Math.atan2(y1 - py, x1 - px) * 180 / Math.PI + 90;
    trailG.insertAdjacentHTML('beforeend', '<g transform="translate(' + px + ',' + py + ') rotate(' + ang.toFixed(0) + ')" fill="#D6B87E"><ellipse cx="0" cy="6" rx="6.5" ry="8"/><ellipse cx="-9" cy="-6" rx="3.4" ry="6" transform="rotate(-24 -9 -6)"/><ellipse cx="0" cy="-10" rx="3.4" ry="6.5"/><ellipse cx="9" cy="-6" rx="3.4" ry="6" transform="rotate(24 9 -6)"/></g>');
    if (!K.calm) { fxG.insertAdjacentHTML('beforeend', '<circle class="dust" cx="' + px + '" cy="' + (py + 26) + '" r="11" fill="#F0DAA6"/>'); var du = fxG.lastElementChild; setTimeout(function () { if (du.parentNode) du.parentNode.removeChild(du); }, 520); }
    if (st.mask !== prev.mask) { itemsG.querySelector('[data-star="' + G.stars.indexOf(n) + '"]').classList.add('got'); K.sparkle(fxG, x1, y1, 13); K.sfx('star'); K.buzz(12); refreshHouse(); }
    else if (st.key !== prev.key) { itemsG.querySelector('#key').classList.add('got'); itemsG.querySelector('#gate').classList.add('open'); K.sfx('key'); K.buzz(12); }
    else K.sfx('step', hist.length);
    K.changed();
    if (st.c === G.e) {
      if (full()) { way = []; walking = false; chr.classList.remove('walk'); chr.classList.add('joy'); K.sparkle(fxG, x1, y1 - 20, 18); K.confetti(fxG, W, H); K.win(); return false; }
      var hs = scene.querySelector('#house'); hs.classList.remove('no'); void hs.getBoundingClientRect(); hs.classList.add('no'); K.sfx('bad'); K.status('Un masso chiude la grotta: mancano ancora delle stelle.');
    }
    return true;
  }
  function frame(t) {
    raf = 0; if (K.isWon()) return;
    var dt = lastT ? Math.min(48, t - lastT) : 16; lastT = t;
    var left = K.calm ? 1e9 : (SPEED + 70 * Math.min(way.length, 6)) * dt / 1000;        // a long trace ahead: hurry up a little
    while (left > 0 && way.length) {
      var wp = way[0], dx = cx(wp.c) - chr._x, dy = cy(wp.c) - chr._y, dist = Math.abs(dx) + Math.abs(dy);   // corridors run straight: one of the two is always zero
      if (Math.abs(dx) > 0.5) chr.querySelector('.flip').style.transform = dx < 0 ? 'scaleX(-1)' : '';
      if (dist <= left) { setChr(cx(wp.c), cy(wp.c)); left -= dist; way.shift(); if (wp.count && !arrive(wp.c)) return; }
      else { setChr(chr._x + (dx > 0 ? left : dx < 0 ? -left : 0), chr._y + (dy > 0 ? left : dy < 0 ? -left : 0)); left = 0; }
    }
    if (way.length) raf = requestAnimationFrame(frame); else { walking = false; lastT = 0; chr.classList.remove('walk'); K.changed(); }
  }
  function go() { if (way.length && !raf) { walking = true; chr.classList.add('walk'); lastT = 0; raf = requestAnimationFrame(frame); K.changed(); } }
  function cellAt(x, y) {
    var b = scene.getBoundingClientRect(), s = Math.min(b.width / W, b.height / H), px = (x - b.left - (b.width - W * s) / 2) / s - PAD, py = (y - b.top - (b.height - H * s) / 2) / s - PAD;
    var gx = Math.floor(px / C), gy = Math.floor(py / C); if (gx < 0 || gy < 0 || gx >= G.w || gy >= G.h) return -1; return gy * G.w + gx;
  }
  function straight(a, b, max, key) {                            // same corridor, nothing in between
    var ax = a % G.w, ay = Math.floor(a / G.w), bx = b % G.w, bq = Math.floor(b / G.w), d, c = a, out = [];
    if ((ax !== bx && ay !== bq) || Math.abs(bx - ax) + Math.abs(bq - ay) > max) return null;
    d = ax === bx ? (bq > ay ? 2 : 0) : (bx > ax ? 1 : 3);
    while (c !== b) { if (LB.blocked(G, c, d, key)) return null; c = LB.nb(G, c, d); out.push(c); }
    return out;
  }
  function aim(x, y) {                                           // the finger draws the way, cell by cell; a touch far away is not a way
    if (K.isWon()) return; var t = cellAt(x, y), k; if (t < 0 || t === lastAim) return; lastAim = t; clearHint();
    var tail = way.length ? way[way.length - 1].c : st.c; if (t === tail) return;
    for (k = 0; k < way.length; k++) if (way[k].count && way[k].c === t) { way.length = k + 1; return; }            // the finger went back along its own trace
    if (t === st.c) { way = mid() ? [{ c: st.c, count: false }] : []; go(); return; }                               // back to where it last stood
    var key = st.key || way.some(function (w) { return w.c === G.key; }) ? 1 : 0;
    var path = LB.route(G, tail, t, key, 3) || straight(tail, t, 5, key); if (!path) return;
    way = way.concat(path.map(function (c) { return { c: c, count: true }; })); go();
  }
  scene.addEventListener('pointerdown', function (e) { if (e.pointerType === 'mouse' && e.button !== 0) return; e.preventDefault(); down = true; lastAim = -1; try { scene.setPointerCapture(e.pointerId); } catch (err) {} aim(e.clientX, e.clientY); });
  scene.addEventListener('pointermove', function (e) { if (down) aim(e.clientX, e.clientY); });
  function up() { down = false; lastAim = -1; }
  scene.addEventListener('pointerup', up); scene.addEventListener('pointercancel', up);
  scene.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  function clearHint() { if (hintG) hintG.innerHTML = ''; }
  K.start({
    key: 'labirinti.v1', count: RAW.length, perTier: 24, moveLabel: 'Passi', word: ['passo', 'passi'], winTitle: 'Arrivato alla grotta!', winDelay: 1500,
    intro: 'Trascina il dito lungo il sentiero: il dinosauro ti segue fino alla sua grotta. Non si passa attraverso le siepi.',
    rules: ['Porta il dinosauro alla sua grotta tracciando il sentiero con il dito: lui segue il percorso disegnato, le siepi non si attraversano.', 'Un tocco lontano non lo fa partire: il percorso va tracciato casella dopo casella.', 'Se ci sono stelle, vanno raccolte tutte prima che il masso liberi la grotta.', 'Il cancello si apre solo dopo aver preso la chiave.', 'Ogni casella percorsa conta un passo, anche quando si torna indietro.'],
    minOf: function (i) { return RAW[i].m; }, load: load, moves: function () { return hist ? hist.length : 0; }, canUndo: function () { return hist && hist.length > 0 && !walking; },
    undo: function () { way = []; var p = hist.pop(); st = p; setChr(cx(p.c), cy(p.c)); if (trailG.lastElementChild) trailG.removeChild(trailG.lastElementChild); refreshItems(); K.sfx('back'); K.changed(); },
    clearHint: clearHint,
    hint: function () {
      if (walking) return null; var path = LB.solve(G, st); if (!path || !path.length) return null;
      hintG.innerHTML = path.slice(0, 6).map(function (c, n) { return '<g class="hdot" style="--d:' + (n * 0.12) + 's"><circle cx="' + cx(c) + '" cy="' + cy(c) + '" r="34" fill="url(#gHint)"/>' + dot(cx(c), cy(c), 11, '#FFF4D9') + '</g>'; }).join('');
      return 'Segui i puntini arancioni. Da qui mancano ' + path.length + ' passi.';
    }
  });
})();
