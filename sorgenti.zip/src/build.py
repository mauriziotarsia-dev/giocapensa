#!/usr/bin/env python3
"""Build every page of the app into the repository root (GitHub Pages serves the root of main).

    python3 src/build.py

Never edit the HTML files in the root by hand: they are generated from src/."""
import base64, hashlib, json, os, re
SRC = os.path.dirname(os.path.abspath(__file__)) + '/'
ROOT = os.path.dirname(SRC.rstrip('/')) + '/'
def rd(p): return open(SRC + p, encoding='utf-8').read()
# Translations: src/lingue/<lang>.json maps each Italian text to its translation. Every page gets, for every language, only the texts it contains.
LINGUE = ['es', 'pt', 'fr', 'de', 'ja', 'zh-Hant', 'zh-Hans']
DIZ = {lg: json.load(open(SRC + 'lingue/' + lg + '.json', encoding='utf-8')) for lg in LINGUE}
def forms(k):                                   # how an Italian text can be written in the page: as it is, inside a JS string, inside HTML
    b = k.split('#')[0]; h = b.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return (b, b.replace("'", "\\'"), b.replace('"', '\\"'), h, h.replace("'", '&#39;'), h.replace('"', '&quot;'))
def testi(page):
    out = {lg: {k: v for k, v in d.items() if any(f in page for f in forms(k))} for lg, d in DIZ.items()}
    return '\n<script id="testi">window.TESTI = ' + json.dumps(out, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/') + ';</script>'
def wr(name, text):
    if '<!--TESTI-->' in text: text = text.replace('<!--TESTI-->', testi(text.replace('<!--TESTI-->', '')), 1)
    if name.endswith('.html') and 'name="robots"' not in text: text = text.replace('<meta name="viewport"', '<meta name="robots" content="noindex">\n<meta name="viewport"', 1)   # the site is for the family: search engines leave it out
    open(ROOT + name, 'w', encoding='utf-8').write(text); print('  %-18s %6d byte' % (name, len(text.encode('utf-8'))))

HOME_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/></svg>'
def wrap_pill(html, link):
    a = html.index('<button class="pill" id="btnLevels"'); b = html.index('</button>', a) + 9
    return html[:a] + '<div class="lft">' + link + html[a:b] + '</div>' + html[b:]
def add_css(html, css): i = html.index('</style>'); return html[:i] + css + html[i:]
SW = "\n<script>if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });</script>"
def close(html): assert html.count('</body>') == 1; return html.replace('</body>', SW + '\n</body>')
def shared_head(): return '\n<!--TESTI-->' + script('opzioni', rd('shared/opzioni.js')) + script('lingua', rd('shared/lingua.js')) + script('tocco', rd('shared/tocco.js')) + script('festa', rd('shared/festa.js'))
def script(name, code): assert '</script' not in code, name; return '\n<script id="' + name + '">\n' + code + '\n</script>'
def levels_js(path, var): return 'window.' + var + ' = ' + json.dumps(json.load(open(SRC + path)), separators=(',', ':')) + ';'

print('Pagine:')
# ---- Via libera -------------------------------------------------------------------------------------------------
icon = 'data:image/png;base64,' + base64.b64encode(open(SRC + 'pwa/icon-180.png', 'rb').read()).decode()
v = rd('via-libera/head.html').replace('/*__ICON__*/', icon) + rd('via-libera/body.html') + shared_head() + script('sound', rd('shared/sound.js')) + script('logic', rd('via-libera/logic.js')) + \
    '\n\n<script id="levels">\nwindow.VL_LEVELS = [' + ',\n'.join(json.dumps(s) for s in json.load(open(SRC + 'via-libera/levels.json'))) + '];\n</script>\n\n<script>\n' + rd('via-libera/main.js') + '</script>\n</body>\n</html>\n'
marker = '<link rel="stylesheet" href="https://fonts.googleapis.com'
v = v.replace(marker, '<link rel="manifest" href="manifest.json">\n<link rel="icon" type="image/png" href="icon-192.png">\n' + marker, 1)
v = wrap_pill(v, '<a class="homebtn" href="index.html" aria-label="Tutti i giochi" data-en-aria="All games">' + HOME_SVG + '</a>')
v = add_css(v, '\n.lft{display:flex; align-items:center; gap:6px; justify-self:start}\n.homebtn{width:40px; height:40px; flex:none; border-radius:50%; border:1.5px solid var(--line); background:var(--surface); color:inherit; display:grid; place-items:center}\n.homebtn svg{width:20px; height:20px}\n.lft .pill{padding:0 12px 0 10px}\n')
wr('via-libera.html', close(v))
# ---- Palline nei tubi -------------------------------------------------------------------------------------------
p = rd('palline/head_body.html') + shared_head() + script('sound', rd('shared/sound.js')) + script('logic', rd('palline/logic.js')) + script('levels', levels_js('palline/levels.json', 'TB_LEVELS')) + '\n<script>\n' + rd('palline/main.js') + '</script>\n</body>\n</html>\n'
p = wrap_pill(p, '<a class="round" href="index.html" aria-label="Tutti i giochi" data-en-aria="All games">' + HOME_SVG + '</a>')
wr('palline.html', close(add_css(p, '\n.lft{display:flex; align-items:center; gap:7px; justify-self:start}\na.round{color:inherit; text-decoration:none}\n')))
# ---- Adesivi (a single self-contained page) ---------------------------------------------------------------------
a = rd('adesivi/pagina.html'); assert a.count('<!--HOME-->') == 1 and a.count('<!--SCRIPTS-->') == 1
code = '(function () {\n  \'use strict\';\n' + rd('adesivi/disegni.js') + rd('adesivi/scene.js') + rd('adesivi/scene2.js') + rd('adesivi/nomi.js') + rd('adesivi/gioco.js') + '})();'
a = a.replace('<!--HOME-->', '<a class="round" href="index.html" aria-label="Tutti i giochi" data-en-aria="All games">' + HOME_SVG + '</a>')
a = a.replace('<!--SCRIPTS-->', (shared_head() + script('sound', rd('shared/sound.js')) + script('adesivi', code)).strip())
wr('adesivi.html', close(a))
# ---- the games built on the shared shell (src/shared) -----------------------------------------------------------
for folder, title in (('labirinti', 'Labirinti'), ('acqua', 'Acqua ai fiori'), ('incastri', 'Incastri')):
    page = rd('shared/kit.html').replace('{{TITLE}}', title).replace('{{CSS}}', rd(folder + '/game.css'))
    page += "\n<script>window.KIT_HOME = 'index.html';</script>" + shared_head() + script('sound', rd('shared/sound.js')) + script('kit', rd('shared/kit.js')) + script('logic', rd(folder + '/logic.js')) + script('levels', levels_js(folder + '/levels.json', 'GAME_LEVELS')) + script('game', rd(folder + '/game.js')) + '\n</body>\n</html>\n'
    wr(folder + '.html', close(page))
home = rd('home/home.html'); assert home.count('<script>') == 1
wr('index.html', close(home.replace('<script>', (shared_head() + script('sound', rd('shared/sound.js')) + script('music', rd('shared/music.js'))).lstrip('\n') + '\n<script>')))   # the music engine loads before the page's own script
# ---- icons, manifest, offline cache -----------------------------------------------------------------------------
for f in ('icon-180.png', 'icon-192.png', 'icon-512.png'): open(ROOT + f, 'wb').write(open(SRC + 'pwa/' + f, 'rb').read())
AUT = json.load(open(SRC + 'home/autore.json', encoding='utf-8'))
def fill(t):
    for k in ('autore', 'email', 'anno'):
        v = (AUT.get(k) or '').strip()
        if not v: print('  ATTENZIONE: manca «%s» in src/home/autore.json' % k); v = '(da completare)'
        t = t.replace('{{' + k.upper() + '}}', v.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))
    return t
wr('privacy.html', fill(rd('home/privacy.html')))
wr('info.html', fill(rd('home/info.html')))
pages = ['index.html', 'via-libera.html', 'palline.html', 'labirinti.html', 'acqua.html', 'incastri.html', 'adesivi.html', 'privacy.html', 'info.html']
wr('manifest.json', json.dumps({'name': 'Giocapensa — giochi per pensare', 'short_name': 'Giocapensa', 'lang': 'it', 'description': 'Sei giochi di logica e fantasia per bambini.', 'start_url': './', 'scope': './', 'display': 'standalone',
    'background_color': '#FDF3E3', 'theme_color': '#FDF3E3', 'icons': [{'src': 'icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'}, {'src': 'icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'}, {'src': 'icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'}]}, ensure_ascii=False, indent=2))
digest = hashlib.sha1(b''.join(open(ROOT + f, 'rb').read() for f in pages)).hexdigest()[:10]      # the cache name follows the content: every change reaches the phones
wr('sw.js', rd('pwa/sw.template.js').replace('__VERSION__', 'giochi-' + digest).replace('__SHELL__', ', '.join("'" + f + "'" for f in pages + ['manifest.json', 'icon-180.png', 'icon-192.png', 'icon-512.png'])))
print('Fatto. Versione cache: giochi-' + digest)
