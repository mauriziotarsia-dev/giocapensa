/* Pipe rules (no DOM). Sides as bits: 1 N, 2 E, 4 S, 8 W; a tile's rotation counts quarter turns clockwise. */
(function (root) {
  'use strict';
  var BASE = { I: 5, L: 3, T: 7, X: 15, S: 1, F: 1 }, PERIOD = { I: 2, L: 4, T: 4, X: 1, S: 4, F: 1 }, DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];
  function rotMask(m, r) { r &= 3; return ((m << r) | (m >> (4 - r))) & 15; }
  function parse(L) {
    var n = L.w * L.h, type = [], rot = [], target = [], i;
    for (i = 0; i < n; i++) { type.push(L.t.charAt(i * 2)); rot.push(+L.t.charAt(i * 2 + 1) || 0); target.push(L.g.charAt(i) === '.' ? -1 : +L.g.charAt(i)); }
    return { w: L.w, h: L.h, n: n, type: type, rot: rot, target: target, min: L.m, src: type.indexOf('S') };
  }
  function flood(G, rot) {
    var wet = [], st = [G.src], c, d, x, y, nx, ny, nb; wet[G.src] = true;
    while (st.length) {
      c = st.pop(); x = c % G.w; y = Math.floor(c / G.w);
      for (d = 0; d < 4; d++) {
        if (!(rotMask(BASE[G.type[c]] || 0, rot[c]) >> d & 1)) continue;
        nx = x + DX[d]; ny = y + DY[d]; if (nx < 0 || ny < 0 || nx >= G.w || ny >= G.h) continue; nb = ny * G.w + nx;
        if (wet[nb] || !(rotMask(BASE[G.type[nb]] || 0, rot[nb]) >> ((d + 2) & 3) & 1)) continue; wet[nb] = true; st.push(nb);
      }
    }
    return wet;
  }
  function won(G, rot) { var wet = flood(G, rot); for (var i = 0; i < G.n; i++) if (G.type[i] === 'F' && !wet[i]) return false; return true; }
  function need(G, rot, c) { var p = PERIOD[G.type[c]]; return G.target[c] < 0 || p < 2 ? 0 : ((G.target[c] - rot[c]) % p + p) % p; }   // taps still missing on one tile
  root.AQ = { parse: parse, flood: flood, won: won, need: need, BASE: BASE, PERIOD: PERIOD, rotMask: rotMask, DX: DX, DY: DY };
})(typeof window !== 'undefined' ? window : globalThis);
