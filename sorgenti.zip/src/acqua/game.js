(function () {
  'use strict';
  var RAW = window.GAME_LEVELS, AQ = window.AQ, K = window.Kit, INK = K.INK, scene = document.getElementById('scene');
  var G, rot, angle, hist, wet, C = 120, PAD = 46, W, H, tilesG, leaksG, hintG, fxG;
  var PATH = { I: 'M0 -60V60', L: 'M0 -60V0H60', T: 'M0 -60V60M0 0H60', X: 'M0 -60V60M-60 0H60', S: 'M0 -60V0', F: 'M0 -60V0' }, SIDES = { I: [0, 2], L: [0, 1], T: [0, 1, 2], X: [0, 1, 2, 3], S: [0], F: [0] };
  function cx(c) { return PAD + (c % G.w) * C + C / 2; } function cy(c) { return PAD + Math.floor(c / G.w) * C + C / 2; }
  function dot(x, y, r, f) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + (f || INK) + '"/>'; }
  function defs() {
    return '<defs><radialGradient id="gLawn" cx="50%" cy="35%" r="85%"><stop offset="0" stop-color="#C9EDA6"/><stop offset="1" stop-color="#8ECB72"/></radialGradient>' +
      '<linearGradient id="gSoil" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#A9825A"/><stop offset="1" stop-color="#8A6643"/></linearGradient>' +
      '<linearGradient id="gSlab" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF6DF"/><stop offset="1" stop-color="#E6D2A6"/></linearGradient>' +
      '<linearGradient id="gPlank" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#D9A06C"/><stop offset="1" stop-color="#A06A3A"/></linearGradient>' +
      '<radialGradient id="gValve" cx="38%" cy="32%" r="75%"><stop offset="0" stop-color="#B9DDFF"/><stop offset="1" stop-color="#4C8FE0"/></radialGradient>' +
      '<radialGradient id="gCore" cx="40%" cy="35%" r="75%"><stop offset="0" stop-color="#FFF0A0"/><stop offset="1" stop-color="#F5B82E"/></radialGradient>' +
      ['#FFE27A,#F0AE2B', '#FFB37A,#EC7428', '#A6D2FF,#4C8FE0', '#FF9C8A,#E2503F'].map(function (g, i) { var c = g.split(','); return '<radialGradient id="gPet' + i + '" cx="50%" cy="80%" r="90%"><stop offset="0" stop-color="' + c[1] + '"/><stop offset="1" stop-color="' + c[0] + '"/></radialGradient>'; }).join('') + '</defs>';
  }
  function pipe(t) {
    var d = PATH[t], s = '';
    [[INK, 52], ['#8398AC', 44], ['#C3D0DC', 33]].forEach(function (l) { s += '<path d="' + d + '" fill="none" stroke="' + l[0] + '" stroke-width="' + l[1] + '" stroke-linejoin="round"/>'; });
    s += '<path class="water" d="' + d + '" fill="none" stroke="#3FA7F2" stroke-width="27" stroke-linejoin="round"/><path d="' + d + '" fill="none" stroke="#F6FAFD" stroke-width="7" stroke-linejoin="round" stroke-linecap="round" opacity=".85" transform="translate(-8,-8)"/>' +
      '<path class="flowdash" d="' + d + '" fill="none" stroke="#E8F6FF" stroke-width="7" stroke-linejoin="round" stroke-linecap="round"/>';
    SIDES[t].forEach(function (sd) { s += '<g transform="rotate(' + sd * 90 + ')"><rect x="-31" y="-60" width="62" height="14" rx="5" fill="#6F8397"' + K.k(4) + '/><rect x="-24" y="-57" width="20" height="4" rx="2" fill="#fff" opacity=".5"/></g>'; });
    if (t === 'I') s += '<rect x="-31" y="-9" width="62" height="18" rx="6" fill="#9DB0C2"' + K.k(4) + '/>';
    else if (t !== 'S' && t !== 'F') { s += '<circle r="23" fill="#A9BACA"' + K.k(4) + '/><circle r="12" fill="#D9E3EC"/>'; [45, 135, 225, 315].forEach(function (a) { s += dot((Math.cos(a * Math.PI / 180) * 17).toFixed(1), (Math.sin(a * Math.PI / 180) * 17).toFixed(1), 2.6, '#5E7184'); }); }
    return s;
  }
  function flower(n) {                                          // a thirsty flower is pale, droops and asks for water; once watered it opens petal by petal
    var pet = '', dry = '', i, gr = 'url(#gPet' + (n % 4) + ')';
    for (i = 0; i < 8; i++) pet += '<g transform="rotate(' + i * 45 + ')"><ellipse class="petal" style="--i:' + i + '" cx="0" cy="-31" rx="14.500" ry="22" fill="' + gr + '"' + K.k(4) + '/></g>';
    for (i = 0; i < 6; i++) dry += '<g transform="rotate(' + (i * 60 + 30) + ')"><ellipse cx="0" cy="-22" rx="9.500" ry="15" fill="#D9D2DE"' + K.k(3.5) + '/></g>';
    return '<g class="head"><g class="dry"><g class="droop">' + dry + '<circle r="15" fill="#E3D3A4"' + K.k(4) + '/><path d="M-8 -4q3 -3 6 0M2 -4q3 -3 6 0" fill="none"' + K.k(2.6) + '/><path d="M-5 7q5 -5 10 0" fill="none"' + K.k(2.6) + '/></g>' +
      '<g class="thirst"><path d="M22 -66a21 21 0 1 1 8 40l-12 12l2 -15a21 21 0 0 1 2 -37Z" fill="#fff"' + K.k(4) + '/><path d="M32 -62q12 15 0 23q-12 -8 0 -23Z" fill="#45AEF5"' + K.k(3) + '/><ellipse cx="28.500" cy="-47" rx="2.200" ry="4" fill="#fff" opacity=".8"/></g></g>' +
      '<g class="bloom"><g class="fdance" style="--d:' + (-n * 0.6) + 's">' + pet + '<g class="core"><circle r="22" fill="url(#gCore)"' + K.k(4.5) + '/><ellipse cx="-7" cy="-9" rx="7" ry="4" fill="#fff" opacity=".6" transform="rotate(-30 -7 -9)"/>' +
      '<g class="blink" style="--d:' + (-n * 1.3) + 's">' + dot(-8, -3, 3.8) + dot(8, -3, 3.8) + '</g><path d="M-9 6q9 10 18 0Z" fill="#7A3B46"' + K.k(3) + '/>' + dot(-15, 5, 4, '#FFB59A') + dot(15, 5, 4, '#FFB59A') + '</g></g>' +
      '<g class="heart" style="--d:' + (-n * 1.1) + 's"><path d="M0 -74q15 19 0 30q-15 -11 0 -30Z" fill="#56B4EE"' + K.k(3) + '/><ellipse cx="-4" cy="-54" rx="2.600" ry="4.500" fill="#fff" opacity=".8"/></g>' +
      '<g class="orbit" style="--d:' + (-n * 1.7) + 's"><g transform="translate(60,0)"><ellipse class="bwing" cx="-3" cy="-9" rx="7" ry="9" fill="#fff" opacity=".9"' + K.k(2) + '/><ellipse cx="0" cy="0" rx="10" ry="7.500" fill="#FFD23F"' + K.k(3) + '/><path d="M-3 -7v14M3 -7v14" stroke="' + INK + '" stroke-width="3"/></g></g></g></g>';
  }
  function tap() {                                               // the pump: a blue tank with a red hand-wheel that never stops turning
    var sp = ''; [0, 45, 90, 135].forEach(function (a) { sp += '<rect x="-27" y="-4.500" width="54" height="9" rx="4.500" fill="#E8605F"' + K.k(3) + ' transform="rotate(' + a + ')"/>'; });
    return '<g class="head"><circle class="ripple" r="46" fill="none" stroke="#7DC4F7" stroke-width="5"/><circle class="ripple" style="--d:-1.2s" r="46" fill="none" stroke="#7DC4F7" stroke-width="5"/>' +
      '<circle r="37" fill="url(#gValve)"' + K.k(5) + '/><circle r="37" fill="none" stroke="#fff" stroke-width="4" stroke-dasharray="26 210" stroke-linecap="round" opacity=".6" transform="rotate(-150)"/><g class="wheel">' + sp + '<circle r="28" fill="none" stroke="#E8605F" stroke-width="8"/><circle r="28" fill="none"' + K.k(2.5) + '/></g><circle r="9" fill="#FFD95A"' + K.k(3.5) + '/></g>';
  }
  function sprout(n) { return '<g class="sprout" style="--d:' + (-n * 0.7) + 's"><path d="M0 16v-16" stroke="#5F9E48" stroke-width="5" stroke-linecap="round"/><path d="M0 2q-16 -2 -18 -16q15 0 18 16ZM0 -2q14 -4 16 -18q-14 2 -16 18Z" fill="#8FD06F"' + K.k(3) + '/></g>'; }
  function butterfly(col, bt, bd) { return '<g class="bfly" style="--bt:' + bt + 's;--bd:' + bd + 's"><g class="bwL"><path d="M0 0q-20 -24 -28 -6t28 6q-24 6 -18 20t18 -20Z" fill="' + col + '"' + K.k(2.5) + '/></g><g class="bwR"><path d="M0 0q20 -24 28 -6t-28 6q24 6 18 20t-18 -20Z" fill="' + col + '"' + K.k(2.5) + '/></g><rect x="-3" y="-10" width="6" height="24" rx="3" fill="' + INK + '"/></g>'; }
  function load(i) {
    G = AQ.parse(RAW[i]); rot = G.rot.slice(); angle = rot.map(function (r) { return r * 90; }); hist = [];
    W = G.w * C + PAD * 2; H = G.h * C + PAD * 2; scene.setAttribute('viewBox', '0 0 ' + W + ' ' + H); scene.style.setProperty('--scene-bg', '#A8D98A'); scene.style.setProperty('--w', W + 'px'); scene.style.setProperty('--h', H + 'px');
    var s = defs() + '<rect x="-3000" y="-3000" width="9000" height="9000" fill="url(#gLawn)"/>', c, nf = 0, x, y, k2;
    for (x = -2400; x < 3400; x += 150) s += '<rect x="' + x + '" y="-3000" width="75" height="9000" fill="#fff" opacity=".07" transform="rotate(14 ' + (W / 2) + ' ' + (H / 2) + ')"/>';
    for (k2 = 0; k2 < 40; k2++) { x = ((k2 * 211) % (W + 640)) - 320; y = ((k2 * 149) % (H + 640)) - 320; if (x > 0 && x < W && y > 0 && y < H) continue;
      s += k2 % 3 ? '<path d="M' + x + ' ' + y + 'l5 -15l5 15l6 -11l3 11" fill="none" stroke="#6FB257" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>' : '<g>' + [0, 1, 2, 3, 4].map(function (q) { return dot((x + 7 * Math.cos(q * 1.2566)).toFixed(1), (y + 7 * Math.sin(q * 1.2566)).toFixed(1), 5, '#fff'); }).join('') + dot(x, y, 3.6, '#FFD95A') + '</g>'; }
    s += '<g class="world"><rect x="' + (PAD - 24) + '" y="' + (PAD - 12) + '" width="' + (G.w * C + 48) + '" height="' + (G.h * C + 48) + '" rx="30" fill="#33502A" opacity=".28"/>' +
      '<rect x="' + (PAD - 26) + '" y="' + (PAD - 26) + '" width="' + (G.w * C + 52) + '" height="' + (G.h * C + 52) + '" rx="30" fill="url(#gPlank)"' + K.k(5) + '/>' +
      '<rect x="' + (PAD - 9) + '" y="' + (PAD - 9) + '" width="' + (G.w * C + 18) + '" height="' + (G.h * C + 18) + '" rx="18" fill="url(#gSoil)"' + K.k(4) + '/>';
    for (k2 = 0; k2 < G.n * 5; k2++) s += dot(PAD + (k2 * 67) % (G.w * C), PAD + (k2 * 101) % (G.h * C), 3 + k2 % 3, k2 % 2 ? '#7A5837' : '#B8946B');
    s += '<g id="tiles">';
    for (c = 0; c < G.n; c++) {
      var t = G.type[c]; if (t === '.') { s += '<g transform="translate(' + cx(c) + ',' + (cy(c) + 6) + ')">' + sprout(c) + '</g>'; continue; }
      var slab = t === 'F' ? '<ellipse cx="4" cy="10" rx="54" ry="50" fill="#4A3218" opacity=".3"/><circle r="54" fill="#D9774F"' + K.k(4.5) + '/><circle r="43" fill="#6E4E31"/><circle r="43" fill="none" stroke="#4A3218" stroke-width="4" opacity=".45"/><path d="M-45 -24a51 51 0 0 1 34 -26" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".55"/>' + dot(-20, 22, 3.5, '#8A6643') + dot(24, 14, 3, '#8A6643') + dot(6, 30, 2.6, '#8A6643')
        : '<rect x="-51" y="-46" width="108" height="108" rx="20" fill="#4A3218" opacity=".3"/><rect x="-55" y="-55" width="110" height="110" rx="20" fill="' + (t === 'S' ? '#D5E8FB' : 'url(#gSlab)') + '" stroke="' + (t === 'S' ? '#7FA9D9' : '#B59C6A') + '" stroke-width="4"/>' +
        '<path d="M-44 40V-32a12 12 0 0 1 12 -12H40" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".8"/><path d="M44 -38V32a12 12 0 0 1 -12 12H-38" fill="none" stroke="' + (t === 'S' ? '#7FA9D9' : '#B59C6A') + '" stroke-width="5" stroke-linecap="round" opacity=".45"/>' +
        dot(-30 + (c * 13) % 20, 28, 3, t === 'S' ? '#B5D0EE' : '#D9C493') + dot(24, -30 + (c * 7) % 16, 2.5, t === 'S' ? '#B5D0EE' : '#D9C493');
      s += '<g class="tile' + (t === 'F' ? ' thirsty' : '') + '" data-c="' + c + '" transform="translate(' + cx(c) + ',' + cy(c) + ')"><g class="slab">' + slab + '</g>' +
        '<g class="spin" style="transform:rotate(' + angle[c] + 'deg)">' + pipe(t) + '</g>' + (t === 'S' ? tap() : t === 'F' ? flower(nf++) : '') + '</g>';
    }
    scene.innerHTML = s + '</g><g id="leaks"></g><g id="hintG"></g></g>' + butterfly('#FFF1A8', 26, -6) + butterfly('#8FC4F7', 34, -21) + '<g id="fxG"></g>';
    tilesG = scene.querySelector('#tiles'); leaksG = scene.querySelector('#leaks'); hintG = scene.querySelector('#hintG'); fxG = scene.querySelector('#fxG'); wet = []; refresh(true);
    return '';
  }
  function el(c) { return tilesG.querySelector('[data-c="' + c + '"]'); }
  function refresh(quiet) {
    var now = AQ.flood(G, rot), c;
    for (c = 0; c < G.n; c++) { if (G.type[c] === '.') continue; var e = el(c), w = !!now[c]; e.classList.toggle('wet', w);
      if (G.type[c] === 'F' && w && !wet[c] && !quiet) { K.sparkle(fxG, cx(c), cy(c), 14); K.sfx('water', c); K.buzz(12); } }
    wet = now;
    var spill = '', d, m, nx, ny, nb;
    for (c = 0; c < G.n; c++) {
      if (!now[c] || G.type[c] === '.') continue; m = AQ.rotMask(AQ.BASE[G.type[c]] || 0, rot[c]);
      for (d = 0; d < 4; d++) {
        if (!(m >> d & 1)) continue; nx = c % G.w + AQ.DX[d]; ny = Math.floor(c / G.w) + AQ.DY[d]; nb = nx < 0 || ny < 0 || nx >= G.w || ny >= G.h ? -1 : ny * G.w + nx;
        if (nb >= 0 && (AQ.rotMask(AQ.BASE[G.type[nb]] || 0, rot[nb]) >> ((d + 2) & 3) & 1)) continue;
        spill += '<g transform="translate(' + (cx(c) + AQ.DX[d] * 58) + ',' + (cy(c) + AQ.DY[d] * 58) + ') rotate(' + d * 90 + ')">' + [0, 1, 2].map(function (q) { return '<circle class="leak" style="--d:' + (-q * 0.3) + 's;--x:' + ((q - 1) * 9) + 'px" cx="0" cy="0" r="' + (6 - q) + '" fill="#56B4EE" stroke="' + INK + '" stroke-width="2"/>'; }).join('') + '</g>';
      }
    }
    leaksG.innerHTML = spill;
  }
  function turn(c, dir) { rot[c] = (rot[c] + dir + 4) & 3; angle[c] += 90 * dir; el(c).querySelector('.spin').style.transform = 'rotate(' + angle[c] + 'deg)'; }
  function cellAt(x, y) {
    var b = scene.getBoundingClientRect(), s = Math.min(b.width / W, b.height / H), px = (x - b.left - (b.width - W * s) / 2) / s - PAD, py = (y - b.top - (b.height - H * s) / 2) / s - PAD;
    var gx = Math.floor(px / C), gy = Math.floor(py / C); if (gx < 0 || gy < 0 || gx >= G.w || gy >= G.h) return -1; return gy * G.w + gx;
  }
  scene.addEventListener('pointerdown', function (e) {
    if (K.isWon() || (e.pointerType === 'mouse' && e.button !== 0)) return; var c = cellAt(e.clientX, e.clientY); if (c < 0 || G.type[c] === '.') return;
    e.preventDefault(); clearHint(); var t = G.type[c];
    if (t === 'F') { var n = el(c); n.classList.remove('no'); void n.getBoundingClientRect(); n.classList.add('no'); K.sfx('bad'); return; }   // flowers stay where they grow; the pump turns like any pipe
    turn(c, 1); K.sfx('turn', rot[c]); K.buzz(7); var pe = el(c); pe.classList.remove('press'); void pe.getBoundingClientRect(); pe.classList.add('press');
    if (AQ.PERIOD[t] > 1) hist.push(c);                                  // a cross looks the same from every side: spinning it is free
    setTimeout(function () { refresh(); K.changed(); if (AQ.won(G, rot) && !K.isWon()) { celebrate(); K.win(); } }, K.calm ? 0 : 190);
    K.changed();
  });
  scene.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  function celebrate() {                                  // a rainbow grows over the garden, the flowers jump, confetti falls
    tilesG.classList.add('party'); var r0 = W * 0.62, s2 = '', i2, cols = ['#F47C7C', '#F2A65A', '#FFD95A', '#8DD68A', '#7DB7F7'];
    for (i2 = 0; i2 < 5; i2++) { var rr = r0 - i2 * 17; s2 += '<path class="rb" style="--d:' + (i2 * 0.09) + 's" d="M' + (W / 2 - rr) + ' ' + (H * 0.55) + 'A' + rr + ' ' + rr + ' 0 0 1 ' + (W / 2 + rr) + ' ' + (H * 0.55) + '" fill="none" stroke="' + cols[i2] + '" stroke-width="17" stroke-linecap="round" opacity=".9"/>'; }
    fxG.insertAdjacentHTML('beforeend', s2); K.confetti(fxG, W, H);
  }
  function clearHint() { if (hintG) hintG.innerHTML = ''; }
  K.start({
    key: 'acqua.v2', count: RAW.length, perTier: 24, moveLabel: 'Tocchi', word: ['tocco', 'tocchi'], winTitle: 'Tutti i fiori bevono!', winDelay: 1300,
    intro: "I fiori pallidi hanno sete. Tocca i tubi, e anche la pompa blu, per girarli: l'acqua deve arrivare a tutti i fiori.",
    rules: ["Ogni tocco gira un tubo di un quarto di giro, sempre nello stesso verso.", "L'acqua parte dalla pompa blu e scorre solo dove i tubi combaciano.", 'Il livello è risolto quando tutti i fiori sono sbocciati.', 'Anche la pompa blu si gira; i fiori no. Dove un tubo resta aperto l\'acqua gocciola fuori. I tubi che non servono si possono lasciare come sono.'],
    minOf: function (i) { return RAW[i].m; }, load: load, moves: function () { return hist ? hist.length : 0; }, canUndo: function () { return hist && hist.length > 0; },
    undo: function () { var c = hist.pop(); turn(c, -1); K.sfx('back'); setTimeout(function () { refresh(true); }, K.calm ? 0 : 170); K.changed(); },
    clearHint: clearHint,
    hint: function () {
      var best = -1, bd = 1e9, left = 0, c;
      for (c = 0; c < G.n; c++) { var n = AQ.need(G, rot, c); if (!n) continue; left += n; var d = Math.abs(c % G.w - G.src % G.w) + Math.abs(Math.floor(c / G.w) - Math.floor(G.src / G.w)); if (d < bd) { bd = d; best = c; } }
      if (best < 0) return null; var k = AQ.need(G, rot, best);
      hintG.innerHTML = '<circle class="ring2" cx="' + cx(best) + '" cy="' + cy(best) + '" r="66"/>';
      return 'Tocca il tubo cerchiato ' + (k === 1 ? 'una volta' : k + ' volte') + '.' + (left > k ? ' In tutto mancano ' + left + ' tocchi.' : '');
    }
  });
})();
