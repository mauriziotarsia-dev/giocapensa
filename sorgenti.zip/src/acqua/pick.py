#!/usr/bin/env python3
"""Choose the 120 graded levels from the pools written by gen.cpp (./gen W H flowers decoys minTaps maxTaps howMany seed > pool.txt).
   usage: python3 pick.py <folder with q1.txt q2a.txt q2b.txt q3.txt q4.txt q5.txt> > levels.json"""
import json, random, sys
random.seed(3); G = sys.argv[1].rstrip('/') + '/'
def pool(*names):
    out = []
    for n in names:
        for line in open(G + n + '.txt'):
            a = line.split(); out.append({'w': int(a[0]), 'h': int(a[1]), 'm': int(a[3]), 't': a[4], 'g': a[5]})
    return out
def take(items, n):
    by = {}
    for it in items: by.setdefault(it['m'], []).append(it)
    for v in by.values(): random.shuffle(v)
    ms = sorted(by); got = []
    while len(got) < n and any(by[m] for m in ms):
        for m in ms:
            if by[m] and len(got) < n: got.append(by[m].pop())
    assert len(got) == n, (n, len(got)); return sorted(got, key=lambda it: (it['m'], it['w'] * it['h']))
tiers = [take(pool('q1'), 24), take(pool('q2a', 'q2b'), 24), take(pool('q3'), 24), take(pool('q4'), 24), take(pool('q5'), 24)]
json.dump([{'w': it['w'], 'h': it['h'], 't': it['t'], 'g': it['g'], 'm': it['m']} for t in tiers for it in t], sys.stdout, separators=(',', ':'))
for i, t in enumerate(tiers): print('fascia', i + 1, 'tocchi minimi:', ' '.join(str(x['m']) for x in t), file=sys.stderr)
