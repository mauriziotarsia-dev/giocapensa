// "Acqua ai fiori": rotate pipe tiles (clockwise taps) until water from the tap reaches every flower.
// A level is built from a random tree tap->flowers, decoy tiles are scattered, tiles are scrambled,
// then the true minimum number of taps is found by exhaustive search over cheaper rotation sets.
#include <bits/stdc++.h>
using namespace std;
static std::mt19937 rng(5);
static int W, H, N;
static const int DX[4] = {0, 1, 0, -1}, DY[4] = {-1, 0, 1, 0};
static inline int rot(int m, int r) { r &= 3; return ((m << r) | (m >> (4 - r))) & 15; }
static int baseMask(char t) { switch (t) { case 'I': return 5; case 'L': return 3; case 'T': return 7; case 'X': return 15; case 'S': case 'F': return 1; } return 0; }
static int period(char t) { return t == 'I' ? 2 : (t == 'L' || t == 'T' || t == 'S') ? 4 : 1; }   // the tap turns too; flowers stay put
static vector<char> type; static vector<int> rotn; static int src; static vector<int> flowers;

static bool wins(const vector<int>& r) {
  static vector<int> mask; mask.assign(N, 0); for (int i = 0; i < N; i++) mask[i] = rot(baseMask(type[i]), r[i]);
  vector<char> wet(N, 0); vector<int> st{src}; wet[src] = 1;
  while (!st.empty()) { int c = st.back(); st.pop_back(); int x = c % W, y = c / W;
    for (int d = 0; d < 4; d++) { if (!(mask[c] >> d & 1)) continue; int nx = x + DX[d], ny = y + DY[d]; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; int n = ny * W + nx;
      if (wet[n] || !(mask[n] >> ((d + 2) & 3) & 1)) continue; wet[n] = 1; st.push_back(n); } }
  for (int f : flowers) if (!wet[f]) return false; return true;
}
static vector<int> movable, cur, found; static long nodes;
static bool dfs(size_t i, int left) {
  if (++nodes > 60000000) return false;
  if (i == movable.size()) { if (left) return false; if (wins(cur)) { found = cur; return true; } return false; }
  int c = movable[i], p = period(type[c]), r0 = cur[c];
  for (int e = 0; e < p && e <= left; e++) { cur[c] = (r0 + e) & 3; if (dfs(i + 1, left - e)) { cur[c] = r0; return true; } }
  cur[c] = r0; return false;
}

int main(int argc, char** argv) {
  W = atoi(argv[1]); H = atoi(argv[2]); int nf = atoi(argv[3]); double decoy = atof(argv[4]); int lo = atoi(argv[5]), hi = atoi(argv[6]), want = atoi(argv[7]); rng.seed(atoi(argv[8])); N = W * H;
  int made = 0, tries = 0; set<string> seen;
  while (made < want && tries++ < 40000) {
    type.assign(N, '.'); rotn.assign(N, 0); vector<int> conn(N, 0); vector<char> inTree(N, 0);
    src = rng() % N; flowers.clear();
    vector<int> cells(N); iota(cells.begin(), cells.end(), 0); shuffle(cells.begin(), cells.end(), rng);
    for (int c : cells) { if ((int)flowers.size() == nf) break; if (c == src) continue; int d = abs(c % W - src % W) + abs(c / W - src / W); if (d < 2) continue; bool ok = true; for (int f : flowers) if (abs(c % W - f % W) + abs(c / W - f / W) < 2) ok = false; if (ok) flowers.push_back(c); }
    if ((int)flowers.size() < nf) continue;
    inTree[src] = 1; bool fail = false; int srcUsed = 0;
    for (int f : flowers) {                                   // wiggly path from the flower to the tree: Dijkstra on random cell weights
      vector<int> w(N); for (int& v : w) v = 1 + rng() % 9; vector<int> dist(N, 1e9), prev(N, -1); priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq; dist[f] = 0; pq.push({0, f}); int hit = -1;
      while (!pq.empty()) { auto [dd, c] = pq.top(); pq.pop(); if (dd > dist[c]) continue; if (inTree[c]) { hit = c; break; } int x = c % W, y = c / W;
        for (int d = 0; d < 4; d++) { int nx = x + DX[d], ny = y + DY[d]; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; int n = ny * W + nx; bool isF = find(flowers.begin(), flowers.end(), n) != flowers.end();
          if (isF) continue; if (n == src && srcUsed) continue; if (inTree[n] && n != src && conn[n] && __builtin_popcount(conn[n]) >= 3) continue; if (dist[n] > dd + w[n]) { dist[n] = dd + w[n]; prev[n] = c; pq.push({dist[n], n}); } } }
      if (hit < 0) { fail = true; break; }
      for (int c = hit; prev[c] != -1 || c == hit; ) { int pnode = prev[c]; if (pnode < 0) break; int dx = pnode % W - c % W, dy = pnode / W - c / W, d = dx == 1 ? 1 : dx == -1 ? 3 : dy == 1 ? 2 : 0; conn[c] |= 1 << d; conn[pnode] |= 1 << ((d + 2) & 3); inTree[c] = inTree[pnode] = 1; c = pnode; }
      if (conn[src]) srcUsed = 1;
    }
    if (fail || __builtin_popcount(conn[src]) != 1) continue;
    bool bad = false; for (int f : flowers) if (__builtin_popcount(conn[f]) != 1) bad = true; if (bad) continue;
    vector<int> solvedRot(N, 0);
    for (int c = 0; c < N; c++) {
      if (!inTree[c]) { if ((double)(rng() % 1000) / 1000 < decoy) { type[c] = "ILLIT"[rng() % 5]; rotn[c] = rng() % 4; } continue; }
      int m = conn[c], pc = __builtin_popcount(m); char t = c == src ? 'S' : find(flowers.begin(), flowers.end(), c) != flowers.end() ? 'F' : pc == 4 ? 'X' : pc == 3 ? 'T' : (m == 5 || m == 10) ? 'I' : 'L';
      type[c] = t; for (int r = 0; r < 4; r++) if (rot(baseMask(t), r) == m) { solvedRot[c] = r; break; }
      rotn[c] = t == 'F' ? solvedRot[c] : (solvedRot[c] + 4 - (int)(rng() % period(t))) & 3;   // scramble: some taps away from the answer (the tap included)
    }
    int U = 0; for (int c = 0; c < N; c++) if (inTree[c] && period(type[c]) > 1) U += ((solvedRot[c] - rotn[c]) % period(type[c]) + period(type[c])) % period(type[c]);
    if (U < lo || U > hi || wins(rotn)) continue;
    movable.clear(); for (int c = 0; c < N; c++) if (period(type[c]) > 1) movable.push_back(c);
    if (movable.size() > 19) continue;
    int best = U; vector<int> target(N, -1); for (int c = 0; c < N; c++) if (inTree[c] && period(type[c]) > 1) target[c] = solvedRot[c];
    bool gaveUp = false;
    for (int c = 1; c < U; c++) { cur = rotn; nodes = 0; if (dfs(0, c)) { best = c; for (int q = 0; q < N; q++) target[q] = (period(type[q]) > 1 && found[q] != rotn[q]) ? found[q] : -1; break; } if (nodes > 60000000) { gaveUp = true; break; } }
    if (gaveUp || best < lo) continue;
    string tiles, tg; for (int c = 0; c < N; c++) { tiles += type[c]; tiles += char('0' + rotn[c]); tg += target[c] < 0 ? '.' : char('0' + target[c]); }
    if (!seen.insert(tiles).second) continue;
    printf("%d %d %d %d %s %s\n", W, H, nf, best, tiles.c_str(), tg.c_str()); fflush(stdout); made++;
  }
  fprintf(stderr, "%dx%d f=%d made=%d tries=%d\n", W, H, nf, made, tries);
}
