  /* ====== New stickers for the station and the building site ====== */
  function wheel(x, y, rr, col) { return G('part spin fast', c(x, y, rr, '#2B323B') + ln('M' + x + ' ' + (y - rr + 5) + 'v' + (rr * 2 - 10) + 'M' + (x - rr + 5) + ' ' + y + 'h' + (rr * 2 - 10), col || '#FFD95A', 3.5) + dot(x, y, rr > 16 ? 6 : 4, col || '#FFD95A')); }
  function face(x, y, gap) { return eyes(x - gap, x + gap, y, 4.5) + smile(x, y + 10, 6); }

  ART.locomotiva = { w: 210, h: 150, size: 250, idle: 'i-drive', tap: 'react', note: 262, d: function () {
    return G('part puff', c(53, 14, 10, '#fff', 3) + c(68, 4, 7, '#fff', 3)) + r(40, 22, 26, 34, 6, '#3A4654') +
      r(14, 50, 118, 62, 22, '#EE5E4D') + shine(52, 62, 22, 6, 0) +
      r(122, 26, 74, 86, 12, '#C7402F') + r(136, 40, 46, 32, 8, '#DFF3FC') + r(114, 16, 90, 16, 8, '#3A4654') +
      r(8, 104, 194, 18, 9, '#3A4654') + p('M8 110l-8 14h16Z', '#F59A3A', 4) +
      wheel(44, 128, 18) + wheel(92, 128, 18) + wheel(162, 126, 22) +
      eyes(32, 54, 76, 5) + smile(43, 88, 7) + cheeks(43, 84, 20);
  } };
  ART.vagone = { w: 210, h: 140, size: 250, idle: 'i-drive', tap: 'react', note: 330, d: function () {
    var s = r(8, 26, 194, 82, 16, '#5FA4F2') + r(4, 16, 202, 18, 9, '#3A4654') + shine(40, 44, 26, 6, 0);
    [24, 84, 144].forEach(function (x, n) { s += r(x, 42, 44, 36, 9, '#DFF3FC') + c(x + 22, 64, 11, ['#FFD9B3', '#F0C08A', '#FFE0C7'][n], 3) + dot(x + 18, 62, 2.2) + dot(x + 26, 62, 2.2) + p('M' + (x + 17) + ' 68q5 4 10 0', null, 2.2); });
    return s + r(8, 102, 194, 14, 7, '#3A4654') + wheel(40, 124, 14) + wheel(84, 124, 14) + wheel(126, 124, 14) + wheel(170, 124, 14);
  } };
  ART.carromerci = { w: 210, h: 140, size: 250, idle: 'i-drive', tap: 'react', note: 294, d: function () {
    return r(16, 36, 58, 58, 8, '#E0A96B') + ln('M24 44l42 42M66 44l-42 42', '#B9793D', 4) +
      r(82, 52, 52, 42, 7, '#FFD95A') + ln('M84 66h48', '#D9A516', 4) +
      r(140, 22, 56, 72, 9, '#4FC3C7') + ln('M154 30v56M168 30v56M182 30v56', '#2E9AA1', 4) + shine(152, 32, 6, 3, 0) +
      r(6, 92, 198, 16, 8, '#4FAE57') + r(6, 106, 198, 10, 5, '#3A4654') + wheel(40, 124, 14) + wheel(84, 124, 14) + wheel(126, 124, 14) + wheel(170, 124, 14);
  } };
  ART.valigia = { w: 120, h: 112, size: 120, idle: 'i-breathe', tap: 'react', note: 392, d: function () {
    return p('M42 26v-12q0-8 8-8h20q8 0 8 8v12', null, 6) + r(10, 24, 100, 76, 14, '#C98A5B') + ln('M14 52h92', '#9C6A3B', 5) +
      r(48, 42, 24, 16, 5, '#FFD95A', 4) + c(30, 78, 10, '#7DB7F7', 3.5) + star(84, 79, 11, '#FFD95A', 3) + shine(28, 34, 10, 4, 0) +
      c(26, 103, 7, '#3A4654', 3) + c(94, 103, 7, '#3A4654', 3);
  } };
  ART.carrello = { w: 150, h: 132, size: 150, idle: 'i-breathe', tap: 'react', note: 349, d: function () {
    return p('M128 8v92M116 8h24', null, 7) + r(18, 46, 56, 50, 8, '#7DB7F7') + r(70, 28, 50, 68, 8, '#EE5E4D') + shine(84, 38, 8, 4, 0) +
      r(24, 58, 40, 10, 5, '#FFF4D9', 3) + r(8, 96, 132, 12, 6, '#3A4654') + c(32, 116, 12, '#2B323B') + c(112, 116, 12, '#2B323B') + dot(32, 116, 4, '#B9BDC4') + dot(112, 116, 4, '#B9BDC4');
  } };
  ART.mongolfiera = { w: 130, h: 172, size: 160, idle: 'i-float', tap: 'twirl', note: 784, d: function () {
    return p('M44 112l-8 -22M86 112l8 -22', null, 4) + r(40, 112, 50, 38, 8, '#C98A5B') + ln('M42 124h46', '#9C6A3B', 4) +
      p('M65 8c-36 0-58 24-58 54 0 26 22 40 36 50h44c14-10 36-24 36-50 0-30-22-54-58-54Z', '#EE5E4D') +
      p('M65 8c-14 6-22 28-22 54 0 22 6 38 14 50h16c8-12 14-28 14-50 0-26-8-48-22-54Z', '#FFD95A', 4) + shine(32, 36, 9, 16, -20);
  } };
  ART.escavatore = { w: 238, h: 170, size: 270, idle: 'i-breathe', tap: 'react', note: 220, d: function () {
    return ln('M126 74L178 24L214 68', INK, 30) + ln('M126 74L178 24L214 68', '#FFD23F', 19) + dot(178, 24, 6, '#3A4654') +
      p('M198 62h32l-6 34q-13 9-28 -1Z', '#B9BDC4') + p('M202 96l-2 8M212 98v8M222 96l2 8', null, 4) +
      r(10, 72, 30, 40, 8, '#3A4654') + r(28, 62, 116, 62, 16, '#FFD23F') + shine(66, 72, 22, 6, 0) +
      r(40, 22, 64, 56, 12, '#FFD23F') + r(50, 30, 44, 32, 8, '#DFF3FC') + face(72, 44, 10) +
      r(12, 124, 156, 40, 20, '#3A4654') + [36, 70, 104, 140].map(function (x) { return c(x, 144, 11, '#8A919C', 4); }).join('') + ln('M26 128h128M26 160h128', '#5A6270', 3);
  } };
  ART.camion = { w: 236, h: 160, size: 270, idle: 'i-drive', tap: 'react', note: 247, d: function () {
    return p('M10 40l118 -8l18 64H22Z', '#F59A3A') + ln('M30 50l100 -6M34 72l104 -4', '#D97A26', 5) +
      r(150, 34, 74, 74, 14, '#EE5E4D') + r(164, 46, 44, 30, 8, '#DFF3FC') + face(186, 58, 10) + shine(170, 42, 8, 4, 0) +
      r(14, 96, 214, 22, 10, '#3A4654') + wheel(50, 130, 22, '#B9BDC4') + wheel(112, 130, 22, '#B9BDC4') + wheel(190, 130, 22, '#B9BDC4');
  } };
  ART.betoniera = { w: 236, h: 160, size: 270, idle: 'i-drive', tap: 'react', note: 196, d: function () {
    return p('M14 92l20 -60q50 -28 104 0l12 60Z', '#E9EEF3') + G('part slide', ln('M44 40l18 50M80 26l10 64M116 30l4 60', '#7DB7F7', 8)) + shine(54, 46, 16, 5, -20) +
      G('part spin', c(150, 60, 12, '#FFD95A', 4) + ln('M150 52v16M142 60h16', INK, 3)) +
      r(158, 34, 70, 74, 14, '#5FA4F2') + r(170, 46, 42, 30, 8, '#DFF3FC') + face(191, 58, 10) +
      r(10, 96, 218, 22, 10, '#3A4654') + wheel(48, 130, 22, '#B9BDC4') + wheel(110, 130, 22, '#B9BDC4') + wheel(192, 130, 22, '#B9BDC4');
  } };
  ART.rullo = { w: 222, h: 160, size: 250, idle: 'i-drive', tap: 'react', note: 175, d: function () {
    return G('part spin', c(56, 112, 42, '#B9BDC4') + ln('M56 76v72M20 112h72', '#8A919C', 6)) + c(56, 112, 42, 'none') +
      r(84, 52, 120, 56, 14, '#8DD68A') + r(112, 14, 66, 50, 12, '#8DD68A') + r(122, 22, 46, 30, 8, '#DFF3FC') + face(145, 34, 10) +
      p('M60 72h44', null, 7) + c(176, 128, 24, '#2B323B') + dot(176, 128, 7, '#B9BDC4') + shine(108, 62, 14, 5, 0);
  } };
  ART.carriola = { w: 170, h: 112, size: 160, idle: 'i-breathe', tap: 'react', note: 330, d: function () {
    return p('M118 50l42 -16', null, 7) + p('M18 34h104l-14 44H38Z', '#EE5E4D') + p('M28 34q46 -30 92 0Z', '#E0B07A', 4) + shine(48, 46, 12, 4, 0) +
      ln('M100 76l8 26', INK, 6) + c(30, 94, 15, '#2B323B') + dot(30, 94, 5, '#B9BDC4');
  } };
  ART.mattoni = { w: 132, h: 104, size: 130, idle: 'i-breathe', tap: 'react', note: 262, d: function () {
    var s = '', rows = [[8, 72, 3], [29, 44, 2], [50, 16, 1]];
    rows.forEach(function (rw) { for (var i = 0; i < rw[2]; i++) s += r(rw[0] + i * 42, rw[1], 38, 26, 5, '#E2705A', 4) + ln('M' + (rw[0] + i * 42 + 7) + ' ' + (rw[1] + 8) + 'h14', '#F7A08C', 3); });
    return s;
  } };
  ART.secchio = { w: 100, h: 112, size: 100, idle: 'i-sway', tap: 'react', note: 440, d: function () {
    return p('M20 32q30 -32 60 0', null, 5) + p('M14 38h72l-8 62q-1 6 -8 6H30q-7 0 -8 -6Z', '#7DB7F7') + e(50, 38, 36, 9, '#E0B07A', 4) + shine(30, 60, 5, 14, 0);
  } };
  ART.cono = { w: 90, h: 112, size: 95, idle: 'i-sway', tap: 'react', note: 523, d: function () {
    return p('M45 8l24 82H21Z', '#F59A3A') + p('M36 38h18l4 13H32Z', '#fff', 3) + p('M29 62h32l4 13H25Z', '#fff', 3) + r(8, 88, 74, 14, 7, '#E07D25');
  } };
  ART.elicottero = { w: 222, h: 130, size: 230, idle: 'i-float', tap: 'twirl', note: 659, d: function () {
    return ln('M60 72H16', INK, 14) + ln('M60 72H16', '#2E9AA1', 7) + G('part rotor', ln('M4 66h28', INK, 6)) +
      e(116, 76, 58, 38, '#4FC3C7') + e(134, 68, 26, 20, '#DFF3FC', 4) + eyes(126, 142, 66, 4) + smile(134, 76, 5) + shine(96, 58, 14, 6) +
      p('M78 118h82M92 106v12M146 106v12', null, 5) + p('M116 38V22', null, 6) + G('part rotor', ln('M46 20h142', INK, 9) + ln('M46 20h142', '#B9BDC4', 4));
  } };

  /* where the feet are, as a share of the drawing's height: things that stand are placed with their feet on the surface */
  var FOOT = { orsetto: 0.95, dinosauro: 0.96, gatto: 0.96, cane: 0.95, razzo: 0.99, trenino: 0.97, macchinina: 0.98, palla: 0.92, uccellino: 0.92, pianta: 1, lampada: 0.97, libri: 0.94,
    locomotiva: 0.97, vagone: 0.98, carromerci: 0.98, valigia: 0.99, carrello: 0.98, escavatore: 0.965, camion: 0.95, betoniera: 0.95, rullo: 0.96, carriola: 0.96, mattoni: 0.92, secchio: 0.95, cono: 0.92 };

  /* names: [Italian with article, Italian plural, English with article, English plural] */
  var NAMES = {
    locomotiva: ['la locomotiva', 'locomotive', 'the engine', 'engines'], vagone: ['il vagone', 'vagoni', 'the carriage', 'carriages'], carromerci: ['il carro merci', 'carri merci', 'the freight wagon', 'freight wagons'],
    valigia: ['la valigia', 'valigie', 'the suitcase', 'suitcases'], carrello: ['il carrello', 'carrelli', 'the trolley', 'trolleys'], mongolfiera: ['la mongolfiera', 'mongolfiere', 'the hot-air balloon', 'hot-air balloons'],
    escavatore: ["l'escavatore", 'escavatori', 'the digger', 'diggers'], camion: ['il camion', 'camion', 'the dump truck', 'dump trucks'], betoniera: ['la betoniera', 'betoniere', 'the cement mixer', 'cement mixers'],
    rullo: ['il rullo', 'rulli', 'the road roller', 'road rollers'], carriola: ['la carriola', 'carriole', 'the wheelbarrow', 'wheelbarrows'], mattoni: ['i mattoni', 'mucchi di mattoni', 'the bricks', 'piles of bricks'],
    secchio: ['il secchio', 'secchi', 'the bucket', 'buckets'], cono: ['il cono', 'coni', 'the cone', 'cones'], elicottero: ["l'elicottero", 'elicotteri', 'the helicopter', 'helicopters'],
    uccellino: ["l'uccellino", 'uccellini', 'the bird', 'birds'], nuvola: ['la nuvola', 'nuvole', 'the cloud', 'clouds'], sole: ['il sole', 'soli', 'the sun', 'suns'], aereo: ["l'aereo", 'aerei', 'the plane', 'planes'],
    orsetto: ["l'orsetto", 'orsetti', 'the teddy bear', 'teddy bears'], gatto: ['il gatto', 'gatti', 'the cat', 'cats'], cane: ['il cane', 'cani', 'the dog', 'dogs'], palla: ['il pallone', 'palloni', 'the ball', 'balls'],
    macchinina: ['la macchinina', 'macchinine', 'the toy car', 'toy cars'], trenino: ['il trenino', 'trenini', 'the toy train', 'toy trains'], dinosauro: ['il dinosauro', 'dinosauri', 'the dinosaur', 'dinosaurs'],
    lampada: ['la lampada', 'lampade', 'the lamp', 'lamps'], libri: ['i libri', 'pile di libri', 'the books', 'stacks of books'], pianta: ['la pianta', 'piante', 'the plant', 'plants'],
    quadro: ['il quadro', 'quadri', 'the picture', 'pictures'], stella: ['la stella', 'stelle', 'the star', 'stars'], luna: ['la luna', 'lune', 'the moon', 'moons'], arcobaleno: ["l'arcobaleno", 'arcobaleni', 'the rainbow', 'rainbows'],
    razzo: ['il razzo', 'razzi', 'the rocket', 'rockets'], palloncino: ['il palloncino', 'palloncini', 'the balloon', 'balloons'], tappeto: ['il tappeto', 'tappeti', 'the rug', 'rugs']
  };

  /* ====== The station ====== */
  function stazione() {
    var s = '<defs><linearGradient id="stSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#BFE6FF"/><stop offset="1" stop-color="#EAF7FF"/></linearGradient>' +
      '<linearGradient id="stStone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EDE3D3"/><stop offset="1" stop-color="#D9C9B2"/></linearGradient>' +
      '<linearGradient id="stWall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE9C8"/><stop offset="1" stop-color="#F6D29E"/></linearGradient></defs>', i, x;
    s += '<rect x="-400" y="-400" width="1800" height="2120" fill="url(#stSky)"/>';
    s += soft('M-400 640q260-120 520-40t520-20 760 40V800H-400Z', '#C6E8AE') + soft('M-400 700q300-80 600-10t600 0 600 20V820H-400Z', '#A9D98F');
    s += G('rm cloud', soft('M120 170q0-24 28-24t28 24q24 0 24 20t-30 20h-50q-28 0-28-20t28-20Z', '#fff', .9)) + G('rm cloud', soft('M470 100q0-20 24-20t24 20q20 0 20 16t-26 16h-42q-24 0-24-16t24-16Z', '#fff', .85), ' style="animation-delay:-8s"');
    // the station building, with its clock
    s += r(560, 360, 420, 420, 16, 'url(#stWall)') + p('M536 374L770 252L1004 374Z', '#EE5E4D') + ln('M592 354L770 266L948 354', '#C7402F', 6);
    s += c(770, 332, 42, '#fff') + G('rm hand', ln('M770 332V302', INK, 6)) + ln('M770 332h20', INK, 6) + dot(770, 332, 6);
    s += r(616, 468, 92, 112, 14, '#DFF3FC') + r(832, 468, 92, 112, 14, '#DFF3FC') + p('M662 468v112M616 524h92M878 468v112M832 524h92', null, 4);
    s += r(722, 610, 96, 170, 16, '#C98A5B') + dot(800, 700, 6, '#FFD95A');
    s += r(606, 580, 112, 22, 6, '#C98A5B') + r(822, 580, 112, 22, 6, '#C98A5B') + [622, 646, 670, 694, 838, 862, 886, 910].map(function (q, n) { return dot(q, 574, 9, ['#EE5E4D', '#FFD95A', '#F7A8B8', '#7DB7F7'][n % 4]); }).join('');
    s += r(546, 640, 12, 140, 5, '#3A4654') + c(552, 630, 18, '#FFE9A8');
    // canopy over the platform and the signal
    s += [60, 300, 500].map(function (q) { return r(q - 8, 590, 16, 186, 6, '#8A919C'); }).join('') + r(16, 556, 532, 40, 14, '#5FA4F2') + ln('M30 568h504', '#9CCBF7', 5);
    s += r(26, 600, 14, 176, 6, '#3A4654') + r(8, 520, 50, 92, 14, '#3A4654') + G('rm sig', dot(33, 545, 12, '#EE5E4D')) + dot(33, 585, 12, '#4FAE57');
    // platform with its yellow safety line
    s += '<rect x="-20" y="772" width="1040" height="190" fill="url(#stStone)" stroke="' + INK + '" stroke-width="5"/>';
    for (x = 80; x < 1000; x += 120) s += ln('M' + x + ' 780v170', '#CDBBA2', 4);
    s += ln('M0 944h1000', '#FFD95A', 10);
    // tracks: ballast, sleepers, rail
    s += '<rect x="-20" y="962" width="1040" height="270" fill="#CDBBA6"/>';
    for (i = 0; i < 60; i++) s += dot((i * 173) % 1000, 990 + (i * 97) % 220, 4 + i % 3, i % 2 ? '#B9A58E' : '#DED0BE');
    for (x = 10; x < 1000; x += 105) s += r(x, 1150, 70, 26, 6, '#9C6A3B', 4);
    s += '<rect x="-20" y="1140" width="1040" height="14" fill="#8A919C" stroke="' + INK + '" stroke-width="4"/>' + ln('M0 1143h1000', '#D4D9E0', 3);
    s += '<rect x="-20" y="1232" width="1040" height="120" fill="#9BD48C"/>';
    return s;
  }
  /* ====== The building site ====== */
  function cantiere() {
    var s = '<defs><linearGradient id="ctSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C8E8FF"/><stop offset="1" stop-color="#F2FAFF"/></linearGradient>' +
      '<linearGradient id="ctEarth" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EBCD9F"/><stop offset="1" stop-color="#D9AE78"/></linearGradient>' +
      '<linearGradient id="ctPit" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8E6038"/><stop offset="1" stop-color="#B58552"/></linearGradient></defs>', i, x;
    s += '<rect x="-400" y="-400" width="1800" height="2120" fill="url(#ctSky)"/>';
    s += [[60, 560, 90, 220], [170, 600, 70, 180], [640, 590, 80, 190], [740, 540, 70, 240]].map(function (b) { return '<rect x="' + b[0] + '" y="' + b[1] + '" width="' + b[2] + '" height="' + b[3] + '" fill="#C9D6E8"/>'; }).join('');
    s += G('rm cloud', soft('M520 120q0-22 26-22t26 22q22 0 22 18t-28 18h-46q-26 0-26-18t26-18Z', '#fff', .9));
    // the crane: tower, jib, swinging load
    s += r(856, 150, 34, 640, 6, '#FFD23F') + (function () { var q = ''; for (var y = 170; y < 780; y += 50) q += ln('M860 ' + y + 'l26 40', '#D9A516', 4); return q; })();
    s += r(420, 132, 580, 26, 8, '#FFD23F') + r(860, 96, 40, 40, 8, '#EE5E4D') + r(900, 160, 90, 40, 8, '#8A919C');
    s += G('rm swing', ln('M560 158v150', INK, 4) + r(500, 306, 120, 26, 6, '#E2705A'));
    // the building going up, with its scaffolding (two plank levels)
    s += [56, 206, 356].map(function (q) { return r(q, 300, 26, 490, 6, '#C9CED6'); }).join('') + r(36, 300, 410, 22, 6, '#B9BFC8');
    s += r(26, 466, 430, 18, 6, '#D9A06C') + r(26, 616, 430, 18, 6, '#D9A06C') + ln('M40 430h400M40 580h400', '#9C6A3B', 5) + [40, 240, 440].map(function (q) { return ln('M' + q + ' 420v370', '#9C6A3B', 6); }).join('');
    // ground, the dig and the road
    s += '<rect x="-20" y="780" width="1040" height="560" fill="url(#ctEarth)"/>';
    s += p('M470 806q0-14 14-14h492q14 0 14 14v186q0 16-16 16H486q-16 0-16-16Z', 'url(#ctPit)') + ln('M488 820h486', '#6E4A2A', 5);
    s += soft('M380 800q40-60 90-4Z', '#C99A62');
    for (i = 0; i < 18; i++) s += dot(40 + (i * 131) % 420, 830 + (i * 67) % 200, 5, '#CFA273');
    s += '<rect x="-20" y="1050" width="1040" height="190" fill="#7D838D" stroke="' + INK + '" stroke-width="5"/>';
    for (x = 476; x < 980; x += 52) s += r(x, 1022, 52, 18, 4, Math.round((x - 476) / 52) % 2 ? '#fff' : '#EE5E4D', 3);
    s += r(462, 1012, 14, 40, 4, '#8A919C', 3) + r(986, 1012, 14, 40, 4, '#8A919C', 3) + G('rm sig', dot(469, 1006, 9, '#FFD23F'));
    for (x = 20; x < 1000; x += 160) s += r(x, 1140, 90, 12, 6, '#F4F5F7', 0);
    s += '<rect x="-20" y="1240" width="1040" height="120" fill="#E3BE8A"/>';
    return s;
  }

  /* ====== The scenes: zones (where things go), the free places inside each zone, what belongs where ======
     A zone is a set of rectangles. «base» zones hold things that stand: slots are [x, y of the surface].
     Other zones hold things that float: slots are the centre. Zones are tried in order, so the more specific come first. */
  var SCENES = [
    { id: 'stazione', it: 'La stazione', en: 'The station', bg: stazione, zones: [
      { id: 'binari', it: 'sui binari', en: 'on the tracks', base: true, rects: [[0, 962, 1000, 270]], slots: [[140, 1146], [390, 1146], [640, 1146], [870, 1146]] },
      { id: 'banchina', it: 'sulla banchina', en: 'on the platform', base: true, rects: [[0, 772, 1000, 190]], slots: [[110, 936], [270, 936], [430, 936], [590, 936], [750, 936], [905, 936]] },
      { id: 'cielo', it: 'in cielo', en: 'in the sky', rects: [[0, 0, 1000, 250], [0, 250, 540, 300]], slots: [[130, 120], [360, 90], [600, 140], [840, 110], [220, 260], [430, 330], [160, 440]] }],
      items: [['locomotiva', 'binari'], ['vagone', 'binari'], ['carromerci', 'binari'], ['valigia', 'banchina'], ['carrello', 'banchina'], ['cane', 'banchina'], ['orsetto', 'banchina'],
        ['mongolfiera', 'cielo'], ['uccellino', 'cielo'], ['nuvola', 'cielo'], ['aereo', 'cielo'], ['sole', 'cielo']] },
    { id: 'cantiere', it: 'Il cantiere', en: 'The building site', bg: cantiere, zones: [
      { id: 'strada', it: 'sulla strada', en: 'on the road', base: true, rects: [[0, 1050, 1000, 190]], slots: [[140, 1226], [400, 1226], [650, 1226], [870, 1226]] },
      { id: 'scavo', it: 'nello scavo', en: 'in the dig', base: true, rects: [[468, 790, 524, 222]], slots: [[600, 1000], [860, 1000]] },
      { id: 'ponteggio', it: 'sul ponteggio', en: 'on the scaffolding', base: true, rects: [[20, 360, 440, 120], [20, 510, 440, 120]], slots: [[100, 467], [230, 467], [360, 467], [100, 617], [230, 617], [360, 617]] },
      { id: 'cielo', it: 'in cielo', en: 'in the sky', rects: [[0, 0, 1000, 290], [460, 290, 380, 220]], slots: [[140, 100], [340, 200], [580, 80], [760, 230], [520, 400], [700, 420]] }],
      items: [['escavatore', 'scavo'], ['carriola', 'scavo'], ['camion', 'strada'], ['betoniera', 'strada'], ['rullo', 'strada'], ['cono', 'strada'], ['mattoni', 'ponteggio'], ['secchio', 'ponteggio'],
        ['elicottero', 'cielo'], ['uccellino', 'cielo'], ['nuvola', 'cielo'], ['sole', 'cielo']] },
    { id: 'cameretta', it: 'La cameretta', en: 'The bedroom', bg: room, zones: [
      { id: 'letto', it: 'sul letto', en: 'on the bed', base: true, rects: [[90, 600, 330, 250]], slots: [[175, 752], [335, 779]] },
      { id: 'comodino', it: 'sul comodino', en: 'on the bedside table', base: true, rects: [[470, 640, 160, 230]], slots: [[549, 757]] },
      { id: 'mensola', it: 'sulla mensola', en: 'on the shelf', base: true, rects: [[690, 430, 290, 190]], slots: [[748, 603], [838, 603], [922, 603]] },
      { id: 'davanzale', it: 'sul davanzale', en: 'on the windowsill', base: true, rects: [[530, 230, 330, 200]], slots: [[604, 417], [696, 417], [788, 417]] },
      { id: 'parete', it: 'sulla parete', en: 'on the wall', rects: [[30, 100, 480, 400]], slots: [[120, 210], [270, 190], [410, 220], [170, 370], [320, 390], [450, 420]] },
      { id: 'pavimento', it: 'sul pavimento', en: 'on the floor', base: true, rects: [[0, 870, 1000, 450]], slots: [[120, 1080], [330, 1100], [540, 1080], [760, 1100], [920, 1080], [230, 1270], [480, 1280], [730, 1270]] }],
      items: [['orsetto', 'letto'], ['gatto', 'letto'], ['lampada', 'comodino'], ['libri', 'mensola'], ['pianta', 'davanzale'], ['quadro', 'parete'], ['stella', 'parete'], ['luna', 'parete'],
        ['palla', 'pavimento'], ['macchinina', 'pavimento'], ['trenino', 'pavimento'], ['dinosauro', 'pavimento'], ['cane', 'pavimento']] }
  ];
