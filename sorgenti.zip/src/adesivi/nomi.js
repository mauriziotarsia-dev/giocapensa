  /* Sticker names in the languages other than Italian and English (those two live in NAMES).
     es, pt, fr: [with article, plural, gender m | f, «one» when it is not article + name]
     de: [with article (nominative), plural, gender m | f | n, «one» (accusative) when it is not «einen/eine/ein» + name]
     ja: [name, counter]   zh-Hant, zh-Hans: [name, measure word]
     The voice says these, so they are the words a child of three would use. */
  var NOMI_L = {
    es: {
      locomotiva: ['la locomotora', 'locomotoras', 'f'], vagone: ['el vagón', 'vagones', 'm'], carromerci: ['el vagón de carga', 'vagones de carga', 'm'], valigia: ['la maleta', 'maletas', 'f'],
      carrello: ['el carrito', 'carritos', 'm'], mongolfiera: ['el globo aerostático', 'globos aerostáticos', 'm'], escavatore: ['la excavadora', 'excavadoras', 'f'], camion: ['el camión', 'camiones', 'm'],
      betoniera: ['la hormigonera', 'hormigoneras', 'f'], rullo: ['la apisonadora', 'apisonadoras', 'f'], carriola: ['la carretilla', 'carretillas', 'f'], mattoni: ['los ladrillos', 'montones de ladrillos', 'm', 'un montón de ladrillos'],
      secchio: ['el cubo', 'cubos', 'm'], cono: ['el cono', 'conos', 'm'], elicottero: ['el helicóptero', 'helicópteros', 'm'], uccellino: ['el pajarito', 'pajaritos', 'm'], nuvola: ['la nube', 'nubes', 'f'],
      sole: ['el sol', 'soles', 'm'], aereo: ['el avión', 'aviones', 'm'], orsetto: ['el osito', 'ositos', 'm'], gatto: ['el gato', 'gatos', 'm'], cane: ['el perro', 'perros', 'm'], palla: ['la pelota', 'pelotas', 'f'],
      macchinina: ['el cochecito', 'cochecitos', 'm'], trenino: ['el trencito', 'trencitos', 'm'], dinosauro: ['el dinosaurio', 'dinosaurios', 'm'], lampada: ['la lámpara', 'lámparas', 'f'],
      libri: ['los libros', 'pilas de libros', 'f', 'una pila de libros'], pianta: ['la planta', 'plantas', 'f'], quadro: ['el cuadro', 'cuadros', 'm'], stella: ['la estrella', 'estrellas', 'f'], luna: ['la luna', 'lunas', 'f'],
      arcobaleno: ['el arcoíris', 'arcoíris', 'm'], razzo: ['el cohete', 'cohetes', 'm'], palloncino: ['el globo', 'globos', 'm'], tappeto: ['la alfombra', 'alfombras', 'f'], mucca: ['la vaca', 'vacas', 'f'],
      maiale: ['el cerdo', 'cerdos', 'm'], pecora: ['la oveja', 'ovejas', 'f'], gallina: ['la gallina', 'gallinas', 'f'], pulcino: ['el pollito', 'pollitos', 'm'], anatra: ['el pato', 'patos', 'm'], rana: ['la rana', 'ranas', 'f'],
      trattore: ['el tractor', 'tractores', 'm'], fieno: ['la paca de heno', 'pacas de heno', 'f'], pterodattilo: ['el pterodáctilo', 'pterodáctilos', 'm'], triceratopo: ['el triceratops', 'triceratops', 'm'],
      stegosauro: ['el estegosaurio', 'estegosaurios', 'm'], collolungo: ['el dinosaurio de cuello largo', 'dinosaurios de cuello largo', 'm'], uovo: ['el huevo', 'huevos', 'm'], cucciolo: ['el dinosaurio bebé', 'dinosaurios bebé', 'm']
    },
    pt: {
      locomotiva: ['a locomotiva', 'locomotivas', 'f'], vagone: ['o vagão', 'vagões', 'm'], carromerci: ['o vagão de carga', 'vagões de carga', 'm'], valigia: ['a mala', 'malas', 'f'],
      carrello: ['o carrinho de malas', 'carrinhos de malas', 'm'], mongolfiera: ['o balão de ar quente', 'balões de ar quente', 'm'], escavatore: ['a escavadeira', 'escavadeiras', 'f'], camion: ['o caminhão', 'caminhões', 'm'],
      betoniera: ['a betoneira', 'betoneiras', 'f'], rullo: ['o rolo compressor', 'rolos compressores', 'm'], carriola: ['o carrinho de mão', 'carrinhos de mão', 'm'], mattoni: ['os tijolos', 'pilhas de tijolos', 'f', 'uma pilha de tijolos'],
      secchio: ['o balde', 'baldes', 'm'], cono: ['o cone', 'cones', 'm'], elicottero: ['o helicóptero', 'helicópteros', 'm'], uccellino: ['o passarinho', 'passarinhos', 'm'], nuvola: ['a nuvem', 'nuvens', 'f'],
      sole: ['o sol', 'sóis', 'm'], aereo: ['o avião', 'aviões', 'm'], orsetto: ['o ursinho', 'ursinhos', 'm'], gatto: ['o gato', 'gatos', 'm'], cane: ['o cachorro', 'cachorros', 'm'], palla: ['a bola', 'bolas', 'f'],
      macchinina: ['o carrinho', 'carrinhos', 'm'], trenino: ['o trenzinho', 'trenzinhos', 'm'], dinosauro: ['o dinossauro', 'dinossauros', 'm'], lampada: ['o abajur', 'abajures', 'm'],
      libri: ['os livros', 'pilhas de livros', 'f', 'uma pilha de livros'], pianta: ['a planta', 'plantas', 'f'], quadro: ['o quadro', 'quadros', 'm'], stella: ['a estrela', 'estrelas', 'f'], luna: ['a lua', 'luas', 'f'],
      arcobaleno: ['o arco-íris', 'arco-íris', 'm'], razzo: ['o foguete', 'foguetes', 'm'], palloncino: ['o balão de festa', 'balões de festa', 'm'], tappeto: ['o tapete', 'tapetes', 'm'], mucca: ['a vaca', 'vacas', 'f'],
      maiale: ['o porco', 'porcos', 'm'], pecora: ['a ovelha', 'ovelhas', 'f'], gallina: ['a galinha', 'galinhas', 'f'], pulcino: ['o pintinho', 'pintinhos', 'm'], anatra: ['o pato', 'patos', 'm'], rana: ['o sapo', 'sapos', 'm'],
      trattore: ['o trator', 'tratores', 'm'], fieno: ['o fardo de feno', 'fardos de feno', 'm'], pterodattilo: ['o pterodáctilo', 'pterodáctilos', 'm'], triceratopo: ['o tricerátops', 'tricerátops', 'm'],
      stegosauro: ['o estegossauro', 'estegossauros', 'm'], collolungo: ['o dinossauro pescoçudo', 'dinossauros pescoçudos', 'm'], uovo: ['o ovo', 'ovos', 'm'], cucciolo: ['o filhote de dinossauro', 'filhotes de dinossauro', 'm']
    },
    fr: {
      locomotiva: ['la locomotive', 'locomotives', 'f'], vagone: ['le wagon', 'wagons', 'm'], carromerci: ['le wagon de marchandises', 'wagons de marchandises', 'm'], valigia: ['la valise', 'valises', 'f'],
      carrello: ['le chariot', 'chariots', 'm'], mongolfiera: ['la montgolfière', 'montgolfières', 'f'], escavatore: ['la pelleteuse', 'pelleteuses', 'f'], camion: ['le camion', 'camions', 'm'],
      betoniera: ['la bétonnière', 'bétonnières', 'f'], rullo: ['le rouleau compresseur', 'rouleaux compresseurs', 'm'], carriola: ['la brouette', 'brouettes', 'f'], mattoni: ['les briques', 'tas de briques', 'm', 'un tas de briques'],
      secchio: ['le seau', 'seaux', 'm'], cono: ['le cône', 'cônes', 'm'], elicottero: ["l'hélicoptère", 'hélicoptères', 'm'], uccellino: ["l'oiseau", 'oiseaux', 'm'], nuvola: ['le nuage', 'nuages', 'm'],
      sole: ['le soleil', 'soleils', 'm'], aereo: ["l'avion", 'avions', 'm'], orsetto: ["l'ourson", 'oursons', 'm'], gatto: ['le chat', 'chats', 'm'], cane: ['le chien', 'chiens', 'm'], palla: ['le ballon', 'ballons', 'm'],
      macchinina: ['la petite voiture', 'petites voitures', 'f'], trenino: ['le petit train', 'petits trains', 'm'], dinosauro: ['le dinosaure', 'dinosaures', 'm'], lampada: ['la lampe', 'lampes', 'f'],
      libri: ['les livres', 'piles de livres', 'f', 'une pile de livres'], pianta: ['la plante', 'plantes', 'f'], quadro: ['le tableau', 'tableaux', 'm'], stella: ["l'étoile", 'étoiles', 'f'], luna: ['la lune', 'lunes', 'f'],
      arcobaleno: ["l'arc-en-ciel", 'arcs-en-ciel', 'm'], razzo: ['la fusée', 'fusées', 'f'], palloncino: ['le ballon de baudruche', 'ballons de baudruche', 'm'], tappeto: ['le tapis', 'tapis', 'm'], mucca: ['la vache', 'vaches', 'f'],
      maiale: ['le cochon', 'cochons', 'm'], pecora: ['le mouton', 'moutons', 'm'], gallina: ['la poule', 'poules', 'f'], pulcino: ['le poussin', 'poussins', 'm'], anatra: ['le canard', 'canards', 'm'], rana: ['la grenouille', 'grenouilles', 'f'],
      trattore: ['le tracteur', 'tracteurs', 'm'], fieno: ['la botte de foin', 'bottes de foin', 'f'], pterodattilo: ['le ptérodactyle', 'ptérodactyles', 'm'], triceratopo: ['le tricératops', 'tricératops', 'm'],
      stegosauro: ['le stégosaure', 'stégosaures', 'm'], collolungo: ['le dinosaure au long cou', 'dinosaures au long cou', 'm'], uovo: ["l'œuf", 'œufs', 'm'], cucciolo: ['le bébé dinosaure', 'bébés dinosaures', 'm']
    },
    de: {
      locomotiva: ['die Lokomotive', 'Lokomotiven', 'f'], vagone: ['der Waggon', 'Waggons', 'm'], carromerci: ['der Güterwagen', 'Güterwagen', 'm'], valigia: ['der Koffer', 'Koffer', 'm'],
      carrello: ['der Gepäckwagen', 'Gepäckwagen', 'm'], mongolfiera: ['der Heißluftballon', 'Heißluftballons', 'm'], escavatore: ['der Bagger', 'Bagger', 'm'], camion: ['der Kipplaster', 'Kipplaster', 'm'],
      betoniera: ['der Betonmischer', 'Betonmischer', 'm'], rullo: ['die Straßenwalze', 'Straßenwalzen', 'f'], carriola: ['die Schubkarre', 'Schubkarren', 'f'], mattoni: ['der Ziegelstapel', 'Ziegelstapel', 'm'],
      secchio: ['der Eimer', 'Eimer', 'm'], cono: ['das Hütchen', 'Hütchen', 'n'], elicottero: ['der Hubschrauber', 'Hubschrauber', 'm'], uccellino: ['der Vogel', 'Vögel', 'm'], nuvola: ['die Wolke', 'Wolken', 'f'],
      sole: ['die Sonne', 'Sonnen', 'f'], aereo: ['das Flugzeug', 'Flugzeuge', 'n'], orsetto: ['der Teddybär', 'Teddybären', 'm'], gatto: ['die Katze', 'Katzen', 'f'], cane: ['der Hund', 'Hunde', 'm'], palla: ['der Ball', 'Bälle', 'm'],
      macchinina: ['das Spielzeugauto', 'Spielzeugautos', 'n'], trenino: ['die Spielzeugeisenbahn', 'Spielzeugeisenbahnen', 'f'], dinosauro: ['der Dinosaurier', 'Dinosaurier', 'm'], lampada: ['die Lampe', 'Lampen', 'f'],
      libri: ['der Bücherstapel', 'Bücherstapel', 'm'], pianta: ['die Pflanze', 'Pflanzen', 'f'], quadro: ['das Bild', 'Bilder', 'n'], stella: ['der Stern', 'Sterne', 'm'], luna: ['der Mond', 'Monde', 'm'],
      arcobaleno: ['der Regenbogen', 'Regenbogen', 'm'], razzo: ['die Rakete', 'Raketen', 'f'], palloncino: ['der Luftballon', 'Luftballons', 'm'], tappeto: ['der Teppich', 'Teppiche', 'm'], mucca: ['die Kuh', 'Kühe', 'f'],
      maiale: ['das Schwein', 'Schweine', 'n'], pecora: ['das Schaf', 'Schafe', 'n'], gallina: ['das Huhn', 'Hühner', 'n'], pulcino: ['das Küken', 'Küken', 'n'], anatra: ['die Ente', 'Enten', 'f'], rana: ['der Frosch', 'Frösche', 'm'],
      trattore: ['der Traktor', 'Traktoren', 'm'], fieno: ['der Heuballen', 'Heuballen', 'm'], pterodattilo: ['der Flugsaurier', 'Flugsaurier', 'm'], triceratopo: ['der Triceratops', 'Triceratopse', 'm'],
      stegosauro: ['der Stegosaurus', 'Stegosaurier', 'm'], collolungo: ['der Langhals', 'Langhälse', 'm'], uovo: ['das Ei', 'Eier', 'n'], cucciolo: ['das Dinobaby', 'Dinobabys', 'n']
    },
    ja: {
      locomotiva: ['機関車', '台'], vagone: ['客車', '両'], carromerci: ['貨車', '両'], valigia: ['スーツケース', '個'], carrello: ['カート', '台'], mongolfiera: ['気球', '個'], escavatore: ['ショベルカー', '台'],
      camion: ['ダンプカー', '台'], betoniera: ['ミキサー車', '台'], rullo: ['ロードローラー', '台'], carriola: ['一輪車', '台'], mattoni: ['レンガの山', 'つ'], secchio: ['バケツ', '個'], cono: ['コーン', '個'],
      elicottero: ['ヘリコプター', '機'], uccellino: ['小鳥', '羽'], nuvola: ['雲', 'つ'], sole: ['太陽', 'つ'], aereo: ['飛行機', '機'], orsetto: ['テディベア', '個'], gatto: ['ねこ', '匹'], cane: ['いぬ', '匹'],
      palla: ['ボール', '個'], macchinina: ['ミニカー', '台'], trenino: ['おもちゃの電車', '台'], dinosauro: ['恐竜', '匹'], lampada: ['ランプ', '個'], libri: ['本の山', 'つ'], pianta: ['植木', 'つ'], quadro: ['絵', '枚'],
      stella: ['星', 'つ'], luna: ['月', 'つ'], arcobaleno: ['にじ', '本'], razzo: ['ロケット', '機'], palloncino: ['風船', '個'], tappeto: ['じゅうたん', '枚'], mucca: ['うし', '頭'], maiale: ['ぶた', '匹'],
      pecora: ['ひつじ', '匹'], gallina: ['にわとり', '羽'], pulcino: ['ひよこ', '羽'], anatra: ['アヒル', '羽'], rana: ['カエル', '匹'], trattore: ['トラクター', '台'], fieno: ['干し草', '個'],
      pterodattilo: ['プテラノドン', '匹'], triceratopo: ['トリケラトプス', '匹'], stegosauro: ['ステゴサウルス', '匹'], collolungo: ['首長竜', '匹'], uovo: ['たまご', '個'], cucciolo: ['恐竜の赤ちゃん', '匹']
    },
    'zh-Hant': {
      locomotiva: ['火車頭', '輛'], vagone: ['車廂', '節'], carromerci: ['貨車廂', '節'], valigia: ['行李箱', '個'], carrello: ['行李推車', '台'], mongolfiera: ['熱氣球', '顆'], escavatore: ['挖土機', '台'],
      camion: ['砂石車', '輛'], betoniera: ['水泥攪拌車', '輛'], rullo: ['壓路機', '台'], carriola: ['手推車', '台'], mattoni: ['磚塊', '堆'], secchio: ['水桶', '個'], cono: ['三角錐', '個'],
      elicottero: ['直升機', '架'], uccellino: ['小鳥', '隻'], nuvola: ['雲', '朵'], sole: ['太陽', '個'], aereo: ['飛機', '架'], orsetto: ['小熊', '隻'], gatto: ['貓', '隻'], cane: ['狗', '隻'],
      palla: ['球', '顆'], macchinina: ['玩具車', '輛'], trenino: ['玩具火車', '列'], dinosauro: ['恐龍', '隻'], lampada: ['檯燈', '盞'], libri: ['書', '疊'], pianta: ['盆栽', '盆'], quadro: ['畫', '幅'],
      stella: ['星星', '顆'], luna: ['月亮', '個'], arcobaleno: ['彩虹', '道'], razzo: ['火箭', '枚'], palloncino: ['氣球', '顆'], tappeto: ['地毯', '塊'], mucca: ['乳牛', '頭'], maiale: ['豬', '隻'],
      pecora: ['綿羊', '隻'], gallina: ['母雞', '隻'], pulcino: ['小雞', '隻'], anatra: ['鴨子', '隻'], rana: ['青蛙', '隻'], trattore: ['拖拉機', '台'], fieno: ['乾草', '捆'],
      pterodattilo: ['翼龍', '隻'], triceratopo: ['三角龍', '隻'], stegosauro: ['劍龍', '隻'], collolungo: ['長脖子恐龍', '隻'], uovo: ['蛋', '顆'], cucciolo: ['恐龍寶寶', '隻']
    },
    'zh-Hans': {
      locomotiva: ['火车头', '辆'], vagone: ['车厢', '节'], carromerci: ['货车厢', '节'], valigia: ['行李箱', '个'], carrello: ['行李推车', '辆'], mongolfiera: ['热气球', '个'], escavatore: ['挖掘机', '台'],
      camion: ['翻斗车', '辆'], betoniera: ['水泥搅拌车', '辆'], rullo: ['压路机', '台'], carriola: ['手推车', '辆'], mattoni: ['砖块', '堆'], secchio: ['水桶', '个'], cono: ['路锥', '个'],
      elicottero: ['直升机', '架'], uccellino: ['小鸟', '只'], nuvola: ['云', '朵'], sole: ['太阳', '个'], aereo: ['飞机', '架'], orsetto: ['小熊', '只'], gatto: ['猫', '只'], cane: ['狗', '只'],
      palla: ['球', '个'], macchinina: ['玩具车', '辆'], trenino: ['玩具火车', '列'], dinosauro: ['恐龙', '只'], lampada: ['台灯', '盏'], libri: ['书', '叠'], pianta: ['盆栽', '盆'], quadro: ['画', '幅'],
      stella: ['星星', '颗'], luna: ['月亮', '个'], arcobaleno: ['彩虹', '道'], razzo: ['火箭', '枚'], palloncino: ['气球', '个'], tappeto: ['地毯', '块'], mucca: ['奶牛', '头'], maiale: ['猪', '头'],
      pecora: ['绵羊', '只'], gallina: ['母鸡', '只'], pulcino: ['小鸡', '只'], anatra: ['鸭子', '只'], rana: ['青蛙', '只'], trattore: ['拖拉机', '台'], fieno: ['干草', '捆'],
      pterodattilo: ['翼龙', '只'], triceratopo: ['三角龙', '只'], stegosauro: ['剑龙', '只'], collolungo: ['长脖子恐龙', '只'], uovo: ['蛋', '个'], cucciolo: ['恐龙宝宝', '只']
    }
  };
