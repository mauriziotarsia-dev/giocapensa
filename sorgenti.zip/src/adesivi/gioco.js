  /* ====== The game: pick a scene, then rounds of three kinds ======
     sagome — every sticker on its own shadow;  dove — everything where it belongs;  conta — that many of each, then the green button.
     A sticker dropped in the wrong place goes back to the drawer with a soft «boing»; after two tries the right place lights up. */
  var VW = 1000, VH = 1320, sceneEl = $('scene'), tray = $('tray');
  var calm = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  var KEY = 'adesivi.scene.v1', prog = { rounds: {}, mode: '', diff: '' };
  try {
    var sv = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (sv && sv.rounds && typeof sv.rounds === 'object') Object.keys(sv.rounds).forEach(function (q) { var n = +sv.rounds[q]; if (n >= 0 && n < 1e6) prog.rounds[q] = Math.floor(n); });
    if (sv && ['sagome', 'dove', 'conta', 'posti'].indexOf(sv.mode) >= 0) prog.mode = sv.mode;
    if (sv && ['0', '1', '2'].indexOf(String(sv.diff)) >= 0) prog.diff = String(sv.diff);
  } catch (err) {}
  function saveProg() { try { localStorage.setItem(KEY, JSON.stringify(prog)); } catch (err) {} }
  function sfx(kind, n) { var X = window.SFX; if (X) X.play(kind, typeof n === 'number' ? { i: n } : {}); }
  function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (err) {} }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ---------- words, written and spoken ---------- */
  var WORDS = ['zero', 'uno', 'due', 'tre', 'quattro', 'cinque', 'sei', 'sette', 'otto', 'nove', 'dieci'];
  var WORDS_EN = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];
  function eng() { return window.OPZ ? OPZ.get('lingua') === 'en' : LANG === 'en'; }                       // the voice
  function en(spoken) { return spoken ? eng() : LANG === 'en'; }
  function name1(id, spoken) { var n = NAMES[id]; return en(spoken) ? n[2] : n[0]; }
  function bare(id, spoken) { return name1(id, spoken).replace(/^(il |lo |la |i |gli |le |the )/, '').replace(/^l'/, ''); }
  function many(id, spoken) { var n = NAMES[id]; return en(spoken) ? n[3] : n[1]; }
  function numWord(n, spoken) { return (en(spoken) ? WORDS_EN : WORDS)[n] || String(n); }
  var UNA_APOS = { anatra: 1 };
  function one(id) { var a = NAMES[id][0]; return UNA_APOS[id] ? "un'" : /^la /.test(a) ? 'una ' : /^lo /.test(a) ? 'uno ' : 'un '; }
  function howmany(id, n, spoken) { return n === 1 ? (en(spoken) ? 'one ' + bare(id, true) : one(id) + bare(id, true)) : numWord(n, spoken) + ' ' + many(id, spoken); }
  function written(id, n) { return n + ' ' + (n === 1 ? bare(id) : many(id)); }
  function ztext(z, spoken) { return en(spoken) ? z.en : z.it; }
  function voiceOn() { return !window.OPZ || OPZ.get('voce'); }
  function speak(text) {
    if (!voiceOn() || !text) return;
    try {
      var ss = window.speechSynthesis; if (!ss) return; ss.cancel();
      var want = eng() ? /^en/i : /^it/i, u = new SpeechSynthesisUtterance(text), vs = (ss.getVoices() || []).filter(function (v) { return want.test(v.lang); });
      u.lang = eng() ? 'en-GB' : 'it-IT'; u.rate = 0.9; u.pitch = 1.1; if (vs.length) u.voice = vs[0]; ss.speak(u);
    } catch (err) {}
  }
  function say(it, enText) { speak(eng() ? enText : it); }

  /* ---------- geometry ---------- */
  function box(id) { var a = ART[id], s = a.size / a.w; return { w: a.w * s, h: a.h * s, s: s }; }
  var FRAME = {};
  function frame(id) {                                            // the drawing's real box, measured once: tiles and cards show it centred and whole
    if (FRAME[id]) return FRAME[id];
    var a = ART[id], ns = 'http://www.w3.org/2000/svg', svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('style', 'position:absolute;left:-9999px;top:0;width:300px;height:300px'); svg.innerHTML = '<g>' + a.d() + '</g>';
    document.body.appendChild(svg); Array.prototype.forEach.call(svg.querySelectorAll('.glow'), function (g) { g.remove(); });
    var bb; try { bb = svg.firstChild.getBBox(); } catch (err) { bb = null; } svg.remove();
    FRAME[id] = bb && bb.width ? [Math.round(bb.x - 5), Math.round(bb.y - 5), Math.round(bb.width + 10), Math.round(bb.height + 10)].join(' ') : '0 0 ' + a.w + ' ' + a.h;
    return FRAME[id];
  }
  function pic(id) { return '<svg viewBox="' + frame(id) + '" aria-hidden="true">' + ART[id].d() + '</svg>'; }
  function geom() { var b = sceneEl.getBoundingClientRect(), s = Math.min(b.width / VW, b.height / VH); return { s: s, ox: b.left + (b.width - VW * s) / 2, oy: b.top + (b.height - VH * s) / 2 }; }
  function toScene(x, y) { var g = geom(); return { x: (x - g.ox) / g.s, y: (y - g.oy) / g.s }; }
  function inZone(z, x, y) { return z.rects.some(function (q) { return x >= q[0] && x <= q[0] + q[2] && y >= q[1] && y <= q[1] + q[3]; }); }
  function centreFor(id, z, slot) { var b = box(id), k = z.scale || 1; return z.base ? { x: slot[0], y: slot[1] - b.h * k * ((FOOT[id] || 0.97) - 0.5) } : { x: slot[0], y: slot[1] }; }

  /* ---------- state ---------- */
  var SC = null, R = null, placed = [], seq = 0, layer, silG, hintG, fx, drag = null, pend = null, locked = false;
  function zone(id) { var all = SC.zones.concat(SC.spots || []); for (var i = 0; i < all.length; i++) if (all[i].id === id) return all[i]; return null; }
  function zoneAt(x, y) { for (var i = 0; i < SC.zones.length; i++) if (inZone(SC.zones[i], x, y)) return SC.zones[i]; return null; }
  function homeOf(id) { for (var i = 0; i < SC.items.length; i++) if (SC.items[i][0] === id) return SC.items[i][1]; return null; }
  function freeSlot(z, near) {                                    // the free place of the zone closest to where the finger let go
    var used = R.used[z.id] || {}, best = -1, bd = 1e9;
    z.slots.forEach(function (sl, i) { if (used[i]) return; var c0 = centreFor('palla', z, sl), d = near ? Math.hypot(c0.x - near.x, c0.y - near.y) : i; if (d < bd) { bd = d; best = i; } });
    return best;
  }
  function take(z, i, n) { (R.used[z.id] = R.used[z.id] || {})[i] = n; }

  /* ---------- a new round ---------- */
  function newRound() {
    var MODES = SC.spots && SC.spots.length ? ['sagome', 'dove', 'conta', 'posti'] : ['sagome', 'dove', 'conta'];
    var r = prog.rounds[SC.id] || 0, mode = MODES.indexOf(prog.mode) >= 0 ? prog.mode : MODES[r % MODES.length], lvl = prog.diff !== '' ? +prog.diff : Math.floor(r / MODES.length), pool = shuffle(SC.items.slice()), k, i, it, z, sl;   // chosen by the grown-up, or taking turns and growing
    var others = []; SCENES.forEach(function (o) { if (o !== SC) o.items.forEach(function (q) { if (!homeOf(q[0]) && others.indexOf(q[0]) < 0) others.push(q[0]); }); });
    R = { mode: mode, lvl: lvl, used: {}, wrong: {}, targets: [], tray: [], req: [], steps: [], step: 0 }; placed = [];
    if (mode === 'sagome') {
      k = Math.min(pool.length, 3 + Math.min(lvl, 3));
      for (i = 0; i < pool.length && R.targets.length < k; i++) {
        it = pool[i]; z = zone(it[1]); sl = freeSlot(z, null); if (sl < 0) continue;
        take(z, sl, -1); var c0 = centreFor(it[0], z, z.slots[sl]); R.targets.push({ id: it[0], z: z.id, slot: sl, x: c0.x, y: c0.y, done: false });
      }
      R.tray = R.targets.map(function (t) { return { id: t.id, once: true }; });
    } else if (mode === 'dove') {
      k = Math.min(pool.length, 4 + Math.min(lvl, 3));
      R.tray = pool.slice(0, k).map(function (q) { return { id: q[0], once: true }; });
    } else if (mode === 'posti') {
      var used = {}, spots = shuffle(SC.spots.slice()), want = Math.min(3 + Math.min(lvl, 1), 4);
      for (i = 0; R.steps.length < want && i < spots.length * 3; i++) {
        var sp = spots[i % spots.length], cand = shuffle(sp.movers.slice()).filter(function (m) { return !used[m]; });
        if (!cand.length) continue; used[cand[0]] = 1; R.steps.push({ id: cand[0], spot: sp.id });
      }
      R.tray = R.steps.map(function (q) { return { id: q.id, once: true }; });
      var extra = []; SC.spots.forEach(function (sp2) { sp2.movers.forEach(function (m) { if (!used[m] && extra.indexOf(m) < 0) extra.push(m); }); });
      shuffle(extra).slice(0, 1 + Math.min(lvl, 1)).forEach(function (m) { R.tray.push({ id: m, once: true, extra: true }); });   // one or two that nobody asked for
    } else {
      var kinds = lvl < 2 ? 1 : 2;
      for (i = 0; i < pool.length && R.req.length < kinds; i++) {
        it = pool[i]; z = zone(it[1]); if (z.slots.length < 4) continue;                            // counting needs room: a small place would give the answer away
        if (R.req.some(function (q) { return q.z === it[1]; }) && z.slots.length < 6) continue;
        var cap = Math.min(5, z.slots.length - 1 - (R.req.filter(function (q) { return q.z === it[1]; }).reduce(function (a2, q) { return a2 + q.n; }, 0))), top = Math.min(cap, 2 + lvl);   // always room for one too many
        if (top < 1) continue; var n = Math.max(1, Math.min(top, 1 + Math.floor(Math.random() * top) + (lvl > 0 ? 1 : 0)));
        R.req.push({ id: it[0], z: it[1], n: Math.min(n, top), ok: false });
      }
      R.tray = R.req.map(function (q) { return { id: q.id, once: false }; });
      pool.filter(function (q) { return !R.req.some(function (x2) { return x2.id === q[0]; }); }).slice(0, 2).forEach(function (q) { R.tray.push({ id: q[0], once: false }); });
    }
    if (mode !== 'conta' && mode !== 'posti' && lvl >= 1) shuffle(others).slice(0, Math.min(2, lvl)).forEach(function (id) { R.tray.push({ id: id, once: true, stranger: true }); });   // things that do not belong to this scene
    shuffle(R.tray);
    hideResult(); render();
    if (mode === 'sagome') say('Metti ogni adesivo sulla sua ombra!', 'Put each sticker on its shadow!');
    else if (mode === 'dove') say('Ogni cosa al suo posto!', 'Everything in its place!');
    else if (mode === 'posti') speak(stepText(true));
    else speak(R.req.map(function (q) { return howmany(q.id, q.n, true) + ' ' + ztext(zone(q.z), true); }).join(eng() ? ' and ' : ' e '));
  }

  function stepText(spoken) {                                     // «Metti il gatto sotto il letto.»
    var s = R.steps[R.step]; if (!s) return ''; var z = zone(s.spot);
    return en(spoken) ? 'Put ' + name1(s.id, spoken) + ' ' + z.en + '.' : 'Metti ' + name1(s.id, spoken) + ' ' + z.it + '.';
  }
  function showStep() {
    var s = R.steps[R.step]; if (!s) return;
    $('cards').innerHTML = '<button class="taskcard m-posti" type="button" id="stepCard"><span class="spic">' + pic(s.id) + '</span><span class="big">' + stepText(false) + '</span></button>';
    $('say').textContent = R.steps.length > 1 ? L('Richiesta ' + (R.step + 1) + ' di ' + R.steps.length, 'Request ' + (R.step + 1) + ' of ' + R.steps.length) : '';
  }

  /* ---------- drawing ---------- */
  var MODE_ICON = {
    sagome: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 19c-2 0-3-2-2-4l3-7c1-2 3-2 4 0l1 2 2-3c1-1 3-1 3 1l2 9c0 1-1 2-2 2Z" fill="currentColor" opacity=".35" stroke="currentColor" stroke-width="1.8" stroke-dasharray="3 2"/></svg>',
    dove: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/><path d="M12 13v4M10 15l2 2 2-2"/></svg>',
    conta: '<svg viewBox="0 0 24 24" aria-hidden="true"><text x="12" y="17" text-anchor="middle" font-size="12" font-weight="900" fill="currentColor">123</text></svg>',
    posti: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h16"/><path d="M12 3v6M9 6l3 3 3-3"/><path d="M12 21v-6M9 18l3-3 3 3"/></svg>'
  };
  function markup(it, fresh) {
    var b0 = box(it.id), k = it.k || 1, b = { w: b0.w * k, h: b0.h * k, s: b0.s * k }, a = ART[it.id], z = zone(it.z);
    return '<g class="set" data-n="' + it.n + '" style="--d:' + (-(it.n * 0.73 % 4)).toFixed(2) + 's" transform="translate(' + (it.x - b.w / 2).toFixed(1) + ',' + (it.y - b.h / 2).toFixed(1) + ') scale(' + b.s.toFixed(3) + ')">' +
      (z && z.base ? '<ellipse cx="' + (a.w / 2) + '" cy="' + (a.h * (FOOT[it.id] || 0.97)).toFixed(1) + '" rx="' + (a.w * 0.36).toFixed(1) + '" ry="6.5" fill="' + INK + '" opacity=".2"/>' : '') +
      '<g class="pop' + (fresh ? ' in' : '') + '"><g class="idle ' + (a.idle || '') + '">' + a.d() + '</g></g></g>';
  }
  function render() {
    sceneEl.innerHTML = '<defs><filter id="silF"><feColorMatrix type="matrix" values="0 0 0 0 0.29  0 0 0 0 0.23  0 0 0 0 0.32  0 0 0 0.38 0"/></filter></defs><g id="bgG">' + SC.bg() + '</g><g id="silG"></g><g id="hintG"></g><g id="layer"></g><g id="fx"></g>';
    sceneEl.setAttribute('aria-label', L(SC.it, SC.en));
    silG = sceneEl.querySelector('#silG'); hintG = sceneEl.querySelector('#hintG'); layer = sceneEl.querySelector('#layer'); fx = sceneEl.querySelector('#fx');
    if (R.mode === 'sagome') silG.innerHTML = R.targets.map(function (t, i) { var b = box(t.id); return '<ellipse class="halo" data-h="' + i + '" cx="' + t.x.toFixed(0) + '" cy="' + t.y.toFixed(0) + '" rx="' + (b.w * 0.56).toFixed(0) + '" ry="' + (b.h * 0.54).toFixed(0) + '" style="--d:' + (-i * 0.4) + 's"/>' + '<g class="silh" data-t="' + i + '" data-id="' + t.id + '" transform="translate(' + (t.x - b.w / 2).toFixed(1) + ',' + (t.y - b.h / 2).toFixed(1) + ') scale(' + b.s.toFixed(3) + ')" filter="url(#silF)">' + ART[t.id].d() + '</g>'; }).join('');
    $('title').textContent = L(SC.it, SC.en); $('modeChip').innerHTML = MODE_ICON[R.mode];
    $('modeChip').setAttribute('aria-label', R.mode === 'sagome' ? L('Ombre', 'Shadows') : R.mode === 'dove' ? L('Ogni cosa al suo posto', 'Everything in its place') : R.mode === 'posti' ? L('Sopra, sotto, dentro', 'On, under, inside') : L('Conta e metti', 'Count and place'));
    var t = $('task');
    if (R.mode === 'conta') {
      t.className = 'task conta';
      $('cards').innerHTML = R.req.map(function (q, i) { return '<button class="numcard" type="button" data-r="' + i + '" aria-label="' + written(q.id, q.n) + ' ' + ztext(zone(q.z)) + '"><span class="num">' + q.n + '</span><span class="pic">' + pic(q.id) + '</span><span class="zl">' + ztext(zone(q.z)) + '</span></button>'; }).join('');
      $('say').textContent = L('Metti ' + R.req.map(function (q) { return written(q.id, q.n) + ' ' + ztext(zone(q.z)); }).join(' e ') + ', poi premi il tasto verde.', 'Put ' + R.req.map(function (q) { return written(q.id, q.n) + ' ' + ztext(zone(q.z)); }).join(' and ') + ', then press the green button.');
      $('btnOk').hidden = false; $('btnOk').disabled = false;
    } else if (R.mode === 'posti') {
      t.className = 'task'; $('btnOk').hidden = true; showStep();
    } else {
      t.className = 'task';
      $('cards').innerHTML = '<div class="taskcard m-' + R.mode + '"><span class="mic">' + MODE_ICON[R.mode] + '</span><span>' + (R.mode === 'sagome' ? L('Metti ogni adesivo sulla sua ombra.', 'Put each sticker on its shadow.') : L('Metti ogni adesivo nel posto giusto.', 'Put each sticker where it belongs.')) + '</span></div>';
      $('say').textContent = R.tray.some(function (q) { return q.stranger; }) ? L('Attenzione: qualche adesivo non è di questa scena.', 'Careful: some stickers do not belong in this scene.') : '';
      $('btnOk').hidden = true;
    }
    tray.innerHTML = R.tray.map(function (q, i) { return '<button class="tile" type="button" data-i="' + i + '" data-id="' + q.id + '" aria-label="' + bare(q.id) + '">' + pic(q.id) + '</button>'; }).join('');
    layoutTray(); locked = false;
  }
  function sparkle(x, y) {
    if (calm) return; var h = '', i, a2, cols = ['#FFD95A', '#F59A3A', '#7DB7F7', '#8DD68A'];
    for (i = 0; i < 8; i++) { a2 = i * 0.785 + 0.3; h += '<g class="spark" style="--dx:' + (Math.cos(a2) * 92).toFixed(0) + 'px;--dy:' + (Math.sin(a2) * 92).toFixed(0) + 'px">' + star(x, y, 17, cols[i % 4], 3.5) + '</g>'; }
    fx.insertAdjacentHTML('beforeend', '<g>' + h + '</g>'); var g = fx.lastElementChild; setTimeout(function () { if (g.parentNode) g.parentNode.removeChild(g); }, 760);
  }
  function dust(it) {
    if (calm) return; var b = box(it.id), fy = it.y - b.h / 2 + b.h * (FOOT[it.id] || 0.97), h = '';
    [-1, -0.45, 0.45, 1].forEach(function (k) { h += '<circle class="dust" cx="' + (it.x + k * b.w * 0.32).toFixed(0) + '" cy="' + (fy - 6).toFixed(0) + '" r="' + (9 + Math.abs(k) * 5).toFixed(0) + '" style="--dx:' + (k * 26).toFixed(0) + 'px"/>'; });
    fx.insertAdjacentHTML('beforeend', '<g>' + h + '</g>'); var g2 = fx.lastElementChild; setTimeout(function () { if (g2.parentNode) g2.parentNode.removeChild(g2); }, 700);
  }
  function hop(n) { var el = layer.querySelector('[data-n="' + n + '"] .pop'); if (!el) return; el.classList.remove('in', 'react', 'twirl'); void el.getBoundingClientRect(); el.classList.add('react'); }
  function hint(id) {                                            // after two wrong tries: the shadow, or the zone, lights up for a moment
    var h = '';
    if (R.mode === 'sagome') R.targets.forEach(function (t, i) { if (t.id === id && !t.done) { var el = silG.querySelector('[data-t="' + i + '"]'); if (el) { el.classList.remove('glowme'); void el.getBoundingClientRect(); el.classList.add('glowme'); } } });
    else { var z = R.mode === 'posti' ? zone(R.steps[R.step].spot) : zone(homeOf(id)); if (!z) return; h = z.rects.map(function (q) { return '<rect class="zhint" x="' + (q[0] + 10) + '" y="' + (q[1] + 10) + '" width="' + (q[2] - 20) + '" height="' + (q[3] - 20) + '" rx="26"/>'; }).join(''); hintG.innerHTML = h; setTimeout(function () { if (hintG) hintG.innerHTML = ''; }, 2600); }
  }

  /* ---------- the drawer: pages turned with the two arrows ---------- */
  var page = 0, perPage = 4;
  function goPage(n, instant) {
    var pages = Math.max(1, Math.ceil(tray.children.length / perPage)); page = Math.max(0, Math.min(pages - 1, n));
    var first = tray.children[page * perPage], left = first ? first.offsetLeft - 8 : 0;
    try { tray.scrollTo({ left: left, behavior: instant || calm ? 'auto' : 'smooth' }); } catch (err) { tray.scrollLeft = left; }
    $('btnTrayPrev').disabled = page === 0; $('btnTrayNext').disabled = page >= pages - 1;
  }
  function layoutTray() {
    var inner = tray.clientWidth - 16, gap = 8; if (inner < 100) return;
    perPage = Math.max(3, Math.floor((inner + gap) / (66 + gap))); tray.style.setProperty('--tile', ((inner - (perPage - 1) * gap) / perPage).toFixed(2) + 'px');
    page = 0; goPage(0, true);
  }
  $('btnTrayPrev').addEventListener('click', function () { goPage(page - 1); sfx('page'); });
  $('btnTrayNext').addEventListener('click', function () { goPage(page + 1); sfx('page'); });
  window.addEventListener('resize', function () { if (SC) layoutTray(); });

  /* ---------- dragging ---------- */
  function overTray(y) { return y > $('traywrap').getBoundingClientRect().top + 6; }
  function lift(id, x, y, from, pid, tileI) {
    var b = box(id), g = geom(), a = ART[id], el = document.createElement('div');
    el.className = 'fly'; el.style.width = (b.w * g.s) + 'px'; el.style.height = (b.h * g.s) + 'px';
    el.innerHTML = '<svg viewBox="0 0 ' + a.w + ' ' + a.h + '">' + a.d() + '</svg>'; document.body.appendChild(el);
    drag = { id: id, el: el, w: b.w * g.s, h: b.h * g.s, from: from, moved: !!from, pid: pid, tileI: tileI, sx: x, sy: y };
    sfx('pick'); follow(x, y);
  }
  function follow(x, y) {
    drag.el.style.transform = 'translate3d(' + (x - drag.w / 2) + 'px,' + (y - drag.h / 2 - 26) + 'px,0) rotate(' + Math.max(-9, Math.min(9, (x - (drag.lx == null ? x : drag.lx)) * 1.2)) + 'deg)';
    drag.lx = x; drag.x = x; drag.y = y; tray.classList.toggle('bin', !!drag.from && overTray(y));
  }
  function flyHome(d) {                                           // back to its tile in the drawer, shrinking
    var tile = d.tileI != null ? tray.querySelector('[data-i="' + d.tileI + '"]') : null, el = d.el;
    if (tile && !calm) { var r2 = tile.getBoundingClientRect(); el.classList.add('back'); el.style.transform = 'translate3d(' + (r2.left + r2.width / 2 - d.w / 2) + 'px,' + (r2.top + r2.height / 2 - d.h / 2) + 'px,0) scale(.3)'; setTimeout(function () { el.remove(); }, 320); }
    else { el.classList.add('back'); el.style.transform += ' scale(.3)'; setTimeout(function () { el.remove(); }, 300); }
  }
  function distToZone(z, x, y) { var best = 1e9; z.rects.forEach(function (q) { var dx = Math.max(q[0] - x, 0, x - (q[0] + q[2])), dy = Math.max(q[1] - y, 0, y - (q[1] + q[3])); best = Math.min(best, Math.hypot(dx, dy)); }); return best; }
  function feet(id, z, pt) { if (!z.base) return pt; var b = box(id), k = z.scale || 1; return { x: pt.x, y: pt.y + b.h * k * ((FOOT[id] || 0.97) - 0.5) }; }
  function closeTo(id, z, pt, rivals) {                            // the middle or the feet inside the place, or near it and not inside another place
    var f = feet(id, z, pt), b = box(id), k = z.scale || 1, i;
    if (inZone(z, pt.x, pt.y) || inZone(z, f.x, f.y)) return true;
    for (i = 0; i < rivals.length; i++) if (rivals[i] !== z && (inZone(rivals[i], pt.x, pt.y) || inZone(rivals[i], f.x, f.y))) return false;
    return Math.min(distToZone(z, pt.x, pt.y), distToZone(z, f.x, f.y)) <= 70 + 0.3 * Math.max(b.w, b.h) * k;
  }
  function judge(id, pt) {
    var z, sl, home = homeOf(id), b = box(id);
    if (R.mode === 'sagome') {
      var best = null, bd = 1e9;
      R.targets.forEach(function (t, i) { if (t.done || t.id !== id) return; var d = Math.hypot(pt.x - t.x, pt.y - t.y); if (d < bd) { bd = d; best = i; } });
      if (best === null) return { ok: false, why: 'stranger' };
      if (bd > Math.max(b.w, b.h) * 0.8) return { ok: false, why: 'shadow' };
      var t0 = R.targets[best]; return { ok: true, z: zone(t0.z), slot: t0.slot, x: t0.x, y: t0.y, target: best };
    }
    if (R.mode === 'posti') {
      var st = R.steps[R.step]; if (!st || id !== st.id) return { ok: false, why: 'other' };
      var zp = zone(st.spot); if (!closeTo(id, zp, pt, SC.spots)) return { ok: false, why: 'zone' };
      var sp = freeSlot(zp, pt); if (sp < 0) return { ok: false, why: 'full' };
      var cp = centreFor(id, zp, zp.slots[sp]); return { ok: true, z: zp, slot: sp, x: cp.x, y: cp.y };
    }
    if (!home) return { ok: false, why: 'stranger' };
    if (R.mode === 'conta' && !R.req.some(function (q) { return q.id === id; })) return { ok: false, why: 'unwanted' };
    z = zone(home);
    if (!closeTo(id, z, pt, SC.zones)) return { ok: false, why: 'zone' };
    sl = freeSlot(z, pt); if (sl < 0) return { ok: false, why: 'full' };
    var c0 = centreFor(id, z, z.slots[sl]); return { ok: true, z: z, slot: sl, x: c0.x, y: c0.y };
  }
  function place(id, res, d) {
    var it = { n: ++seq, id: id, z: res.z.id, slot: res.slot, x: res.x, y: res.y, k: res.z.scale || 1 };
    placed.push(it); take(res.z, res.slot, it.n);
    if (res.target != null) { R.targets[res.target].done = true; var sh = silG.querySelector('[data-t="' + res.target + '"]'); if (sh) sh.classList.add('filled'); var hl = silG.querySelector('[data-h="' + res.target + '"]'); if (hl) hl.classList.add('done'); }
    layer.insertAdjacentHTML('beforeend', markup(it, true)); sparkle(it.x, it.y); if (res.z.base) dust(it); sfx('place', placed.length - 1); buzz(12);
    if (d.tileI != null && R.tray[d.tileI].once) { R.tray[d.tileI].used = true; var tile = tray.querySelector('[data-i="' + d.tileI + '"]'); if (tile) tile.classList.add('gone'); }
    if (R.mode === 'posti') { R.step++; if (R.step >= R.steps.length) { setTimeout(win, 450); return; } setTimeout(function () { showStep(); speak(stepText(true)); }, calm ? 50 : 650); speak(eng() ? 'Yes!' : 'Sì!'); return; }
    if (R.mode === 'conta') speak(numWord(placed.filter(function (p) { return p.id === id; }).length, true));
    else speak(name1(id, true) + (R.mode === 'dove' ? ', ' + ztext(res.z, true) : '') + '!');
    if (R.mode === 'sagome' && R.targets.every(function (t) { return t.done; })) setTimeout(win, 450);
    if (R.mode === 'dove' && R.tray.every(function (q) { return q.used || q.stranger; })) setTimeout(win, 450);
  }
  function unplace(it) {
    placed = placed.filter(function (p) { return p !== it; }); delete R.used[it.z][it.slot];
    var el = layer.querySelector('[data-n="' + it.n + '"]'); if (el) el.remove();
  }
  function refuse(d, res) {
    flyHome(d); sfx('no'); buzz(14);
    var tile = d.tileI != null ? tray.querySelector('[data-i="' + d.tileI + '"]') : null;
    if (res.why === 'stranger') { say('Questo non è di questa scena.', 'This one does not belong here.'); if (tile) { tile.classList.remove('nope'); void tile.offsetWidth; tile.classList.add('nope'); } return; }
    if (res.why === 'unwanted') { say('Questo non serve.', 'This one is not needed.'); return; }
    if (res.why === 'other') { var s0 = R.steps[R.step]; speak(eng() ? 'Not this one. ' + stepText(true) : 'Non questo. ' + stepText(true)); return; }
    if (res.why === 'full') { say('Qui non c\'è più posto.', 'There is no more room here.'); return; }
    R.wrong[d.id] = (R.wrong[d.id] || 0) + 1;
    if (R.wrong[d.id] >= 2) { hint(d.id); say('Guarda: va qui!', 'Look: it goes here!'); }
  }
  function drop(x, y) {
    var d = drag; drag = null; tray.classList.remove('bin');
    if (!d.moved) { d.el.remove(); speak(name1(d.id, true)); var tile = tray.querySelector('[data-i="' + d.tileI + '"]'); if (tile) { tile.classList.remove('nope'); void tile.offsetWidth; tile.classList.add('nope'); } return; }   // a tap names it
    if (overTray(y)) { flyHome(d); if (d.from) sfx('back'); return; }                                   // back in the drawer (a placed one is taken away)
    var res = judge(d.id, toScene(x, y - 26));
    if (res.ok) { d.el.remove(); place(d.id, res, d); return; }
    refuse(d, res);
  }
  tray.addEventListener('pointerdown', function (ev) {
    var tile = ev.target.closest ? ev.target.closest('.tile') : null;
    if (!tile || drag || pend || locked || tile.classList.contains('gone')) return;
    ev.preventDefault(); lift(tile.getAttribute('data-id'), ev.clientX, ev.clientY, null, ev.pointerId, +tile.getAttribute('data-i'));
    try { tile.setPointerCapture(ev.pointerId); } catch (err) {}
  });
  sceneEl.addEventListener('pointerdown', function (ev) {
    if (drag || pend || locked) return; var g = ev.target.closest ? ev.target.closest('.set') : null; if (!g) return;
    ev.preventDefault(); pend = { n: +g.getAttribute('data-n'), x: ev.clientX, y: ev.clientY, pid: ev.pointerId };
    try { sceneEl.setPointerCapture(ev.pointerId); } catch (err) {}
  });
  window.addEventListener('pointermove', function (ev) {
    if (pend && ev.pointerId === pend.pid && Math.abs(ev.clientX - pend.x) + Math.abs(ev.clientY - pend.y) > 9) {
      var it = null; placed.forEach(function (p) { if (p.n === pend.n) it = p; }); var pid = pend.pid; pend = null;
      if (it && R.mode === 'conta') { unplace(it); var ti = -1; R.tray.forEach(function (q, i) { if (q.id === it.id) ti = i; }); lift(it.id, ev.clientX, ev.clientY, it, pid, ti >= 0 ? ti : null); }   // only while counting can a sticker be taken back
    }
    if (drag && ev.pointerId === drag.pid) { if (Math.abs(ev.clientX - drag.sx) + Math.abs(ev.clientY - drag.sy) > 6) drag.moved = true; follow(ev.clientX, ev.clientY); }
  }, true);
  function onUp(ev) {
    if (pend && ev.pointerId === pend.pid) { var n = pend.n; pend = null; var it = null; placed.forEach(function (p) { if (p.n === n) it = p; }); if (it) { hop(n); speak(name1(it.id, true)); sfx('react'); } return; }
    if (!drag || ev.pointerId !== drag.pid) return; drop(drag.x, drag.y);
  }
  window.addEventListener('pointerup', onUp, true); window.addEventListener('pointercancel', onUp, true);

  /* ---------- counting: the green button ---------- */
  function bubble(it, label) { var b = box(it.id); fx.insertAdjacentHTML('beforeend', '<g class="cbub" transform="translate(' + it.x.toFixed(0) + ',' + Math.max(40, it.y - b.h / 2 - 30).toFixed(0) + ')"><circle r="36" fill="#fff" stroke="' + INK + '" stroke-width="5"/><text text-anchor="middle" dominant-baseline="central" y="3">' + label + '</text></g>'); }
  function check() {
    if (locked || R.mode !== 'conta') return;
    locked = true; $('btnOk').disabled = true; fx.innerHTML = '';
    var gap = calm ? 60 : (voiceOn() ? 700 : 450), steps = [], bad = [], cards = $('cards').children;
    R.req.forEach(function (q, ri) {
      var mine = placed.filter(function (p) { return p.id === q.id; });
      steps.push(function () { cards[ri].classList.remove('good', 'bad'); cards[ri].classList.add('now'); return gap * 0.4; });
      mine.forEach(function (it, k2) { steps.push(function () { hop(it.n); bubble(it, k2 + 1); speak(numWord(k2 + 1, true)); sfx('count', k2 + 1); return gap; }); });
      steps.push(function () { var ok = mine.length === q.n; cards[ri].classList.remove('now'); cards[ri].classList.add(ok ? 'good' : 'bad'); if (!ok) bad.push({ q: q, n: mine.length }); sfx(ok ? 'done' : 'no'); return gap * 0.7; });
    });
    (function run() {
      if (steps.length) { setTimeout(run, steps.shift()()); return; }
      if (!bad.length) { win(); return; }
      var w = bad[0];
      $('say').textContent = bad.map(function (b2) { var m = many(b2.q.id); m = m.charAt(0).toUpperCase() + m.slice(1); return L(m + ': ' + (b2.n === 1 ? 'ce n\'è 1' : 'sono ' + b2.n) + ', ne servono ' + b2.q.n + '.' + (b2.n > b2.q.n ? ' Togline qualcuno: trascinali nel cassetto.' : ''), m + ': there ' + (b2.n === 1 ? 'is 1' : 'are ' + b2.n) + ', ' + b2.q.n + ' needed.' + (b2.n > b2.q.n ? ' Take some away: drag them to the drawer.' : '')); }).join(' ');
      speak(eng() ? many(w.q.id, true) + ': ' + numWord(w.n, true) + '. You need ' + numWord(w.q.n, true) + '.' : many(w.q.id, true) + ': ' + numWord(w.n, true) + '. Ne servono ' + numWord(w.q.n, true) + '.');
      setTimeout(function () { fx.innerHTML = ''; locked = false; $('btnOk').disabled = false; Array.prototype.forEach.call(cards, function (c2) { c2.classList.remove('bad', 'good'); }); }, calm ? 300 : 2200);
    })();
  }
  $('btnOk').addEventListener('click', check);
  $('cards').addEventListener('click', function (e2) { if (R && R.mode === 'posti' && e2.target.closest && e2.target.closest('#stepCard')) { speak(stepText(true)); return; } var c2 = e2.target.closest ? e2.target.closest('.numcard') : null; if (!c2 || locked) return; var q = R.req[+c2.getAttribute('data-r')]; speak(howmany(q.id, q.n, true) + ' ' + ztext(zone(q.z), true)); });

  /* ---------- winning ---------- */
  function confetti() {
    if (calm) return; var h = '', cols = ['#EE5E4D', '#FFD95A', '#7DB7F7', '#8DD68A', '#4FC3C7', '#F59A3A'], i;
    for (i = 0; i < 56; i++) { var w = 14 + Math.random() * 14; h += '<rect class="conf" x="' + (Math.random() * VW).toFixed(0) + '" y="-60" width="' + w.toFixed(0) + '" height="' + (w * 1.5).toFixed(0) + '" rx="4" fill="' + cols[i % 6] + '" style="--x:' + ((Math.random() - 0.5) * 380).toFixed(0) + 'px;--y:' + (VH + 200) + 'px;--r:' + ((Math.random() * 900 - 450) | 0) + 'deg;--t:' + (1.9 + Math.random() * 1.7).toFixed(2) + 's;--dl:' + (Math.random() * 0.8).toFixed(2) + 's"/>'; }
    fx.insertAdjacentHTML('beforeend', '<g>' + h + '</g>');
  }
  function win() {
    locked = true; prog.rounds[SC.id] = (prog.rounds[SC.id] || 0) + 1; saveProg();
    confetti(); sfx('win'); buzz([12, 60, 18]); placed.forEach(function (p, i) { setTimeout(function () { hop(p.n); }, 90 * i); });
    setTimeout(function () { say('Bravo!', 'Well done!'); }, 450);
    $('resText').textContent = R.mode === 'posti' ? L('Hai ascoltato bene: ogni cosa dove l\'hai sentita.', 'You listened well: everything where you heard it.') : R.mode === 'sagome' ? L('Ogni ombra ha il suo adesivo.', 'Every shadow has its sticker.') : R.mode === 'dove' ? L('Ogni cosa al suo posto.', 'Everything in its place.') : L('Giusto: ', 'Right: ') + R.req.map(function (q) { return written(q.id, q.n) + ' ' + ztext(zone(q.z)); }).join(L(' e ', ' and ')) + '.';
    $('say').textContent = '';
    setTimeout(function () { var r2 = $('result'); r2.hidden = false; void r2.offsetWidth; r2.classList.add('show'); }, calm ? 100 : 1000);
  }
  function hideResult() { var r2 = $('result'); r2.classList.remove('show'); r2.hidden = true; }
  $('btnNext').addEventListener('click', function () { newRound(); });
  $('btnScenes').addEventListener('click', function () { showPicker(); });

  /* ---------- choosing the scene ---------- */
  function showPicker() {
    SC = null; R = null; hideResult(); try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (err) {}
    document.body.classList.add('picking'); $('title').textContent = L('Adesivi', 'Stickers'); $('modeChip').innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2.4"/><circle cx="10" cy="17" r="2.4"/></svg>';
    var mp = document.querySelector('.mschips[data-k="mode"]');
    $('picker').innerHTML = '<section class="modepick" aria-label="' + L('Come vuoi giocare?', 'How do you want to play?') + '"><h2>' + L('Come vuoi giocare?', 'How do you want to play?') + '</h2><div class="mschips pics" data-k="mode">' + (mp ? mp.innerHTML : '') + '</div></section>' + SCENES.map(function (s2) { var n = prog.rounds[s2.id] || 0; return '<button class="scn" type="button" data-s="' + s2.id + '"><span class="thumb"><svg viewBox="0 0 1000 1320" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' + s2.bg() + '</svg></span>' + (s2.hero ? '<span class="hero">' + pic(s2.hero) + '</span>' : '') + '<span class="sname">' + L(s2.it, s2.en) + '</span>' + (n ? '<span class="stars" aria-label="' + n + '">★ ' + n + '</span>' : '') + '</button>'; }).join('');
    paintModes();
  }
  $('picker').addEventListener('click', function (e2) {
    var ch = e2.target.closest ? e2.target.closest('.modepick .chip') : null;
    if (ch) { prog.mode = ch.getAttribute('data-v'); saveProg(); paintModes(); sfx('tap'); var lb = ch.querySelector('.lbl'); if (lb) speak(lb.textContent); return; }
    var b2 = e2.target.closest ? e2.target.closest('.scn') : null; if (!b2) return;
    SCENES.forEach(function (s2) { if (s2.id === b2.getAttribute('data-s')) SC = s2; });
    document.body.classList.remove('picking'); $('picker').innerHTML = ''; sfx('tap'); newRound();
  });
  $('btnBack').addEventListener('click', showPicker);
  function paintModes() { Array.prototype.forEach.call(document.querySelectorAll('.mschips'), function (grp) { var v = prog[grp.getAttribute('data-k')]; Array.prototype.forEach.call(grp.children, function (b2) { b2.setAttribute('aria-pressed', b2.getAttribute('data-v') === String(v) ? 'true' : 'false'); }); }); }
  $('modeChip').addEventListener('click', function () { if (drag) return; paintModes(); $('modeSheet').hidden = false; sfx('tap'); });
  function closeModes() { $('modeSheet').hidden = true; }
  $('btnModeClose').addEventListener('click', closeModes);
  $('modeSheet').addEventListener('click', function (e2) {
    if (e2.target === $('modeSheet')) { closeModes(); return; }
    var b2 = e2.target.closest ? e2.target.closest('.chip') : null; if (!b2) return;
    var key = b2.parentNode.getAttribute('data-k'), v = b2.getAttribute('data-v'); if (prog[key] === v) { closeModes(); return; }
    prog[key] = v; saveProg(); paintModes(); sfx('tap');
    setTimeout(function () { closeModes(); if (SC) newRound(); }, 220);                      // the new choice starts a new round straight away
  });
  showPicker();
  window.__AD = { state: function () { return { R: R, SC: SC, placed: placed }; } };   // read by the automatic tests only
