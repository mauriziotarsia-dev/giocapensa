  /* Drawing helpers, the sticker drawings of the first version, and the bedroom — all in the plum-outline pastel style. */
  var INK = '#4A3B52';
  var $ = function (id) { return document.getElementById(id); };
  function k(w) { return ' stroke="' + INK + '" stroke-width="' + (w == null ? 5 : w) + '" stroke-linejoin="round" stroke-linecap="round"'; }
  function r(x, y, w, h, rx, f, sw) { return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + rx + '" fill="' + f + '"' + k(sw) + '/>'; }
  function c(cx, cy, rad, f, sw) { return '<circle cx="' + cx + '" cy="' + cy + '" r="' + rad + '" fill="' + f + '"' + k(sw) + '/>'; }
  function e(cx, cy, rx, ry, f, sw) { return '<ellipse cx="' + cx + '" cy="' + cy + '" rx="' + rx + '" ry="' + ry + '" fill="' + f + '"' + k(sw) + '/>'; }
  function p(d, f, sw) { return '<path d="' + d + '" fill="' + (f || 'none') + '"' + k(sw) + '/>'; }
  function ln(d, col, w) { return '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round"/>'; }
  function soft(d, f, op, cls) { return '<path' + (cls ? ' class="' + cls + '"' : '') + ' d="' + d + '" fill="' + f + '" opacity="' + (op || 1) + '"/>'; }
  function dot(cx, cy, rad, f) { return '<circle cx="' + cx + '" cy="' + cy + '" r="' + rad + '" fill="' + (f || INK) + '"/>'; }
  function G(cls, inner, extra) { return '<g class="' + cls + '"' + (extra || '') + '>' + inner + '</g>'; }
  function eyes(x1, x2, y, rad) { return G('part blink', dot(x1, y, rad) + dot(x2, y, rad)); }     // they blink now and then
  function cheeks(x, y, gap, f) { return dot(x - gap, y, 6, f || '#FFB59A') + dot(x + gap, y, 6, f || '#FFB59A'); }
  function smile(x, y, w) { return p('M' + (x - w) + ' ' + y + 'q' + w + ' ' + w * 0.8 + ' ' + w * 2 + ' 0', null, 4); }
  function star(cx, cy, rad, f, sw) {
    var d = '', i, a, rr;
    for (i = 0; i < 10; i++) { a = -Math.PI / 2 + i * Math.PI / 5; rr = i % 2 ? rad * 0.47 : rad; d += (i ? 'L' : 'M') + (cx + rr * Math.cos(a)).toFixed(1) + ' ' + (cy + rr * Math.sin(a)).toFixed(1); }
    return p(d + 'Z', f || '#FFD95A', sw);
  }
  function shine(cx, cy, rx, ry, rot) { return '<ellipse cx="' + cx + '" cy="' + cy + '" rx="' + rx + '" ry="' + ry + '" fill="#fff" opacity=".42" transform="rotate(' + (rot == null ? -28 : rot) + ' ' + cx + ' ' + cy + ')"/>'; }

  var ART = {
    orsetto: { w: 104, h: 112, size: 132, idle: 'i-breathe', tap: 'react', note: 392, d: function () {
      return c(26, 24, 15, '#C08B58') + c(78, 24, 15, '#C08B58') + dot(26, 24, 7.5, '#EBC9A2') + dot(78, 24, 7.5, '#EBC9A2') +
        e(52, 82, 30, 24, '#C08B58') + e(52, 87, 19, 16, '#EBC9A2') + c(20, 74, 12, '#C08B58') + c(84, 74, 12, '#C08B58') +
        c(52, 42, 27, '#C08B58') + e(52, 51, 14, 10, '#EBC9A2') + shine(38, 30, 9, 6) +
        eyes(41, 63, 38, 4.4) + e(52, 47, 5.5, 4.2, INK, 0) + smile(52, 54, 6) + cheeks(52, 48, 22); } },
    gatto: { w: 110, h: 112, size: 142, idle: 'i-breathe', tap: 'react', note: 660, d: function () {
      return G('part tail', p('M72 96q34 2 30-32-3-20-21-15 14 3 12 19t-25 18Z', '#EBB068')) + e(52, 80, 27, 26, '#F9C784') +
        p('M30 20l-4-18 19 10ZM74 20l4-18-19 10Z', '#F9C784') + c(52, 42, 26, '#F9C784') +
        p('M34 28l-6-8M70 28l6-8', null, 4) + shine(38, 30, 9, 6) + e(40, 100, 12, 8, '#EBB068') + e(64, 100, 12, 8, '#EBB068') +
        eyes(41, 63, 40, 4.4) + p('M52 48l-5 4 5 4 5-4Z', '#E8788C', 0) + smile(52, 54, 6) + cheeks(52, 50, 22) +
        p('M28 52h-16M30 58l-14 5M76 52h16M74 58l14 5', null, 3.5); } },
    cane: { w: 112, h: 112, size: 142, idle: 'i-breathe', tap: 'react', note: 294, d: function () {
      return G('part tail fast', p('M80 98q28-8 20-34-7-20-20-12 12 6 9 20t-18 18Z', '#B9793D')) + e(52, 82, 28, 25, '#E0A96B') + e(52, 88, 17, 15, '#F6E0C0') +
        e(22, 48, 13, 25, '#B9793D') + e(82, 48, 13, 25, '#B9793D') + c(52, 46, 26, '#E0A96B') + shine(38, 34, 9, 6) +
        e(52, 60, 17, 12, '#F6E0C0') + eyes(41, 63, 42, 4.4) + e(52, 54, 6, 4.6, INK, 0) + smile(52, 62, 6) + cheeks(52, 54, 24); } },
    uccellino: { w: 112, h: 92, size: 112, idle: 'i-hop', tap: 'react', note: 1320, d: function () {
      return p('M8 24l30 20-30 22q-4-20 0-42Z', '#5E96D8') + e(58, 44, 32, 27, '#7DB7F7') + shine(44, 28, 11, 7) +
        G('part wing', p('M44 44q16-6 28 6t-16 16q-14 2-16-10Z', '#A8CFFB')) + p('M88 38l22 7-22 8Z', '#F2A65A') +
        G('part blink', dot(76, 33, 4.4)) + dot(74, 45, 6, '#FFB59A') + p('M48 70v14M66 70v14M42 84h12M60 84h12', null, 4); } },
    dinosauro: { w: 128, h: 112, size: 150, idle: 'i-breathe', tap: 'react', note: 220, d: function () {
      return G('part tail', p('M34 80q-26 0 -32 -22q14 14 34 8Z', '#6CC070')) + r(46, 84, 16, 24, 7, '#58A85E') + r(74, 84, 16, 24, 7, '#58A85E') +
        p('M26 84q-4 -34 30 -36q14 0 24 6q2 -36 24 -42q20 -2 20 14t-16 16q-2 24 -10 40q-8 12 -34 12q-32 0 -38 -10Z', '#6CC070') + e(62, 88, 22, 11, '#CFEFC4', 3) +
        p('M42 51l6 -13l8 11ZM59 49l7 -14l8 13Z', '#F59A3A', 3.5) + shine(98, 15, 8, 5) + G('part blink', dot(109, 22, 4.2)) + p('M105 32q7 5 14 0', null, 3.5) + dot(99, 31, 5, '#FFB59A'); } },
    stella: { w: 100, h: 100, size: 104, idle: 'i-twinkle', tap: 'twirl', note: 1568, d: function () {
      return star(50, 52, 46, '#FFD95A') + eyes(40, 60, 44, 4) + smile(50, 56, 6) + cheeks(50, 52, 18); } },
    razzo: { w: 92, h: 136, size: 112, idle: 'i-float', tap: 'react', note: 784, d: function () {
      return G('part flick', p('M32 98q14 38 14 38t14 -38Z', '#FFD95A', 4) + soft('M39 100q7 22 7 22t7 -22Z', '#F59A3A')) +
        p('M20 78l-16 28 18 -8ZM72 78l16 28 -18 -8Z', '#EE5E4D') + p('M46 6q27 28 27 68v24H19V74q0 -40 27 -68Z', '#EEF3F7') +
        p('M46 6q15 15 21 36H25q6 -21 21 -36Z', '#EE5E4D') + shine(32, 66, 5, 20, 0) + c(46, 62, 13, '#7DB7F7') + shine(41, 57, 5, 3.5) + p('M19 90h54', null, 4); } },
    sole: { w: 116, h: 116, size: 138, idle: 'i-bob', tap: 'twirl', note: 988, d: function () {
      var rays = '', i;
      for (i = 0; i < 10; i++) rays += '<path d="M58 4l7 17h-14Z" fill="#F2A65A"' + k(4) + ' transform="rotate(' + i * 36 + ' 58 58)"/>';
      return G('part spin', rays) + c(58, 58, 34, '#FFD95A') + shine(46, 44, 10, 6) + eyes(48, 68, 54, 4.2) + smile(58, 64, 7) + cheeks(58, 62, 22); } },
    luna: { w: 116, h: 104, size: 142, idle: 'i-bob', tap: 'react', note: 523, d: function () {
      return p('M74 12a42 42 0 1 0 14 68A36 36 0 0 1 74 12Z', '#FFD95A') + p('M40 44q6-4 12 0M40 60q7 7 14 0', null, 4.5) + cheeks(46, 56, 20) +
        G('part twk', star(96, 26, 14)) + G('part twk', star(102, 66, 10), ' style="animation-delay:-.9s"'); } },
    nuvola: { w: 116, h: 100, size: 152, idle: 'i-float', tap: 'react', note: 440, d: function () {
      return G('part swing', p('M36 70v12M58 70v18M80 70v12', null, 4) + star(36, 90, 9) + star(58, 96, 9) + star(80, 90, 9)) +
        p('M28 68q-22 0-22-17t22-17q3-21 23-21t25 19q19-2 23 15t-19 21Z', '#DFF3FC') + soft('M30 40q4-16 22-18-16 6-18 20Z', '#fff', .7) +
        p('M44 50q3-3 6 0M66 50q3-3 6 0', null, 4) + smile(58, 56, 5); } },
    arcobaleno: { w: 186, h: 108, size: 208, idle: 'i-bob', tap: 'react', note: 698, d: function () {
      var s = p('M20 94A73 73 0 0 1 166 94Z', '#FFF6DE'), cols = ['#F47C7C', '#F2A65A', '#FFD95A', '#8DD68A', '#7DB7F7'], i;
      for (i = 0; i < 5; i++) s += ln('M' + (26 + i * 13) + ' 94A' + (67 - i * 13) + ' ' + (67 - i * 13) + ' 0 0 1 ' + (160 - i * 13) + ' 94', cols[i], 13);
      s += p('M20 94A73 73 0 0 1 166 94M85 94A8 8 0 0 1 101 94', null, 4.5);
      return s + e(26, 94, 27, 15, '#DFF3FC') + e(160, 94, 27, 15, '#DFF3FC'); } },
    palloncino: { w: 84, h: 132, size: 104, idle: 'i-float', tap: 'react', note: 880, d: function () {
      return p('M42 84q-8 14 4 24t-6 22', null, 4) + p('M36 82h12l-6 9Z', '#2F6FC4', 4) + e(42, 44, 34, 40, '#4C8FE0') + shine(28, 26, 10, 14, -20); } },
    palla: { w: 100, h: 100, size: 106, idle: 'i-roll', tap: 'twirl', note: 330, d: function () {
      return c(50, 50, 42, '#fff') + p('M50 32l17 12l-6.500 20h-21L33 44Z', '#3A4654', 3.5) + p('M50 32V10M67 44l20 -7M60.500 64l12 18M39.500 64l-12 18M33 44l-20 -7', null, 3.5) +
        soft('M37 10q13 -5 26 0l-13 8ZM91 35q3 13 -1 26l-9 -15ZM9 35q-3 13 1 26l9 -15ZM31 88q-10 -6 -15 -17l15 3ZM69 88q10 -6 15 -17l-15 3Z', '#3A4654') + shine(34, 27, 11, 7); } },
    macchinina: { w: 140, h: 82, size: 152, idle: 'i-drive', tap: 'react', note: 247, d: function () {
      return c(38, 66, 15, INK) + c(102, 66, 15, INK) + dot(38, 66, 6, '#B9BDC4') + dot(102, 66, 6, '#B9BDC4') +
        p('M14 58q0-16 12-19 10-24 44-24t42 24q12 3 12 19 0 10-10 10H24q-10 0-10-10Z', '#7DB7F7') +
        p('M44 21q26-6 50 2l6 16H38Z', '#DFF3FC') + p('M70 18v21', null, 4) + dot(114, 44, 5, '#FFF3A6') + shine(44, 30, 14, 6); } },
    aereo: { w: 146, h: 100, size: 160, idle: 'i-float', tap: 'react', note: 494, d: function () {
      return p('M24 44l-10 -28h18l14 26Z', '#EE5E4D') + p('M14 56q4 -20 42 -22h52q26 2 30 20q-6 16 -32 16H48q-28 0 -34 -14Z', '#EEF3F7') + ln('M20 63q58 9 114 -3', '#EE5E4D', 7) +
        p('M62 58l-18 34h24l24 -34Z', '#EE5E4D') + [66, 86, 106].map(function (x) { return c(x, 47, 6.5, '#7DB7F7', 3); }).join('') + shine(40, 43, 12, 5) +
        G('part spin fast', e(140, 54, 4, 23, '#3A4654', 3)) + c(138, 54, 5.5, '#F59A3A', 3); } },
    trenino: { w: 140, h: 106, size: 158, idle: 'i-drive', tap: 'react', note: 330, d: function () {
      return G('part puff', c(38, 8, 8, '#fff', 3)) + r(30, 16, 16, 26, 4, '#3A4654') + r(14, 38, 66, 34, 14, '#4C8FE0') + shine(32, 47, 12, 5) + r(76, 16, 46, 56, 8, '#EE5E4D') + r(86, 26, 26, 22, 5, '#DFF3FC') +
        r(8, 66, 122, 16, 8, '#3A4654') + p('M8 82l-8 12h16Z', '#F59A3A', 4) +
        [30, 62, 102].map(function (x, n) { var rr = n === 2 ? 15 : 13; return G('part spin fast', c(x, 88, rr, '#2B323B') + ln('M' + x + ' ' + (88 - rr + 4) + 'v' + (rr * 2 - 8) + 'M' + (x - rr + 4) + ' 88h' + (rr * 2 - 8), '#FFD95A', 3) + dot(x, 88, 4.5, '#FFD95A')); }).join(''); } },
    pianta: { w: 100, h: 126, size: 146, idle: 'i-sway', tap: 'react', note: 349, d: function () {
      return p('M50 76q-30-6-36-32 26-8 38 18ZM50 72q2-34 28-42 8 26-16 40ZM50 78q22-2 30-16 2 14-14 20ZM50 80V44', '#7FC47E', 4.5) +
        p('M22 78h56l-7 42q-1 8-10 8H39q-9 0-10-8Z', '#E0784E') + p('M22 78h56M32 92h36', null, 4) + shine(34, 96, 6, 12, 0); } },
    lampada: { w: 96, h: 116, size: 112, idle: '', tap: 'react', note: 466, d: function () {
      return '<ellipse class="glow" cx="48" cy="40" rx="62" ry="54" fill="#FFE98A"/>' + p('M22 12h52l18 46H4Z', '#FFD95A') + soft('M22 12h20L30 58H4Z', '#fff', .35) +
        r(43, 58, 10, 38, 5, '#B98C62') + e(48, 102, 30, 11, '#B98C62') + p('M12 34h72', null, 4); } },
    libri: { w: 104, h: 92, size: 116, idle: '', tap: 'react', note: 262, d: function () {
      return r(8, 62, 88, 24, 6, '#7DB7F7') + r(15, 37, 74, 25, 6, '#F47C7C') + r(22, 12, 60, 25, 6, '#8DD68A') +
        p('M25 66v16M32 41v17M39 16v17', null, 4) + soft('M22 12h14v25H22Z', '#fff', .3); } },
    quadro: { w: 104, h: 94, size: 146, idle: '', tap: 'react', note: 415, d: function () {
      return r(6, 6, 92, 82, 12, '#C9A227') + r(17, 17, 70, 60, 7, '#FFF6DE') +
        p('M17 62l18-18 14 12 16-18 22 24v9q0 8-8 8H25q-8 0-8-8Z', '#8DD68A', 4) + dot(38, 34, 8, '#FFD95A'); } },
    tappeto: { w: 180, h: 88, size: 380, idle: '', tap: 'react', note: 196, d: function () {
      var s = e(90, 44, 84, 38, '#6FA8E8') + e(90, 44, 60, 25, '#FFD95A') + e(90, 44, 33, 13, '#7CCB78'), i;
      for (i = 0; i < 10; i++) s += p('M' + (10 + i * 0.6) + ' ' + (16 + i * 6) + 'h-8', null, 3.5) + p('M' + (170 - i * 0.6) + ' ' + (16 + i * 6) + 'h8', null, 3.5);
      return s; } }
  };
  /* ---------- the room ---------- */
  function room() {
    var x, i, s = '<defs><linearGradient id="gWallA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF6EA"/><stop offset="1" stop-color="#FFE9D4"/></linearGradient><linearGradient id="gWallB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE6CC"/><stop offset="1" stop-color="#FBD7B2"/></linearGradient>' +
      '<linearGradient id="gFloor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EFCFA6"/><stop offset="1" stop-color="#DDB483"/></linearGradient><linearGradient id="gBeam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF3B0" stop-opacity=".5"/><stop offset="1" stop-color="#FFF3B0" stop-opacity="0"/></linearGradient></defs>' +
      '<rect x="-400" y="-400" width="1800" height="2120" fill="url(#gWallB)"/>';
    s += '<rect x="-400" y="-400" width="1800" height="928" fill="url(#gWallA)"/>';
    for (i = 0; i < 40; i++) { x = 40 + (i % 8) * 122 + (i % 3) * 18; s += dot(x, 60 + Math.floor(i / 8) * 96, 7, '#F6D6B4'); }
    s += r(-8, 520, 1016, 20, 8, '#F7E2C8');
    // bunting: every flag sways on its own
    s += p('M-10 46q250 60 510 30t510-46', null, 5);
    for (i = 0; i < 9; i++) {
      var bx = 30 + i * 112, by = 62 + Math.sin(i * 0.62) * 16 + (i < 5 ? i * 5 : (8 - i) * 5);
      s += G('rm flag', p('M' + bx + ' ' + by + 'h56l-28 52Z', ['#EE5E4D', '#FFD95A', '#8DD68A', '#7DB7F7'][i % 4], 4.5), ' style="--d:' + (-i * 0.37).toFixed(2) + 's"');
    }
    // floor
    s += '<rect x="-400" y="852" width="1800" height="868" fill="url(#gFloor)"/>';
    for (x = 36; x < 1000; x += 78) s += ln('M' + x + ' 860V1320', '#D8B184', 5);
    for (i = 0; i < 14; i++) s += ln('M' + (70 + (i % 7) * 132) + ' ' + (930 + Math.floor(i / 7) * 184) + 'q16 9 30 0', '#D8B184', 4);
    s += r(-8, 828, 1016, 36, 10, '#F7E2C8');
    // window: a little world outside that keeps moving; tapping it turns day into night
    s += '<rect class="sky" x="556" y="150" width="276" height="268" rx="16" fill="#BEE7F5"' + k(5) + '/>';
    s += '<clipPath id="win"><rect x="556" y="150" width="276" height="268" rx="16"/></clipPath><g clip-path="url(#win)">';
    s += G('wstars', [[590, 190, 0], [640, 236, -.7], [720, 178, -1.3], [792, 250, -.4], [604, 286, -1.7], [806, 176, -1]].map(function (w) { return G('rm wstar', star(w[0], w[1], 9, '#FFF3A6', 0), ' style="--d:' + w[2] + 's"'); }).join(''));
    var rays = ''; for (i = 0; i < 12; i++) rays += '<path d="M760 166v18" stroke="#F2A65A" stroke-width="6" stroke-linecap="round" transform="rotate(' + i * 30 + ' 760 214)"/>';
    s += G('sunG', G('rm rays', rays) + dot(760, 214, 30, '#FFD95A'));
    s += G('moonG', '<path d="M772 184a34 34 0 1 0 12 56 29 29 0 0 1-12-56Z" fill="#FFF3A6"/>');
    s += G('rm cloud', soft('M596 208q0-14 16-14t16 14q14 0 14 12t-18 12h-30q-16 0-16-12t18-12Z', '#fff', .9, 'cloudfill'));
    s += G('rm birdfly', '<path d="M560 250q8-10 16 0 8-10 16 0" fill="none" stroke="' + INK + '" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>');
    s += soft('M556 330q60-46 128-20t148 4v104H556Z', '#9BD48C', 1, 'hill');
    s += r(650, 300, 12, 46, 5, '#B9793D', 4) + c(656, 288, 32, '#7FC47E', 4.5);
    s += '</g>';
    s += r(556, 150, 276, 268, 16, 'none') + p('M694 150v268M556 284h276', null, 4.5);
    s += G('rm curtain', p('M530 132h66q-18 60 0 120t-14 90h-52Z', '#6FA8E8')) + G('rm curtain r', p('M858 132h-66q18 60 0 120t14 90h52Z', '#6FA8E8'));
    s += r(524, 414, 340, 26, 10, '#F7E2C8');
    s += '<g class="beam"><path d="M560 440L360 1180H700L828 440Z" fill="url(#gBeam)"/>' + [[520, 640, 0], [600, 760, -1.1], [470, 880, -2.3], [640, 960, -0.6], [560, 1060, -1.8]].map(function (q) { return '<circle class="mote" style="--d:' + q[2] + 's" cx="' + q[0] + '" cy="' + q[1] + '" r="4" fill="#FFF8D6"/>'; }).join('') + '</g>';   // daylight falls in from the window, dust dancing in it
    s += '<rect id="winhit" x="596" y="150" width="196" height="264" fill="transparent"/>';
    // bed
    s += c(70, 556, 21, '#B87C4E') + r(48, 570, 44, 372, 16, '#C98A5B');
    s += c(422, 694, 18, '#B87C4E') + r(404, 708, 38, 234, 14, '#C98A5B');
    s += r(84, 846, 352, 68, 18, '#C98A5B') + r(92, 786, 336, 64, 18, '#F0F5F8');
    s += p('M238 772h176q18 0 18 18v46q0 18-18 18H238Z', '#8DD68A') + p('M240 806h192', null, 4);
    for (i = 0; i < 5; i++) s += dot(268 + i * 36, 790, 4.5, '#5FA968');
    s += r(106, 744, 128, 54, 18, '#FFF6DE') + r(122, 754, 96, 34, 14, 'none', 3.5);
    // bedside table and shelf
    s += r(474, 754, 150, 134, 16, '#C98A5B') + r(490, 776, 118, 48, 10, '#DFA877') + c(549, 800, 9, '#F7E2C8') + p('M474 844h150', null, 4);
    s += r(486, 888, 26, 50, 12, '#B87C4E') + r(586, 888, 26, 50, 12, '#B87C4E');
    s += r(690, 600, 292, 26, 10, '#C98A5B') + p('M724 626v26M948 626v26', null, 4.5);
    // at night the room dims, but the stickers above it stay bright
    return s + '<rect class="dusk" x="-400" y="-400" width="1800" height="2120" fill="#1B2250"/>';
  }

