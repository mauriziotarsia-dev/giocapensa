  /* ====== The winter mountain: cable car, snowplough, snowcat, sledge, snowman, mountain goat, fox, snowflake ====== */
  ART.funivia = { w: 120, h: 150, size: 140, idle: 'i-bob', tap: 'react', note: 523, d: function () {
    return r(38, 0, 44, 14, 7, '#3A4654') + dot(50, 7, 3, '#B9BDC4') + dot(70, 7, 3, '#B9BDC4') + ln('M60 14V34', INK, 6) +
      r(10, 40, 100, 104, 18, '#EE5E4D') + r(4, 30, 112, 16, 8, '#C7402F') + r(20, 54, 80, 44, 10, '#DFF3FC') +
      c(44, 80, 12, '#FFD9B3', 3) + dot(40, 78, 2.2) + dot(48, 78, 2.2) + p('M39 84q5 4 10 0', null, 2.2) +
      c(76, 80, 12, '#F0C08A', 3) + dot(72, 78, 2.2) + dot(80, 78, 2.2) + p('M71 84q5 4 10 0', null, 2.2) +
      ln('M16 120h88', '#FFD95A', 7) + shine(26, 58, 6, 3, 0) + shine(30, 128, 10, 3, 0);
  } };
  ART.spazzaneve = { w: 236, h: 160, size: 240, idle: 'i-drive', tap: 'react', note: 175, d: function () {
    return G('part puff', c(16, 44, 9, '#fff', 3) + c(30, 32, 6, '#fff', 3)) + r(44, 92, 22, 12, 4, '#3A4654') +
      p('M6 66l44 -6v72l-44 -8Z', '#FFD23F') + ln('M14 74v44', '#D9A516', 4) +
      r(62, 56, 92, 52, 12, '#F59A3A') + ln('M76 70h64M76 88h64', '#D97A26', 4) +
      r(176, 16, 22, 14, 6, '#FFD23F', 4) + r(150, 30, 76, 78, 14, '#F59A3A') + r(164, 42, 46, 30, 8, '#DFF3FC') + face(187, 54, 10) + shine(170, 38, 8, 4, 0) +
      r(40, 102, 188, 20, 10, '#3A4654') + wheel(92, 134, 22, '#B9BDC4') + wheel(196, 134, 22, '#B9BDC4');
  } };
  ART.gattonevi = { w: 240, h: 170, size: 220, idle: 'i-drive', tap: 'react', note: 196, d: function () {
    return r(0, 108, 30, 34, 10, '#FFD23F') + ln('M7 134h16', '#D9A516', 4) +
      r(190, 96, 26, 12, 4, '#3A4654') + p('M214 72l22 -8v70l-22 -8Z', '#B9BDC4') + ln('M223 74v50', '#8A919C', 4) +
      r(30, 66, 160, 50, 14, '#EE5E4D') + shine(70, 76, 22, 6, 0) +
      r(120, 12, 60, 12, 6, '#FFD23F', 4) + r(104, 22, 92, 72, 14, '#EE5E4D') + r(116, 32, 68, 34, 8, '#DFF3FC') + face(150, 46, 10) +
      r(22, 110, 196, 52, 26, '#3A4654') + ln('M44 114h152M44 158h152', '#5A6270', 3) + [52, 94, 136, 178].map(function (x) { return c(x, 136, 13, '#8A919C', 4); }).join('');
  } };
  ART.slittino = { w: 150, h: 96, size: 150, idle: 'i-breathe', tap: 'react', note: 392, d: function () {
    return p('M128 46q22 8 16 34', null, 3.5) + ln('M38 60v26M104 60v26', INK, 6) + p('M6 88h118q22 0 24 -26', null, 7) +
      r(16, 38, 116, 24, 10, '#EE5E4D') + ln('M30 50h88', '#C7402F', 4) + star(74, 50, 8, '#FFD95A', 3) + shine(36, 44, 12, 3, 0);
  } };
  ART.pupazzo = { w: 120, h: 162, size: 130, idle: 'i-sway', tap: 'react', note: 330, d: function () {
    return ln('M34 74L8 56M14 60l-8 -10M14 60l-10 2', '#9C6A3B', 5) + ln('M86 74L112 56M106 60l8 -10M106 60l10 2', '#9C6A3B', 5) +
      c(60, 120, 40, '#fff') + shine(44, 104, 10, 6) + c(60, 74, 30, '#fff') + dot(60, 66, 4) + dot(60, 82, 4) + dot(60, 112, 4) + dot(60, 128, 4) +
      c(60, 36, 22, '#fff') + p('M38 54q22 10 44 0v9q-22 10 -44 0Z', '#EE5E4D', 4) + r(66, 58, 12, 26, 5, '#EE5E4D', 4) +
      r(36, 14, 48, 8, 4, '#3A4654', 4) + r(44, 0, 32, 18, 4, '#3A4654', 4) + ln('M47 12h26', '#EE5E4D', 4) +
      eyes(52, 68, 31, 3.6) + cheeks(60, 41, 14) + p('M60 37l20 4 -20 5Z', '#F59A3A', 3.5) + smile(57, 47, 5);
  } };
  ART.stambecco = { w: 170, h: 150, size: 170, idle: 'i-breathe', tap: 'react', note: 220, d: function () {
    var s = G('part tail', p('M150 66q12 -6 14 4q-8 3 -14 4Z', '#A07A52', 4));
    [64, 84, 124, 144].forEach(function (x) { s += r(x - 8, 92, 16, 48, 7, '#A07A52', 4) + r(x - 8, 130, 16, 14, 5, INK, 0); });
    s += e(104, 80, 54, 28, '#C49A6C') + shine(96, 64, 20, 5, 0) + ln('M66 76L50 50', INK, 30) + ln('M66 76L50 50', '#C49A6C', 21);
    s += p('M46 32q-2 -30 34 -30q16 2 18 14q-22 -8 -34 4q-6 8 -6 16Z', '#EAD9B6') + ln('M62 10l4 8M74 6l2 9M86 7v9', '#C9B48E', 3.5);
    return s + e(58, 40, 10, 5, '#B08658', 3) + e(40, 48, 22, 16, '#C49A6C') + e(24, 54, 10, 8, '#B08658', 3) + dot(17, 52, 2.6) +
      p('M30 62l-4 16 12 -10Z', '#A07A52', 3.5) + G('part blink', dot(36, 44, 4)) + dot(44, 54, 5, '#FFB59A');
  } };
  ART.volpe = { w: 150, h: 112, size: 140, idle: 'i-breathe', tap: 'react', note: 294, d: function () {
    var s = G('part tail', p('M114 66q40 0 34 -44q-14 26 -38 30Z', '#F59A3A') + p('M148 22q2 14 -10 22q2 -14 10 -22Z', '#fff', 3));
    [56, 72, 96, 112].forEach(function (x) { s += r(x - 6, 74, 12, 32, 6, '#E07D25', 4) + r(x - 6, 96, 12, 12, 5, INK, 0); });
    return s + e(84, 64, 40, 22, '#F59A3A') + e(78, 72, 24, 9, '#FFF4E8', 0) + shine(92, 52, 14, 4, 0) +
      p('M22 30l-6 -24 20 14Z', '#F59A3A', 4) + p('M46 26l12 -20 2 24Z', '#F59A3A', 4) + c(38, 44, 22, '#F59A3A') +
      p('M20 46q-18 4 -16 12q12 6 26 -2Z', '#FFF4E8', 4) + dot(6, 52, 4) + eyes(32, 46, 40, 3.6) + dot(50, 52, 5, '#FFB59A');
  } };
  ART.fiocco = { w: 110, h: 110, size: 110, idle: 'i-twinkle', tap: 'twirl', note: 1175, d: function () {
    var s = '', i;
    for (i = 0; i < 6; i++) s += '<g transform="rotate(' + i * 60 + ' 55 55)">' + ln('M55 55V9', INK, 14) + ln('M55 24l-10 -10M55 24l10 -10', INK, 9) + ln('M55 55V9', '#A8D8FF', 8) + ln('M55 24l-10 -10M55 24l10 -10', '#A8D8FF', 4) + '</g>';
    return s + c(55, 55, 24, '#E6F5FF') + cheeks(55, 59, 13) + eyes(47, 63, 52, 3.6) + smile(55, 60, 5);
  } };

  Object.assign(FOOT, { spazzaneve: 0.97, gattonevi: 0.95, slittino: 0.93, pupazzo: 0.99, stambecco: 0.96, volpe: 0.96 });
  Object.assign(NAMES, {
    funivia: ['la funivia', 'funivie', 'the cable car', 'cable cars'], spazzaneve: ['lo spazzaneve', 'spazzaneve', 'the snowplough', 'snowploughs'],
    gattonevi: ['il gatto delle nevi', 'gatti delle nevi', 'the snowcat', 'snowcats'], slittino: ['lo slittino', 'slittini', 'the sledge', 'sledges'],
    pupazzo: ['il pupazzo di neve', 'pupazzi di neve', 'the snowman', 'snowmen'], stambecco: ['lo stambecco', 'stambecchi', 'the mountain goat', 'mountain goats'],
    volpe: ['la volpe', 'volpi', 'the fox', 'foxes'], fiocco: ['il fiocco di neve', 'fiocchi di neve', 'the snowflake', 'snowflakes']
  });

  function pino(x, y, k) {                                         // a fir with snow on every tier; y is where the trunk meets the ground
    var s = r(x - 8 * k, y - 22 * k, 16 * k, 24 * k, 4, '#9C6A3B', 4);
    [[20, 60, 46], [50, 55, 38], [80, 50, 28]].forEach(function (t) {
      var yb = y - t[0] * k, ya = yb - t[1] * k, hw = t[2] * k, hh = t[1] * k;
      s += p('M' + (x - hw) + ' ' + yb + 'L' + x + ' ' + ya + 'L' + (x + hw) + ' ' + yb + 'Z', '#4FA463', 4) +
        soft('M' + (x - hw * 0.42) + ' ' + (ya + hh * 0.42) + 'L' + x + ' ' + (ya + 3) + 'L' + (x + hw * 0.42) + ' ' + (ya + hh * 0.42) + 'Q' + x + ' ' + (ya + hh * 0.56) + ' ' + (x - hw * 0.42) + ' ' + (ya + hh * 0.42) + 'Z', '#fff');
    });
    return s;
  }
  function montagna() {
    var s = '<defs><linearGradient id="mnSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#A9D8FF"/><stop offset="1" stop-color="#EAF6FF"/></linearGradient>' +
      '<linearGradient id="mnSnow" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#DCEBFA"/></linearGradient>' +
      '<linearGradient id="mnIce" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C9F1F5"/><stop offset="1" stop-color="#7FD3DE"/></linearGradient></defs>', i, x, g;
    s += '<rect x="-400" y="-400" width="1800" height="2120" fill="url(#mnSky)"/>';
    s += G('rm cloud', soft('M140 170q0-24 28-24t28 24q24 0 24 20t-30 20h-50q-28 0-28-20t28-20Z', '#fff', .9)) + G('rm cloud', soft('M500 92q0-20 24-20t24 20q20 0 20 16t-26 16h-42q-24 0-24-16t24-16Z', '#fff', .85), ' style="animation-delay:-8s"');
    // far ridges, then the two mountains with their snow caps
    s += soft('M-400 640L-60 430L130 560L340 400L560 560L780 360L1000 520L1400 420V900H-400Z', '#D3E2F4');
    s += p('M-60 780L180 380L440 780Z', '#A9BCD8') + p('M180 380L114 490q17 16 34 0q17 16 34 0q17 16 34 0q17 16 35 0Z', '#fff', 4);
    s += p('M300 780L690 290L1080 780Z', '#93AACB') + p('M690 290L587 420q17 16 34 0q17 16 34 0q17 16 34 0q17 16 34 0q17 16 34 0q18 16 37 0Z', '#fff', 4) + ln('M600 540l-26 60M780 520l34 66M470 640l-20 40', '#7F96B8', 6);
    // the cable car line: the stations and the cable the cabins hang from
    s += r(18, 536, 92, 64, 10, '#EE5E4D') + p('M10 540L64 506L118 540Z', '#C7402F') + c(65, 548, 14, '#B9BDC4', 4) + r(34, 568, 26, 26, 6, '#DFF3FC', 4);
    s += p('M598 352h84l18 70q-60 16 -120 0Z', '#8C9BB3') + soft('M604 360h72l4 16q-40 8 -80 0Z', '#fff') + r(592, 300, 92, 60, 10, '#EE5E4D') + p('M584 304L638 270L692 304Z', '#C7402F') + c(640, 318, 14, '#B9BDC4', 4) + r(612, 330, 26, 24, 6, '#DFF3FC', 4);
    s += ln('M65 548L640 318', INK, 5) + ln('M65 562L640 332', '#5A6270', 3);
    // the rocks where the goat climbs, with snow on top
    s += p('M724 742L744 676Q752 652 780 648L860 642Q884 634 904 646L990 638Q1010 636 1014 650V742Z', '#8C9BB3') + ln('M790 690l20 26M930 676l-16 34M868 700l8 24', '#74839C', 5) +
      soft('M748 664Q756 648 780 646L860 640Q884 630 904 644L990 636Q1012 634 1012 652Q990 660 960 652Q930 664 900 656Q870 666 840 656Q800 666 770 658Q756 668 748 664Z', '#fff');
    // the snowfield
    s += '<path d="M-20 720q250 -40 500 -10t520 0V1340H-20Z" fill="url(#mnSnow)" stroke="' + INK + '" stroke-width="5"/>';
    // the ski slope: groomed lines and gates
    s += soft('M572 520q-30 260 -236 510h424q-100 -210 -130 -510Z', '#F4FAFF') + ln('M566 580q-40 240 -160 440M584 580q-10 250 -60 450M604 580q20 250 120 440', '#E1EEFA', 5);
    [[430, 820, '#EE5E4D'], [600, 900, '#5FA4F2'], [450, 980, '#EE5E4D']].forEach(function (q) { s += ln('M' + q[0] + ' ' + q[1] + 'v-58', '#3A4654', 5) + p('M' + q[0] + ' ' + (q[1] - 58) + 'l30 10 -30 10Z', q[2], 3.5); });
    // the woods
    s += pino(50, 800, 1.1) + pino(150, 792, 1.25) + pino(272, 806, 1.05);
    // the big fir with room underneath
    s += r(888, 880, 24, 126, 8, '#9C6A3B') + [[900, 110, 100], [842, 98, 80], [786, 90, 58]].map(function (t) { return p('M' + (900 - t[2]) + ' ' + t[0] + 'L900 ' + (t[0] - t[1]) + 'L' + (900 + t[2]) + ' ' + t[0] + 'Z', '#4FA463', 4) + soft('M' + (900 - t[2] * 0.4) + ' ' + (t[0] - t[1] * 0.58) + 'L900 ' + (t[0] - t[1] + 3) + 'L' + (900 + t[2] * 0.4) + ' ' + (t[0] - t[1] * 0.58) + 'Q900 ' + (t[0] - t[1] * 0.46) + ' ' + (900 - t[2] * 0.4) + ' ' + (t[0] - t[1] * 0.58) + 'Z', '#fff'); }).join('');
    // the frozen pond
    s += '<ellipse cx="885" cy="1068" rx="115" ry="42" fill="url(#mnIce)" stroke="' + INK + '" stroke-width="5"/>' + ln('M820 1060l40 -10M900 1084l50 -12', '#fff', 5);
    // the hut, its chimney smoking and its windows lit
    s += G('rm smoke', c(260, 840, 14, '#EFF3F7', 3) + c(276, 818, 10, '#EFF3F7', 3)) + r(246, 846, 30, 50, 4, '#B9793D', 4);
    s += r(40, 930, 260, 112, 12, '#C98A5B') + ln('M48 960h244M48 990h244M48 1020h244', '#B0743F', 4);
    s += r(148, 966, 52, 76, 10, '#8E5A34') + dot(188, 1006, 4.5, '#FFD95A') + r(64, 958, 56, 46, 8, '#FFE58A') + r(222, 958, 56, 46, 8, '#FFE58A') + p('M92 958v46M64 981h56M250 958v46M222 981h56', null, 4);
    s += p('M10 942L170 858L330 942Z', '#EE5E4D') + p('M14 940L170 860L326 940q-20 -16 -40 -10q-26 -18 -54 -6q-30 -20 -62 -4q-30 -18 -60 2q-28 -16 -56 4q-20 -10 -40 14Z', '#fff', 4);
    // the plowed road with its snow banks and marker poles
    s += '<rect x="-20" y="1128" width="1040" height="140" fill="#9AA8BB" stroke="' + INK + '" stroke-width="5"/>';
    for (x = 40; x < 1000; x += 150) s += r(x, 1194, 80, 10, 5, '#F4F5F7', 0);
    s += soft('M-20 1132q40 -26 80 -4q40 -24 80 0q40 -22 80 2q40 -26 80 -2q40 -22 80 0q40 -24 80 -2q40 -22 80 2q40 -24 80 0q40 -22 80 0q40 -24 80 -2q40 -20 80 2q40 -22 80 0V1140H-20Z', '#fff');
    [360, 560, 740].forEach(function (q) { s += r(q - 5, 1060, 10, 70, 4, '#fff', 3) + r(q - 5, 1060, 10, 18, 4, '#EE5E4D', 3) + r(q - 5, 1096, 10, 14, 0, '#EE5E4D', 0); });
    s += '<rect x="-20" y="1266" width="1040" height="90" fill="url(#mnSnow)"/>';
    // snow falling, in three layers so that it never stops
    for (g = 0; g < 3; g++) {
      var fl = '';
      for (i = 0; i < 18; i++) fl += dot((i * 131 + g * 61) % 1000, (i * 197 + g * 113) % 1240, 4 + ((i + g) % 3) * 1.6, '#fff');
      s += G('rm snow', fl, ' style="animation-delay:' + (-g * 2.7) + 's" opacity=".9"');
    }
    return s;
  }

  SCENES.push({ id: 'montagna', it: 'La montagna', en: 'The mountain', bg: montagna, hero: 'pupazzo', zones: [
    { id: 'cavo', it: 'sul cavo', en: 'on the cable', rects: [[180, 440, 160, 220], [340, 380, 160, 220], [500, 316, 160, 220]], slots: [[260, 557], [420, 493], [580, 429]] },
    { id: 'rocce', it: 'sulle rocce', en: 'on the rocks', base: true, rects: [[730, 500, 280, 230]], slots: [[820, 646], [940, 646]] },
    { id: 'bosco', it: 'nel bosco', en: 'in the woods', base: true, rects: [[0, 660, 330, 160]], slots: [[90, 806], [240, 812]] },
    { id: 'baita', it: 'davanti alla baita', en: 'in front of the hut', base: true, rects: [[0, 1040, 340, 88]], slots: [[90, 1112], [250, 1112]] },
    { id: 'strada', it: 'sulla strada', en: 'on the road', base: true, rects: [[0, 1128, 1000, 140]], slots: [[140, 1244], [390, 1244], [640, 1244], [880, 1244]] },
    { id: 'pista', it: 'sulla pista', en: 'on the ski slope', base: true, rects: [[340, 720, 420, 310]], slots: [[440, 870], [660, 860], [400, 1012], [580, 1020], [750, 1012]] },
    { id: 'cielo', it: 'in cielo', en: 'in the sky', rects: [[0, 0, 1000, 290], [760, 290, 240, 160]], slots: [[120, 110], [350, 80], [600, 120], [860, 100], [230, 240], [480, 230], [880, 380]] }],
    items: [['funivia', 'cavo'], ['stambecco', 'rocce'], ['volpe', 'bosco'], ['pupazzo', 'baita'], ['cane', 'baita'], ['spazzaneve', 'strada'], ['slittino', 'pista'], ['gattonevi', 'pista'],
      ['fiocco', 'cielo'], ['uccellino', 'cielo'], ['nuvola', 'cielo'], ['sole', 'cielo']],
    spots: [
      { id: 'p-tetto', it: 'sopra il tetto della baita', en: 'on the roof of the hut', rects: [[10, 780, 320, 150]], slots: [[100, 840], [240, 840]], movers: ['uccellino', 'fiocco', 'gatto'] },
      { id: 'p-baita', it: 'davanti alla baita', en: 'in front of the hut', base: true, rects: [[0, 1040, 340, 88]], slots: [[90, 1112], [250, 1112]], movers: ['pupazzo', 'cane', 'slittino', 'volpe'] },
      { id: 'p-pino', it: "sotto l'abete", en: 'under the fir tree', base: true, scale: 0.65, rects: [[808, 900, 192, 110]], slots: [[846, 1004], [954, 1004]], movers: ['volpe', 'cane', 'slittino', 'pupazzo'] },
      { id: 'p-ghiaccio', it: 'sopra il ghiaccio', en: 'on the ice', base: true, rects: [[770, 1022, 230, 96]], slots: [[836, 1082], [936, 1082]], movers: ['slittino', 'volpe', 'cane', 'pupazzo'] }] });
