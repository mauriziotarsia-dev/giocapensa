  /* ====== The farm: animals and machines ====== */
  function wool(list) { return list.map(function (q) { return c(q[0], q[1], q[2], '#fff', 4); }).join('') + list.map(function (q) { return c(q[0], q[1], q[2] - 2.5, '#fff', 0); }).join(''); }
  ART.mucca = { w: 204, h: 150, size: 205, idle: 'i-breathe', tap: 'react', note: 196, d: function () {
    var s = G('part tail', p('M182 66q20 6 16 40', null, 5) + c(197, 108, 7, INK, 0));
    [74, 96, 150, 172].forEach(function (x) { s += r(x - 9, 98, 18, 40, 8, '#fff', 4) + r(x - 9, 128, 18, 12, 5, INK, 4); });
    s += r(52, 48, 136, 66, 30, '#fff') + soft('M84 52q22 -4 30 12q-6 20 -28 16q-10 -12 -2 -28Z', INK) + soft('M146 64q18 -2 26 14q-10 16 -26 10Z', INK) + e(124, 116, 14, 7, '#FFB3C1', 4);
    s += p('M26 38l-10 -20q12 2 16 14Z', '#F2E2B0', 4) + p('M62 36l10 -20q-12 2 -16 14Z', '#F2E2B0', 4) + e(12, 54, 13, 7, '#fff', 4) + e(78, 52, 13, 7, '#fff', 4);
    return s + e(44, 62, 32, 30, '#fff') + e(40, 84, 26, 15, '#FFB3C1', 4) + dot(32, 84, 3) + dot(48, 84, 3) + eyes(32, 54, 56, 4.5) + shine(58, 46, 8, 4, -20);
  } };
  ART.maiale = { w: 172, h: 124, size: 160, idle: 'i-breathe', tap: 'react', note: 262, d: function () {
    var s = G('part tail', p('M156 54q18 -8 12 8q-6 10 4 14', null, 4));
    [54, 76, 118, 140].forEach(function (x) { s += r(x - 8, 86, 16, 32, 7, '#F7A8B8', 4); });
    s += e(98, 62, 62, 40, '#FFC2CF') + shine(86, 38, 20, 6, 0);
    return s + p('M24 36l-8 -18 20 8Z', '#F7A8B8', 4) + p('M54 32l10 -18 4 20Z', '#F7A8B8', 4) + e(40, 60, 32, 30, '#FFC2CF') + e(22, 70, 15, 11, '#F7A8B8', 4) + dot(17, 70, 2.6) + dot(27, 70, 2.6) + eyes(32, 52, 52, 4.5) + cheeks(48, 66, 16);
  } };
  ART.pecora = { w: 176, h: 132, size: 160, idle: 'i-breathe', tap: 'react', note: 330, d: function () {
    var s = ''; [72, 94, 132, 152].forEach(function (x) { s += r(x - 7, 92, 14, 34, 6, '#5C4A63', 4); });
    s += wool([[78, 52, 26], [108, 42, 28], [140, 52, 26], [156, 78, 22], [128, 92, 26], [96, 94, 26], [68, 80, 24], [110, 70, 30]]);
    return s + e(22, 52, 11, 6, '#5C4A63', 4) + e(62, 50, 11, 6, '#5C4A63', 4) + e(42, 66, 22, 27, '#5C4A63') + wool([[38, 40, 10], [50, 44, 8]]) +
      dot(34, 62, 5, '#fff') + dot(50, 62, 5, '#fff') + G('part blink', dot(34, 63, 2.6) + dot(50, 63, 2.6)) + ln('M36 78q6 5 12 0', '#fff', 3);
  } };
  ART.gallina = { w: 124, h: 132, size: 115, idle: 'i-hop', tap: 'react', note: 523, d: function () {
    return ln('M54 106v20M76 106v20M46 126h14M68 126h14', '#F59A3A', 6) + p('M96 62q24 -6 24 -30q-16 8 -26 10Z', '#fff', 4) +
      p('M24 70q0 -36 44 -36q40 0 40 34q0 40 -44 40q-40 0 -40 -38Z', '#fff') + p('M58 74q22 -6 34 8q-16 18 -34 6Z', '#F3EDE4', 4) +
      c(42, 40, 22, '#fff') + p('M28 22q4 -16 12 -6q6 -12 12 0q8 -8 10 6Z', '#EE5E4D', 4) + p('M20 40l-14 4 14 6Z', '#FFD23F', 4) + e(26, 56, 5, 8, '#EE5E4D', 3) + G('part blink', dot(38, 36, 4)) + shine(56, 50, 10, 4, -20);
  } };
  ART.pulcino = { w: 92, h: 94, size: 82, idle: 'i-hop', tap: 'react', note: 784, d: function () {
    return ln('M38 78v12M54 78v12', '#F59A3A', 5) + c(46, 50, 34, '#FFE066') + p('M30 18q4 -14 12 -4', null, 4) + p('M12 52l-12 4 12 6Z', '#F59A3A', 4) + p('M56 54q14 -2 18 10q-12 6 -18 -2Z', '#FFD23F', 4) +
      eyes(30, 46, 44, 4) + cheeks(38, 56, 14) + shine(36, 32, 8, 4, -20);
  } };
  ART.anatra = { w: 134, h: 98, size: 122, idle: 'i-bob', tap: 'react', note: 440, d: function () {
    return ln('M8 90q20 -7 40 0t40 0t40 0', '#7DC4F7', 5) + p('M118 56l14 -16v26Z', '#FFE066', 4) + e(76, 66, 52, 24, '#FFE066') + p('M72 58q20 -10 36 4q-16 14 -36 4Z', '#FFD23F', 4) +
      c(40, 36, 22, '#FFE066') + p('M20 36q-16 0 -18 6q8 8 20 2Z', '#F59A3A', 4) + G('part blink', dot(36, 32, 4)) + cheeks(42, 44, 8) + shine(54, 56, 12, 4, 0);
  } };
  ART.rana = { w: 112, h: 94, size: 100, idle: 'i-hop', tap: 'react', note: 330, d: function () {
    return e(18, 84, 16, 7, '#6CB868', 4) + e(94, 84, 16, 7, '#6CB868', 4) + e(56, 62, 44, 28, '#7CCB78') + c(34, 32, 16, '#7CCB78') + c(78, 32, 16, '#7CCB78') +
      dot(34, 32, 8, '#fff') + dot(78, 32, 8, '#fff') + G('part blink', dot(34, 33, 4.5) + dot(78, 33, 4.5)) + p('M36 66q20 14 40 0', null, 4) + dot(26, 64, 6, '#FFB59A') + dot(86, 64, 6, '#FFB59A') + shine(50, 48, 12, 4, 0);
  } };
  ART.trattore = { w: 214, h: 178, size: 240, idle: 'i-drive', tap: 'react', note: 175, d: function () {
    return G('part puff', c(150, 14, 9, '#fff', 3) + c(162, 4, 6, '#fff', 3)) + r(144, 22, 12, 42, 4, '#3A4654') +
      r(20, 72, 172, 52, 14, '#EE5E4D') + r(30, 18, 84, 70, 12, '#EE5E4D') + r(42, 28, 60, 40, 8, '#DFF3FC') + face(72, 42, 10) + r(22, 10, 100, 16, 8, '#3A4654') + shine(160, 84, 14, 5, 0) +
      G('part spin', c(62, 130, 44, '#2B323B') + ln('M62 94v72M26 130h72', '#FFD95A', 5)) + c(62, 130, 18, '#FFD95A', 4) +
      G('part spin fast', c(176, 146, 26, '#2B323B') + ln('M176 126v40M156 146h40', '#FFD95A', 4)) + c(176, 146, 10, '#FFD95A', 3);
  } };
  ART.fieno = { w: 152, h: 112, size: 140, idle: 'i-breathe', tap: 'react', note: 294, d: function () {
    return r(10, 22, 112, 84, 30, '#F2C14E') + ln('M24 42h84M24 62h84M24 84h84', '#D9A516', 4) + e(120, 64, 26, 42, '#F7D06A') + p('M120 40q-12 10 0 24q12 10 0 22', null, 3.5) + shine(42, 32, 18, 5, 0);
  } };

  /* ====== Prehistory ====== */
  ART.pterodattilo = { w: 212, h: 112, size: 210, idle: 'i-float', tap: 'twirl', note: 659, d: function () {
    return G('part wingL', p('M98 58L8 26q18 34 72 46Z', '#B58BD9')) + G('part wingR', p('M114 58L204 26q-18 34 -72 46Z', '#B58BD9')) +
      e(106, 64, 22, 18, '#C9A3E8') + p('M128 40l-22 -22l28 10Z', '#B58BD9', 4) + c(138, 50, 16, '#C9A3E8') + p('M150 46l32 6l-32 8Z', '#FFD23F', 4) +
      G('part blink', dot(140, 46, 4)) + ln('M96 82l-8 14M114 82l6 14', INK, 4);
  } };
  ART.triceratopo = { w: 214, h: 140, size: 220, idle: 'i-breathe', tap: 'react', note: 147, d: function () {
    var s = G('part tail', p('M168 70q30 0 42 20q-24 0 -42 -6Z', '#7DB7F7'));
    [72, 98, 142, 164].forEach(function (x) { s += r(x - 10, 96, 20, 36, 8, '#5FA4F2', 4); });
    s += e(120, 76, 58, 38, '#7DB7F7') + shine(112, 52, 22, 6, 0) + soft('M110 60q10 -4 16 4q-6 8 -16 4Z', '#5FA4F2') + soft('M140 84q10 -4 16 4q-6 8 -16 4Z', '#5FA4F2');
    s += p('M60 30q-30 4 -30 44q32 12 52 -6Z', '#F59A3A') + ln('M44 40l6 10M58 36v12M70 40l-4 10', '#D97A26', 4);
    return s + e(46, 74, 30, 24, '#7DB7F7') + p('M20 72l-18 -2 14 14Z', '#FFF4D9', 4) + p('M42 54l-8 -28 14 24Z', '#FFF4D9', 4) + p('M58 56l4 -28 8 28Z', '#FFF4D9', 4) + eyes(38, 54, 70, 4) + smile(44, 82, 6);
  } };
  ART.stegosauro = { w: 214, h: 140, size: 220, idle: 'i-breathe', tap: 'react', note: 165, d: function () {
    var s = '';
    [[72, 48], [102, 34], [132, 34], [160, 48]].forEach(function (q) { s += p('M' + (q[0] - 15) + ' ' + (q[1] + 22) + 'l15 -32l15 32Z', '#F59A3A'); });
    s += p('M168 78q30 -6 40 -26q4 26 -36 36Z', '#8DD68A') + p('M196 58l10 -14M204 68l14 -6', null, 4);
    [70, 94, 140, 164].forEach(function (x) { s += r(x - 10, 96, 20, 34, 8, '#7CCB78', 4); });
    return s + e(118, 78, 60, 34, '#8DD68A') + shine(110, 58, 22, 6, 0) + e(42, 84, 24, 16, '#8DD68A') + eyes(34, 46, 80, 3.6) + smile(38, 90, 5);
  } };
  ART.collolungo = { w: 212, h: 192, size: 230, idle: 'i-breathe', tap: 'react', note: 131, d: function () {
    return e(134, 158, 70, 34, '#B9A3E3') + soft('M122 134q14 -6 22 4q-8 10 -22 4Z', '#9C86C9') + soft('M158 140q12 -4 18 4q-6 8 -18 4Z', '#9C86C9') + p('M198 150q16 -10 12 -28', null, 6) +
      ln('M100 152Q76 84 56 42', INK, 32) + ln('M100 152Q76 84 56 42', '#B9A3E3', 22) + e(48, 34, 28, 19, '#B9A3E3') + eyes(40, 58, 30, 4) + smile(48, 40, 6) + cheeks(48, 38, 20) +
      p('M0 162q26 -10 52 0t52 0t52 0t56 0V192H0Z', '#8FD3F4') + ln('M14 174h40M120 180h50', '#fff', 4);
  } };
  ART.uovo = { w: 110, h: 120, size: 100, idle: 'i-sway', tap: 'react', note: 587, d: function () {
    return p('M55 8c26 0 42 36 42 62 0 26 -18 42 -42 42s-42 -16 -42 -42c0 -26 16 -62 42 -62Z', '#F3EDE4') + dot(40, 46, 7, '#9CD08E') + dot(70, 38, 6, '#9CD08E') + dot(66, 80, 9, '#9CD08E') + dot(36, 86, 5, '#9CD08E') + shine(38, 30, 7, 12, -20);
  } };
  ART.cucciolo = { w: 120, h: 132, size: 110, idle: 'i-hop', tap: 'react', note: 698, d: function () {
    return c(60, 48, 30, '#8DD68A') + p('M44 20l6 -12 6 12M62 18l6 -12 6 12', '#F59A3A', 3.5) + eyes(48, 72, 44, 4.5) + smile(60, 56, 7) + cheeks(60, 52, 18) +
      p('M14 80l10 -12 12 12 12 -12 12 12 12 -12 12 12 12 -12 10 12v20q0 26 -46 26t-46 -26Z', '#F3EDE4') + dot(40, 106, 6, '#9CD08E') + dot(78, 100, 5, '#9CD08E');
  } };

  Object.assign(FOOT, { mucca: 0.95, maiale: 0.95, pecora: 0.95, gallina: 0.96, pulcino: 0.96, trattore: 0.98, fieno: 0.95, triceratopo: 0.94, stegosauro: 0.93, collolungo: 0.84, uovo: 0.94, cucciolo: 0.97 });
  Object.assign(NAMES, {
    mucca: ['la mucca', 'mucche', 'the cow', 'cows'], maiale: ['il maiale', 'maiali', 'the pig', 'pigs'], pecora: ['la pecora', 'pecore', 'the sheep', 'sheep'], gallina: ['la gallina', 'galline', 'the hen', 'hens'],
    pulcino: ['il pulcino', 'pulcini', 'the chick', 'chicks'], anatra: ["l'anatra", 'anatre', 'the duck', 'ducks'], rana: ['la rana', 'rane', 'the frog', 'frogs'], trattore: ['il trattore', 'trattori', 'the tractor', 'tractors'],
    fieno: ['il fieno', 'balle di fieno', 'the hay bale', 'hay bales'], pterodattilo: ['lo pterodattilo', 'pterodattili', 'the pterodactyl', 'pterodactyls'], triceratopo: ['il triceratopo', 'triceratopi', 'the triceratops', 'triceratops'],
    stegosauro: ['lo stegosauro', 'stegosauri', 'the stegosaurus', 'stegosauruses'], collolungo: ['il collolungo', 'collilunghi', 'the long-neck', 'long-necks'], uovo: ["l'uovo", 'uova', 'the egg', 'eggs'],
    cucciolo: ['il cucciolo', 'cuccioli', 'the baby dinosaur', 'baby dinosaurs']
  });

  function fattoria() {
    var s = '<defs><linearGradient id="faSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#BFE6FF"/><stop offset="1" stop-color="#F1FAFF"/></linearGradient>' +
      '<linearGradient id="faGrass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#B9E39C"/><stop offset="1" stop-color="#8FCB74"/></linearGradient>' +
      '<linearGradient id="faWater" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9ADAF6"/><stop offset="1" stop-color="#5FB6E6"/></linearGradient>' +
      '<linearGradient id="faBarn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EE6A58"/><stop offset="1" stop-color="#C94A3A"/></linearGradient></defs>', i, x;
    s += '<rect x="-400" y="-400" width="1800" height="2120" fill="url(#faSky)"/>';
    s += soft('M-400 600q300-140 620-50t640-30 740 60V760H-400Z', '#CDEBB6') + soft('M-400 640q260-60 520 0t560-20 720 40V780H-400Z', '#B5DF98');
    s += G('rm cloud', soft('M160 160q0-24 28-24t28 24q24 0 24 20t-30 20h-50q-28 0-28-20t28-20Z', '#fff', .9)) + G('rm cloud', soft('M520 90q0-20 24-20t24 20q20 0 20 16t-26 16h-42q-24 0-24-16t24-16Z', '#fff', .85), ' style="animation-delay:-9s"');
    // the field behind the fence: golden rows
    s += '<rect x="-20" y="600" width="620" height="178" fill="#EBCB7A" stroke="' + INK + '" stroke-width="5"/>';
    for (i = 0; i < 6; i++) s += ln('M0 ' + (618 + i * 28) + 'q150 -10 300 0t300 0', '#D9AE4E', 5);
    // the barn with its hayloft and a weathervane
    s += r(600, 420, 380, 360, 14, 'url(#faBarn)') + p('M578 436L790 300L1002 436Z', '#8E3B30') + ln('M606 430L790 314L974 430', '#fff', 7);
    s += r(742, 360, 96, 70, 10, '#5A3A2E') + soft('M752 420q40-30 76 0Z', '#F2C14E') + ln('M790 300V250', INK, 5) + G('rm vane', p('M770 254h40l-8 -8M770 254l8 8', null, 5));
    s += p('M700 562L636 594V748L700 780Z', '#E8604F') + ln('M694 574L644 744M644 600L694 766', '#FFF4E8', 6) + p('M880 562L944 594V748L880 780Z', '#E8604F') + ln('M886 574L936 744M936 600L886 766', '#FFF4E8', 6);
    s += r(700, 560, 180, 222, 12, '#FFF4E8') + r(714, 574, 152, 208, 8, '#4A2F24') + soft('M714 600h152v-26H714Z', '#2E1C16', .6) + soft('M722 782q22-62 64-56q52-18 74 56Z', '#F2C14E') + ln('M742 760l14 -18M790 752l6 -20M830 762l12 -16', '#D9A516', 4) + soft('M714 574l60 208H714Z', '#FFF3D0', .08);
    // fences: around the meadow, and the yard in front of the barn
    for (x = 20; x <= 580; x += 70) s += r(x - 7, 760, 14, 70, 4, '#C98A5B', 4);
    s += r(0, 776, 600, 12, 5, '#DDA26F', 4) + r(0, 804, 600, 12, 5, '#DDA26F', 4);
    s += '<rect x="-20" y="788" width="1040" height="560" fill="url(#faGrass)"/>';
    s += soft('M610 830q190-40 380 0v230q-190 30-380 0Z', '#E9D6A8', .9);
    s += soft('M26 806h550q12 0 12 12v274H14V818q0-12 12-12Z', '#CFE4A2', .95);
    for (i = 0; i < 14; i++) s += ln('M' + (50 + (i * 83) % 500) + ' ' + (840 + (i * 47) % 220) + 'l14 -6', '#D9C27A', 4);
    [24, 584].forEach(function (q) { for (var yy = 836; yy <= 1100; yy += 66) s += r(q - 7, yy - 34, 14, 46, 4, '#C98A5B', 4); s += ln('M' + q + ' 806V1112', '#DDA26F', 7); });
    for (x = 24; x <= 584; x += 70) if (x < 250 || x > 360) s += r(x - 7, 1082, 14, 52, 4, '#C98A5B', 4);
    s += r(10, 1094, 248, 11, 5, '#DDA26F', 4) + r(10, 1116, 248, 11, 5, '#DDA26F', 4) + r(352, 1094, 246, 11, 5, '#DDA26F', 4) + r(352, 1116, 246, 11, 5, '#DDA26F', 4);
    s += p('M352 1086l-62 -40v48l62 36Z', '#E7B47E') + ln('M352 1100l-60 -38M352 1122l-60 -38', '#C98A5B', 4);
    // the pond, with reeds and lily pads
    s += '<ellipse cx="650" cy="1205" rx="330" ry="96" fill="url(#faWater)" stroke="' + INK + '" stroke-width="5"/>' + ln('M420 1190h120M700 1240h140', '#C9ECFB', 5);
    s += e(430, 1230, 30, 10, '#6CB868', 4) + e(880, 1180, 26, 9, '#6CB868', 4);
    [[338, 1150], [356, 1140], [960, 1170], [944, 1160]].forEach(function (q) { s += ln('M' + q[0] + ' ' + q[1] + 'v-70', '#5F9E48', 6) + e(q[0], q[1] - 78, 7, 18, '#9C6A3B', 3); });
    for (i = 0; i < 9; i++) s += star(40 + (i * 37) % 260, 1120 + (i * 53) % 170, 9, ['#fff', '#FFD95A', '#F7A8B8'][i % 3], 3);
    return s;
  }
  function preistoria() {
    var s = '<defs><linearGradient id="prSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFD9A8"/><stop offset="1" stop-color="#FFF3DF"/></linearGradient>' +
      '<linearGradient id="prLake" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8ED8EE"/><stop offset="1" stop-color="#4FB0D8"/></linearGradient>' +
      '<linearGradient id="prGrass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C8E69E"/><stop offset="1" stop-color="#9CCB6E"/></linearGradient></defs>', i;
    s += '<rect x="-400" y="-400" width="1800" height="2120" fill="url(#prSky)"/>';
    // the volcano, smoking now and then
    s += G('rm smoke', c(806, 214, 34, '#EFE8E2', 4) + c(840, 180, 26, '#EFE8E2', 4) + c(780, 166, 22, '#EFE8E2', 4));
    s += p('M560 640L748 262h96L1040 640Z', '#A88A78') + p('M748 262h96l-16 34q-30 12 -64 0Z', '#EE5E4D') + ln('M770 300l-40 120M820 300l30 90', '#EE5E4D', 8);
    s += soft('M-400 560q240-120 480-40t480-10 400 50V700H-400Z', '#C5B3D9') + soft('M-400 620q300-70 600-10t600 0V720H-400Z', '#B4D99A');
    // the lake on the left
    s += '<path d="M-20 650q300-30 560 10q30 110 -10 210q-280 30 -550 0Z" fill="url(#prLake)" stroke="' + INK + '" stroke-width="5"/>' + ln('M60 720h120M260 790h140M120 840h90', '#C9ECFB', 5);
    // the rock with the nest
    s += p('M600 890q14-176 210-192q186 4 204 192Z', '#B9A99A') + ln('M660 810q40-20 60 10M880 770q30-10 50 20', '#A08F80', 5);
    s += e(806, 710, 170, 32, '#C99A62') + ln('M660 704l70 -12M760 716l80 -14M850 700l70 12M690 722l-40 6M900 722l60 -4', '#9C6A3B', 5) + soft('M650 712q156 30 312 0', '#9C6A3B', .35);
    // the grass, ferns and footprints
    s += '<rect x="-20" y="870" width="1040" height="480" fill="url(#prGrass)"/>';
    [[40, 900], [960, 920], [70, 1300], [930, 1290]].forEach(function (q, n) {
      for (var k = -2; k <= 2; k++) s += p('M' + q[0] + ' ' + q[1] + 'q' + (k * 26) + ' -60 ' + (k * 44) + ' -100', '#5F9E48', 6);
    });
    for (i = 0; i < 5; i++) s += soft('M' + (300 + i * 90) + ' ' + (1210 + (i % 2) * 30) + 'q-14 -10 0 -20q14 10 0 20Z', '#8AB862');
    return s;
  }

  SCENES.push(
    { id: 'fattoria', it: 'La fattoria', en: 'The farm', bg: fattoria, hero: 'mucca', zones: [
      { id: 'stagno', it: 'nello stagno', en: 'in the pond', rects: [[330, 1112, 640, 186]], slots: [[480, 1196], [650, 1180], [820, 1206]] },
      { id: 'recinto', it: 'nel recinto', en: 'in the pen', base: true, rects: [[0, 788, 600, 300]], slots: [[200, 930], [430, 930], [110, 1060], [320, 1068], [510, 1060]] },
      { id: 'aia', it: "nell'aia", en: 'in the farmyard', base: true, rects: [[600, 782, 400, 300]], slots: [[690, 930], [880, 930], [660, 1060], [800, 1068], [930, 1060]] },
      { id: 'campo', it: 'nel campo', en: 'in the field', base: true, rects: [[0, 560, 600, 228]], slots: [[140, 772], [400, 772], [540, 772]] },
      { id: 'cielo', it: 'in cielo', en: 'in the sky', rects: [[0, 0, 1000, 300], [0, 300, 590, 260]], slots: [[140, 110], [380, 80], [620, 130], [860, 100], [260, 250], [480, 330], [160, 440]] }],
      items: [['mucca', 'recinto'], ['maiale', 'recinto'], ['pecora', 'recinto'], ['gallina', 'aia'], ['pulcino', 'aia'], ['cane', 'aia'], ['anatra', 'stagno'], ['rana', 'stagno'],
        ['trattore', 'campo'], ['fieno', 'campo'], ['uccellino', 'cielo'], ['nuvola', 'cielo'], ['sole', 'cielo']] },
    { id: 'preistoria', it: 'La preistoria', en: 'Prehistory', bg: preistoria, hero: 'triceratopo', zones: [
      { id: 'nido', it: 'nel nido', en: 'in the nest', base: true, rects: [[620, 560, 390, 170]], slots: [[700, 716], [806, 716], [912, 716], [753, 700], [859, 700]] },
      { id: 'acqua', it: 'nel lago', en: 'in the lake', base: true, rects: [[0, 650, 560, 225]], slots: [[150, 822], [380, 822]] },
      { id: 'prato', it: 'sul prato', en: 'on the grass', base: true, rects: [[0, 875, 1000, 445]], slots: [[160, 1100], [430, 1112], [700, 1100], [880, 1112], [280, 1276], [580, 1286], [850, 1276]] },
      { id: 'cielo', it: 'in cielo', en: 'in the sky', rects: [[0, 0, 1000, 160], [0, 160, 560, 420]], slots: [[140, 100], [380, 80], [620, 90], [880, 80], [240, 300], [440, 380], [160, 480]] }],
      items: [['pterodattilo', 'cielo'], ['nuvola', 'cielo'], ['sole', 'cielo'], ['collolungo', 'acqua'], ['triceratopo', 'prato'], ['stegosauro', 'prato'], ['dinosauro', 'prato'], ['uovo', 'nido'], ['cucciolo', 'nido']] }
  );
  SCENES[0].hero = 'locomotiva'; SCENES[1].hero = 'escavatore'; SCENES[2].hero = 'orsetto';

  /* «Sopra, sotto, dentro»: the voice asks for one sticker in one place named with a preposition.
     Each place lists the stickers that may be asked to go there; «scale» shrinks them where there is little room. */
  var SPOTS = {
    stazione: [
      { id: 'p-sopra', it: 'sopra la pensilina', en: 'on top of the canopy', base: true, rects: [[16, 430, 532, 128]], slots: [[110, 556], [270, 556], [430, 556]], movers: ['uccellino', 'gatto'] },
      { id: 'p-sotto', it: 'sotto la pensilina', en: 'under the canopy', base: true, rects: [[20, 600, 520, 345]], slots: [[120, 936], [270, 936], [420, 936]], movers: ['valigia', 'cane', 'gatto', 'orsetto'] },
      { id: 'p-porta', it: 'davanti alla porta', en: 'in front of the door', base: true, rects: [[690, 782, 170, 168]], slots: [[770, 936]], movers: ['valigia', 'cane', 'orsetto'] }],
    cantiere: [
      { id: 'p-sopra', it: 'sopra il ponteggio', en: 'on the scaffolding', base: true, rects: [[20, 360, 440, 120], [20, 510, 440, 120]], slots: [[100, 467], [230, 467], [360, 467], [100, 617], [230, 617], [360, 617]], movers: ['secchio', 'mattoni', 'uccellino'] },
      { id: 'p-sotto', it: 'sotto il ponteggio', en: 'under the scaffolding', base: true, rects: [[20, 640, 440, 150]], slots: [[100, 786], [230, 786], [360, 786]], movers: ['secchio', 'mattoni', 'cono', 'cane'] },
      { id: 'p-dentro', it: 'dentro lo scavo', en: 'inside the dig', base: true, rects: [[468, 790, 524, 222]], slots: [[560, 1000], [700, 1000], [860, 1000]], movers: ['secchio', 'cono', 'cane', 'carriola'] }],
    cameretta: [
      { id: 'p-letto', it: 'sopra il letto', en: 'on the bed', base: true, rects: [[90, 620, 340, 170]], slots: [[175, 752], [335, 779]], movers: ['gatto', 'orsetto', 'palla', 'dinosauro'] },
      { id: 'p-davanti', it: 'davanti al letto', en: 'in front of the bed', base: true, rects: [[60, 950, 400, 190]], slots: [[150, 1080], [300, 1090], [420, 1080]], movers: ['gatto', 'cane', 'palla', 'macchinina', 'dinosauro'] },
      { id: 'p-comodino', it: 'sopra il comodino', en: 'on the bedside table', base: true, rects: [[470, 640, 160, 120]], slots: [[549, 757]], movers: ['libri', 'orsetto', 'gatto'] },
      { id: 'p-sottocom', it: 'sotto il comodino', en: 'under the bedside table', base: true, scale: 0.55, rects: [[480, 886, 140, 66]], slots: [[549, 940]], movers: ['palla', 'macchinina'] },
      { id: 'p-mensola', it: 'sopra la mensola', en: 'on the shelf', base: true, rects: [[690, 430, 290, 190]], slots: [[748, 603], [838, 603], [922, 603]], movers: ['libri', 'orsetto', 'trenino', 'macchinina'] },
      { id: 'p-sottomen', it: 'sotto la mensola', en: 'under the shelf', base: true, rects: [[690, 640, 300, 460]], slots: [[760, 1080], [900, 1080]], movers: ['cane', 'palla', 'trenino', 'dinosauro'] }],
    fattoria: [
      { id: 'p-stalla', it: 'dentro la stalla', en: 'inside the barn', base: true, rects: [[700, 560, 180, 220]], slots: [[745, 776], [835, 776]], movers: ['gallina', 'pulcino', 'maiale', 'gatto'] },
      { id: 'p-tetto', it: 'sopra il tetto della stalla', en: 'on the barn roof', rects: [[600, 280, 380, 150]], slots: [[680, 392], [900, 392], [790, 320]], movers: ['uccellino', 'gatto', 'gallina'] },
      { id: 'p-recinto', it: 'dentro il recinto', en: 'inside the pen', base: true, rects: [[0, 788, 600, 300]], slots: [[200, 930], [430, 930], [110, 1060], [320, 1068], [510, 1060]], movers: ['maiale', 'pecora', 'gallina', 'cane'] },
      { id: 'p-stagno', it: 'dentro lo stagno', en: 'in the pond', rects: [[330, 1112, 640, 186]], slots: [[480, 1196], [650, 1180], [820, 1206]], movers: ['anatra', 'rana'] }],
    preistoria: [
      { id: 'p-nido', it: 'dentro il nido', en: 'inside the nest', base: true, rects: [[620, 560, 390, 170]], slots: [[700, 716], [806, 716], [912, 716]], movers: ['uovo', 'cucciolo'] },
      { id: 'p-vulcano', it: 'sopra il vulcano', en: 'above the volcano', rects: [[680, 100, 240, 170]], slots: [[796, 190]], movers: ['pterodattilo'] },
      { id: 'p-lago', it: 'dentro il lago', en: 'in the lake', base: true, rects: [[0, 650, 560, 225]], slots: [[150, 822], [380, 822]], movers: ['collolungo'] },
      { id: 'p-roccia', it: 'davanti alla roccia', en: 'in front of the rock', base: true, rects: [[600, 890, 400, 160]], slots: [[700, 1010], [880, 1010]], movers: ['dinosauro', 'stegosauro', 'cucciolo', 'triceratopo'] }]
  };
  SCENES.forEach(function (s3) { s3.spots = SPOTS[s3.id] || []; });
