import UIKit
import Capacitor
import DeclaredAgeRange

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = CAPBridgeViewController()
        window?.makeKeyAndVisible()

        SceneDelegateProxy.shared.scene(scene, willConnectTo: session, options: connectionOptions)
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        ControlloEta.avvia(window?.rootViewController)
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        SceneDelegateProxy.shared.scene(scene, continue: userActivity)
    }
}

/// Age assurance where a law requires it (Texas since June 2026, and similar laws elsewhere).
/// iOS says whether the person signed in on this device is in such a region; only then the app asks
/// iOS for their age range, through Apple's own sheet. Everywhere else nothing is shown.
/// The answer is neither stored nor sent anywhere: Giocapensa is made for small children and no
/// feature depends on age. iOS 26.0 and 26.1 cannot tell the region, so nothing happens there.
/// DeclaredAgeRange exists only from iOS 26: the app links it weakly (OTHER_LDFLAGS), so it still
/// starts on older iOS, and the GitHub workflow checks the weak link in every build.
enum ControlloEta {
    private static var fatto = false

    static func avvia(_ vc: UIViewController?) {
        guard !fatto, let vc = vc else { return }
        fatto = true
        if #available(iOS 26.2, *) {
            Task { @MainActor in
                do {
                    guard try await AgeRangeService.shared.isEligibleForAgeFeatures else { return }
                    _ = try await AgeRangeService.shared.requestAgeRange(ageGates: 13, in: vc)
                } catch {
                    // Service not available or request not completed: the games work the same way.
                }
            }
        }
    }
}
